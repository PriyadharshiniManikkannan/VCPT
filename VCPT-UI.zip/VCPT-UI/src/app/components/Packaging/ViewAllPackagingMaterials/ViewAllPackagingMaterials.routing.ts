import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ViewAllPackagingMaterialsComponent } from './ViewAllPackagingMaterials.component';

const viewAllPackagingMaterialsRoutes: Routes = [
    {
        path: '',
        component: ViewAllPackagingMaterialsComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(viewAllPackagingMaterialsRoutes)],
    exports: [RouterModule]
})
export class ViewAllPackagingMaterialsRouteModule {

}
