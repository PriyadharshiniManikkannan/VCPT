import { Router } from '@angular/router';
import { CommonUtilitiesComponent } from './../../../shared/components/common-utilities/common-utilities.component';
import { ExtractAllDataService } from './../../../services/reports/ExtractAllData.service';
import { Component, OnInit } from '@angular/core';
import { FormLabelValues, ScreenTitles } from './../../../shared/constants/form.constants';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { APP_CONSTANTS, ConstantValues, MessageItems, Url } from './../../../shared/constants/app.constants';
import { MessageModel } from './../../../models/MessageModel.model';
import { ViewProductMasterService } from './../../../services/product/ViewProductMaster.service';
import { MaintainProductConfigurationsService } from './../../../services/product/MaintainProductConfigurations.service';
import { utils, write, WorkBook } from 'xlsx';
import { saveAs } from 'file-saver';
import { ViewProductMaster } from './../../../models/ViewProductMaster.model';
import { SelectItem } from 'primeng/primeng';

@Component(
    {
        templateUrl: './ExtractAllData.Component.html',
        styleUrls: ['./ExtractAllData.Component.scss']
    }
)

export  /**
 * ExtractAllDataComponent
 */
    class ExtractAllDataComponent implements OnInit {
    formLabels: any;
    formTitle: any;
    facilityDropdownItems: SelectItem[];
    selectedFacilities: number[];
    extractDataForm: FormGroup;
    productLegacyID: string;
    messageHeader: string;
    returnMessage: MessageModel;
    messageIconType: string;
    displayMessage: boolean;
    seletedFacilityValues: string;
    productDetails: any[];
    isNoRecords: boolean;
    viewProductDetails: any[];

    // Loading variable for ngx-loading component
    public loading = false;
    constructor(
        private formBuilder: FormBuilder, private extractAllDataService: ExtractAllDataService
        , private ViewProductMasterService: ViewProductMasterService,
        private MaintainProductConfigurationService: MaintainProductConfigurationsService,
        private _router: Router) {
    }
    ngOnInit() {
        this.formLabels = FormLabelValues;
        this.formTitle = ScreenTitles;
        this.returnMessage = new MessageModel();
        this.productLegacyID = '';
        this.isNoRecords = false;
        this.buildForm();
        this.facilityDropdownItems = [];
        this.ViewProductMasterService.getFacilities().subscribe((data: any) => {
            data.forEach(element => {
                this.facilityDropdownItems.push({ label: element.facilityName, value: element.facilityID });
            });
        },
            (err) => {
                if (err !== undefined) {
                    // this.messageHeader = MessageItems.erroHeader;
                    // this.returnMessage.message = MessageItems.errorMessgae;
                    // this.messageIconType = APP_CONSTANTS.ErrorIcon;
                    // this.displayMessage = true;
                    this._router.navigate([Url.error]);
                    return;
                }
            });

    }
    buildForm() {
        this.extractDataForm = this.formBuilder.group({
            productLegacyID: ['']
            , facilities: ['']
        });
    }
    s2ab(s) {
        const buf = new ArrayBuffer(s.length);
        const view = new Uint8Array(buf);
        for (let i = 0; i !== s.length; ++i) {
            view[i] = s.charCodeAt(i) & 0xFF;
        }
        return buf;
    }
    exportToExcel() {
        this.loading = true;
        this.productLegacyID = this.extractDataForm.get('productLegacyID').value;
        let timestamp = '';
        timestamp = CommonUtilitiesComponent.getCurrentDateTimeStamp();
        if (this.productLegacyID !== '' && this.productLegacyID !== undefined && this.productLegacyID !== null
            && this.productLegacyID.length === ConstantValues.productLegacyIDLength) {
            this.seletedFacilityValues = '';
            this.productDetails = [];
            if (this.selectedFacilities && this.selectedFacilities.length > 0) {
                this.selectedFacilities.forEach((facility, index) => {
                    if (index !== this.selectedFacilities.length - 1) {
                        this.seletedFacilityValues += facility.toString().trim() + ',';
                    } else {
                        this.seletedFacilityValues += facility.toString();
                    }

                });
            } else {
                this.seletedFacilityValues = '';
            }
            const sheetName = 'ExtractAllData' + '_' + this.productLegacyID + '_' + timestamp + '.xlsx';
            const ws_product = 'Product';
            const wb: WorkBook = { SheetNames: [], Sheets: {} };
            const prod = new ViewProductMaster();
            prod.productLegacyID = this.productLegacyID;
            prod.facilityCode = '';
            prod.productStatus.statusCode = 0;
            prod.productBusinessLifeCycleStatus.statusCode = '';
            prod.productDescription = '';
            prod.productCode = '';
            this.MaintainProductConfigurationService.getProductDetailsByLegacyID(prod).
                subscribe((ViewProductDetails: any[]) => {
                    this.viewProductDetails = ViewProductDetails;
                    if (this.viewProductDetails !== undefined) {
                        if (this.viewProductDetails.length !== 0) {
                            this.viewProductDetails.forEach(element => {
                                if (element.productStatus.toString().toLowerCase()
                                    === ConstantValues.statusActive.toLowerCase()
                                    && element.productBusinessLifeCycleStatus.toString().toLowerCase()
                                    !== ConstantValues.statusInActive.toLowerCase()
                                    && element.productBusinessLifeCycleStatus.toString().toLowerCase()
                                    !== ConstantValues.statusObsolete.toLowerCase()) {
                                    this.extractAllDataService.extractAllData(this.seletedFacilityValues,
                                        this.productLegacyID).subscribe((data: any) => {
                                            this.loading = false;
                                            this.productDetails = [];
                                            this.productDetails = data;
                                            const ws: any = utils.json_to_sheet(this.productDetails);
                                            wb.SheetNames.push(ws_product);
                                            wb.Sheets[ws_product] = ws;
                                            if (this.productDetails.length === 0) {
                                                this.loading = false;
                                                this.isNoRecords = true;
                                                this.messageHeader = MessageItems.erroHeader;
                                                this.returnMessage.message = MessageItems.noResultsMessage;
                                                this.messageIconType = APP_CONSTANTS.ErrorIcon;
                                                this.displayMessage = true;
                                                return;
                                            } else {
                                                this.isNoRecords = false;
                                                const wbout = write(wb, { bookType: 'xlsx', bookSST: true, type: 'binary' });
                                                saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }),
                                                    sheetName

                                                );
                                            }
                                        },
                                        (err) => {
                                            if (err !== undefined) {
                                                // this.messageHeader = MessageItems.erroHeader;
                                                // this.returnMessage.message = MessageItems.errorMessgae;
                                                // this.messageIconType = APP_CONSTANTS.ErrorIcon;
                                                // this.displayMessage = true;
                                                this._router.navigate([Url.error]);
                                                return;
                                            }
                                        });
                                } else if (element.productStatus.toLowerCase() === ConstantValues.productStatusDraft.toLowerCase()) {
                                    this.messageHeader = MessageItems.productHeader;
                                    this.returnMessage.message = MessageItems.draftMessage;
                                    this.messageIconType = APP_CONSTANTS.ErrorIcon;
                                    this.displayMessage = true;
                                      this.isNoRecords = true;
                                    this.loading = false;
                                } else if (element.productStatus.toLowerCase() === ConstantValues.productStatusInActive.toLowerCase()) {
                                    this.messageHeader = MessageItems.productHeader;
                                    this.returnMessage.message = MessageItems.inactiveMessage;
                                    this.messageIconType = APP_CONSTANTS.ErrorIcon;
                                    this.displayMessage = true;
                                      this.isNoRecords = true;
                                    this.loading = false;
                                }
                            });
                        } else {
                            this.messageHeader = MessageItems.productHeader;
                            this.returnMessage.message = MessageItems.draftMessage;
                            this.messageIconType = APP_CONSTANTS.ErrorIcon;
                            this.displayMessage = true;
                              this.isNoRecords = true;
                            this.loading = false;
                        }
                    } else {
                        this.messageHeader = MessageItems.productHeader;
                        this.returnMessage.message = MessageItems.draftMessage;
                        this.messageIconType = APP_CONSTANTS.ErrorIcon;
                        this.displayMessage = true;
                          this.isNoRecords = true;
                        this.loading = false;
                    }
                });

        } else {
            this.messageHeader = MessageItems.erroHeader;
            this.returnMessage.message = MessageItems.draftMessage;
            this.messageIconType = APP_CONSTANTS.ErrorIcon;
            this.displayMessage = true;
            this.isNoRecords = true;
            this.loading = false;
            return;
        }
    }
    legacyIdChange() {
        this.isNoRecords = false;
    }
    facilityCheckBoxClick() {
        this.isNoRecords = false;
    }
}
