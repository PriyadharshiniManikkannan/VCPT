export const AppMenus = {
    menus:
    [
        {
            mainMenuName: 'Home',
            SubMenu: [],
            routePath: '/Home',
            tabIndex: 0,
            enabled: true
        },
        {
            mainMenuName: 'Product',
            routePath: '/Product/',
            tabIndex: 1,
            SubMenu: [
                {
                    label: 'Maintain Product',
                    routePath: 'MaintainProduct',
                    tabIndex: 2,
                    editable: true,
                    enabled: false
                },
                {
                    label: 'View Product List',
                    routePath: 'ViewProductMaster',
                    tabIndex: 3,
                    editable: false,
                    enabled: true
                },
                {
                    label: 'Maintain Product Configurations',
                    routePath: 'MaintainProductConfigurations',
                    tabIndex: 4,
                    editable: true,
                    enabled: false
                },
                {
                    label: 'View Product Configurations',
                    routePath: 'ViewProductConfigurations',
                    tabIndex: 5,
                    editable: false,
                    enabled: true
                }
            ],
            enabled: true
        },
        {
            mainMenuName: 'Packaging',
            routePath: '/Packaging/',
            tabIndex: 6,
            SubMenu: [
                {
                    label: 'Import Packaging Material',
                    routePath: 'ImportPackagingMaterial',
                    tabIndex: 7,
                    editable: true,
                    enabled: false
                },
                {
                    label: 'Add Obsolete Packaging Material',
                    routePath: 'AddObsoletePackagingMaterial',
                    tabIndex: 8,
                    editable: true,
                    enabled: false
                },
                {
                    label: 'View Packaging Materials List',
                    routePath: 'ViewAllPackagingMaterials',
                    tabIndex: 9,
                    editable: false,
                    enabled: true
                },
                {
                    label: 'Maintain Packaging Materials for Product',
                    routePath: 'MaintainPackagingMaterialsForProduct',
                    tabIndex: 10,
                    editable: true,
                    enabled: false
                },
                {
                    label: 'View Packaging Materials for Product',
                    routePath: 'ViewAllPackagingMaterialsforProduct',
                    tabIndex: 11,
                    editable: false,
                    enabled: true
                },
                {
                    label: 'Maintain Packaging Material for Product Configuration',
                    routePath: 'MaintainPackagingMaterialsForConfiguration',
                    tabIndex: 12,
                    editable: true,
                    enabled: false
                },
                {
                    label: 'View Packaging Materials for Product Configuration',
                    routePath: 'ViewAllPackagingMaterialsforConfigurations',
                    tabIndex: 13,
                    editable: false,
                    enabled: true
                }
            ],
            enabled: true
        },
        {
            mainMenuName: 'Reports',
            tabIndex: 14,
            routePath: '/Reports/',
            SubMenu: [
                {
                    label: 'Packaging Material - Where Used',
                    routePath: 'PackagingMaterialWhereUsed',
                    tabIndex: 15,
                    editable: true,
                    enabled: true
                },
                {
                    label: 'Show All Products with no Packaging Association',
                    routePath: 'AllProductsWithNoPackagingAssociation',
                    tabIndex: 16,
                    editable: false,
                    enabled: true
                },
                {
                    label: 'Extract All Data',
                    routePath: 'ExtractAllData',
                    tabIndex: 17,
                    editable: true,
                    enabled: true
                },
            ],
            enabled: true
        },
        {
            mainMenuName: 'Admin',
            routePath: '/Admin/',
            tabIndex: 18,
            SubMenu: [
                {
                    label: 'Maintain Product Characteristics',
                    routePath: 'MaintainProductCharacteristics',
                    tabIndex: 19,
                    editable: true,
                    enabled: true
                },
                {
                    label: 'Maintain UOMs',
                    routePath: 'MaintainUOM',
                    tabIndex: 20,
                    editable: true,
                    enabled: true
                }
            ],
            enabled: false
        }
    ]
};
