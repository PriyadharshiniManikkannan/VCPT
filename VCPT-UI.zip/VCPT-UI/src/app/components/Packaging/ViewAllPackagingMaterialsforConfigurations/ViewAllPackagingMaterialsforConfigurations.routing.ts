import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ViewAllPackagingMaterialsforConfigurationsComponent } from './ViewAllPackagingMaterialsforConfigurations.component';

const viewAllPackagingMaterialsforConfigurationsRoutes: Routes = [
    {
        path: '',
        component: ViewAllPackagingMaterialsforConfigurationsComponent
    },
    {
        path: ':id',
        component: ViewAllPackagingMaterialsforConfigurationsComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(viewAllPackagingMaterialsforConfigurationsRoutes)],
    exports: [RouterModule]
})
export class ViewAllPackagingMaterialsforConfigurationsRouteModule {

}
