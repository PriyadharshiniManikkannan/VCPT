import { environment } from './../../../environments/environment';
import { ANIMATION_TYPES } from 'ngx-loading';
export const APP_CONSTANTS = {
    ServerError: 'Server Error!',
    InformationIcon: 'fa fa-info-circle fa-2x',
    ErrorIcon: 'fa fa-times-circle fa-2x',
    WarningIcon: 'fa fa-exclamation-triangle fa-2x',
    UnsavedChangesMessage: 'You have unsaved change(s) on this screen which will be lost. Are you sure you want to continue?',
    loaderConfig: {
        fullScreenBackdrop: true,
        animationType: ANIMATION_TYPES.rectangleBounce,
        primaryColour: '#008899',
        secondaryColour: '#008899',
        tertiaryColour: '#008899',
        backdropBackgroundColour: 'rgba(227, 245, 246, 0.5)'
    },
    recordsPerPageConstant: 25,
    defaultLocaleString: 'en-US',
    adminMenuName: 'ADMIN',
    globalDecimalPlace: 5,
};

export const SessionConstants = {
    userId: 'USERNAME',
    userFullName: '',
    userToken: 'SMSESSION',
    cookieHeaderName: 'Cookie'
};

export const Url = {
    /**
     * Internal URL
     */
    notAuthorized: '/notAuthorized',
    error: '/error',
    homeUrl: '/Home',

    HelpFileUrl: 'HelpFile',
    LogoutUrl: environment.logOutUrl,

    /**
     * API URLs
     */

    // Common URL Constants
    GGSMStatusesUrl: 'ggsm/statuses',
    VCPTStatusesUrl: 'vcpt/statuses',
    UserDetailsUrl: 'security/user',
    FacilitiesUrl: 'facilities',
    HelpFileRouteUrl: 'helpfile',

    // Admin Module URL Constants
    UomDetailsUrl: 'admin/uom',
    CharacteristicDetailsUrl: 'admin/characteristic',

    // Product Module URL Constants
    ProductDetailsUrl: 'product',
    UnlockProductUrl: 'product/unlock',
    ProductSearchUrl: 'product/search',
    FacilitiesByProductUrl: 'product/facilities',
    ProductConfigurationsUrl: 'product/configurations',
    ProductConfigurationUrl: 'product/configuration',
    CharacteristicsForProductUrl: 'product/characteristics',
    CharacteristicsForProductConfigurationUrl: 'product/configuration/characteristics',
    CharacteristicsForProductConfigurationNoLockUrl: 'product/configuration/characteristics/no-lock',
    UnlockProductConfigUrl: 'product/configuration/unlock',
    ReplicateProductConfigDetailUrl: 'product/configuration/replicate',
    UnlockConfigFacilityUrl: 'product/configuration/facility/unlock',

    // Packaging Materials Module URL Constants
    PackagingMaterialDetailsUrl: 'packaging-materials',
    ImportPackagingMaterialUrl: 'packaging-material/import',
    CheckActiveConfigurationExistsforProductUrl: 'product/configurations/active-count',
    ImportObsoletePackagingMaterial: 'packaging-material/obsolete/import',
    AssociatedPackagingMaterialUrl: 'product/packaging-materials',
    AssociatedPackagingMaterialExportUrl: 'product/packaging-materials/export',
    ActivatePackagingMaterialUrl: 'packaging-material/activate',
    InactivatePackagingMaterialUrl: 'packaging-material/inactivate',
    PackagingMaterialForProductUrl: 'product/packaging-material',
    PackagingMaterialforProductConfiguration: 'product/configuration/packaging-materials',
    DisassociatePackagingMaterialForProductUrl: 'product/packaging-material/disassociate',
    DisassociatePackagingMaterialforProductConfiguration: 'product/configuration/packaging-materials/disassociate',
    PackagingMaterialforProductConfigurationInExportFormat: 'product/configuration/packaging-materials/export',
    ActiveProductUrl: 'product/active',
    ActiveProductWithNoLockUrl: 'product/active/no-lock',
    PackagingMaterialForProductConfigurationNoLockUrl: 'product/configuration/packaging-materials/no-lock',

    // Reports Module URL Constants
    ActiveProductsAssociatedforPackagingMaterialUrl: 'report/packaging-materials-where-used/product',
    ActiveProductConfigurationforPackagingMaterialUrl: 'report/packaging-materials-where-used/product/configurations',
    ProductWithNoPackagingMaterialUrl: 'report/products/no-packaging-materials',
    ProductWithNoPackagingMaterialExportUrl: 'report/products/no-packaging-materials/export',
    ProductAndProductConfigCountForPackagingMaterialUrl: 'report/packaging-materials-where-used/products-and-configurations-count',
    ExtractAllDataUrl: 'report/extract-all-data',
};
export const ConstantValues = {
    productDataType: 'Text',
    statusActive: 'ACTIVE',
    statusInActive: 'INACTIVE',
    statusObsolete: 'OBSOLETE',
    sapRelevancy: 'VC Identified SAP Configurable ID',
    statusActiveCode: 'A',
    statusInActiveCode: 'I',
    statusObsoleteCode: 'O',
    productStatusActiveCode: 12,
    productStatusInActiveCode: 13,
    productStatusDraftCode: 11,
    defaultDropDownOption: 'All',
    productLegacyIDLength: 11,
    productStatusInActive: 'INACTIVE',
    productStatusDraft: 'DRAFT',
    productStatusActive: 'ACTIVE',
    productUnavailableMessage: 'This Product Legacy ID is unavailable.  Kindly enter a different ID.',
    productCharacteristicRequired: 'Kindly select at least 1 product characteristic.',
    containsFilter: 'contains',
    equalsFilter: 'equals',
    isRangeTrue: true,
    isRangeFalse: false,
    trueValue: 'Yes',
    falseValue: 'No',
    textDataTypeValue: 'Text',
    numericDataTypeValue: 'Numeric'

};


export const excludeColumns = {
    columns: ['Product Legacy Id', 'Product Description', 'Product Code',
        'Product Comments', 'ProductId', 'ProdConfigId', 'VCPTConfigurationStatus'],
    dynamicColumns: ['Product Legacy Id', 'Product Description', 'Product Code', 'Product Comments', 'ProductId',
        'ProdConfigId', 'Status', 'ConfigurationComments', 'Facility', 'VCPTConfigurationStatus'],
    hiddenColumns: ['ProductId', 'ProdConfigId', 'Configuration Comments', 'Facility', 'VCPT Configuration Status'],
    RangeColumns: ['Numeric'],
    NonRangeDataType: ['Text']
};
export const containsSearchfilterColumns = {
    columns: ['Product Description', 'productCharacteristic(s)', 'Product Comments', 'Facility', 'sAPBasicDataText',
        'packagingMaterialDescription', 'Configuration Comments']
};
export const RouteURLs = {
    MaintainProductPath: '/Product/MaintainProduct',
    MaintainProductConfigurationsPath: '/Product/MaintainProductConfigurations',
    ViewProductConfigurationsPath: '/Product/ViewProductConfigurations',
    ViewPackagingMaterialsPath: '/Packaging/ViewAllPackagingMaterials',
    ViewPackagingMaterialsforProductPath: '/Packaging/ViewAllPackagingMaterialsforProduct',
    ViewPackagingMaterialsConfigurationPath: '/Packaging/ViewAllPackagingMaterialsforConfigurations',
    MaintainPackagingMaterialsPath: '/Packaging/MaintainPackagingMaterialsForProduct',
    MaintainPackagingMaterialsConfigurationPath: '/Packaging/MaintainPackagingMaterialsForConfiguration'

};
export const StatusCode = {

    successCode: '200',
    duplicateCode: '201',
    mismatchCode: '202'
};

export const MessageItems = {

    saveMessage: 'Details Saved Successfully',
    saveandActivateMessage: 'Details Saved and Activated Successfully',
    draftMessage: 'This Product Legacy ID is unavailable.  Kindly enter a different ID.',
    inactiveMessage: 'This Product Legacy ID is Inactive. Kindly enter a different ID.',
    characteristicMessage: 'Kindly enter value for at least one characteristic to save the configuration for the product.',
    duplicateConfigurationMessage: 'This Configuration already exists. Do you want to edit it?',
    facilityMessage: 'Kindly select at least 1 facility.',
    characteristicMismatchMessage: 'Could not save as the product details have changed. Kindly try again.',
    inactivateMessage: 'You have not selected any facility. This would inactivate the configuration. Are you sure you want to continue?',
    productSearchMessage: 'Kindly select either one facility or enter a product legacy id to narrow down the search.',
    noResultsMessage: 'No Results found',
    uomMessage: 'This UOM already exists. Kindly enter again.',
    duplicateCharacteristicsMessage: 'This Product Characteristic already exists. Kindly enter again.',
    erroHeader: 'Error',
    productHeader: 'Product Details',
     packagingHeader: 'Packaging Details',
    saveHeader: 'Save',
    saveandactivate: 'Save and Activate',
    saveDraftHeader: 'Save as Draft',
    errorMessgae: 'Server Error',
    characteristicsChangeMessage: 'You have changed characteristic(s) information, kindly remember to review the existing packaging associations (if any) for this configuration.',
    duplicateUOMMessage: 'This UOM already exists. Kindly enter again.',
    packagingIdSearchMessage: 'This Packaging Material Legacy ID is unavailable. Kindly enter a different ID.',
    packagingIdEmptyMessage: 'Kindly Enter a value for Packaging Material Legacy ID to Search the Packaging Matertial',
    packagingIdImportEmptyMessage: 'Kindly enter a value for Packaging Material Legacy ID to Import the Packaging Matertial',
    packagingIdAddObsoleteEmptyMessage: 'Kindly enter a value for Packaging Material Legacy ID to Save and Activate',
    packagingQuantityUOMEmptyMessage: 'Kindly enter a value for Quantity UOM to Save and Activate the Packaging Matertial',
    packagingUOMandLegacyEmptyMessage: 'Kindly enter the value for Packaging Material Legacy ID and Qunatity UOM  to Save and Activate the Packaging Matertial',
    packagingAssociationDeleteMessage: 'You are about to remove/delete a packaging material association. Are you sure you want to continue?',
    quantityEmptyMessage: 'Kindly enter a Value for Quantity to Save the Associate Packaging Material Details',
    scrapEmptyMessage: 'Kindly enter a Value for Scrap% to Save the Associate Packaging Material Details',
    packagingLegacyEmptyMessage: 'Kindly enter a value for Packaging Material Legacy ID',
    productUnlockError: 'An error occured while trying to unlock product for others to Edit.',
    emptyUOMMessage: 'Kindly Select the UOM  Where the  Characteristcs Value  is non Empty',
    emptyLegacyIdMessage: 'Kindly enter a value for LegacyId and try again.',
    characteristicEmptyMessage: 'Please enter the name for characteristic.',
    uomEmptyMessage: 'Please select at least one UOM.',
    dataTypeEmptyMessage: 'Please select DataType.',
    uomNameEmptyMessage: 'Please enter the Name.',
    uomCodeEmptyMessage: 'Please enter UOM code.',
    maxMessage: 'Please Enter Max value greater than Min Value',
    minMessage: 'Please Enter  Min value less than Max Value',
    equalsMessage: 'Min and Max Value should not be same',
    emptyMinValueMessage: 'Kindly enter the Min Value for the row where the max Value is Non empty to save the Configuration',
    minValueZeroMessage: 'Kindly enter Min Value greater than 0',
    emptyMaxValueMessage: 'Kindly enter the Max Value for the row where the min Value is Non empty to save the Configuration',
    maxValueZeroMessage: 'Kindly enter Max Value greater than 0',
    packagingIdInactiveMessage: 'This Packaging Material Legacy ID is inactive. Kindly enter a different ID.',
    removeCharacteristicsMessage: 'Note: In order to remove a characteristic make the value as empty.'
};
export const DataTypeDropdown = {
    DataTypes: ['', 'Numeric', 'Text']
};
