import { CommonUtilitiesComponent } from './../../../shared/components/common-utilities/common-utilities.component';
import { SecurityService } from './../../../services/Security.service';
import { VCPTStatusModel } from './../../../models/VCPTStatus.model';
import { GGSMStatusModel } from './../../../models/GGSMStatus.model';
import {
    RouteURLs, APP_CONSTANTS,
    ConstantValues, StatusCode, MessageItems, Url
} from './../../../shared/constants/app.constants';
import { Observable } from 'rxjs/Observable';
import { ProductSearchModel } from './../../../models/SearchCriteria.model';
import { element } from 'protractor';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { utils, write, WorkBook } from 'xlsx';
import { saveAs } from 'file-saver';
import { MessageModel } from './../../../models/MessageModel.model';
import { ViewAllPackagingMaterialService } from './../../../services/packaging/ViewAllPackagingMaterials.service';
import { PackagingMaterial } from './../../../models/PackagingMaterial.model';
import { FormLabelValues, ScreenTitles } from './../../../shared/constants/form.constants';

import { Message, DialogModule, ButtonModule, RadioButtonModule } from 'primeng/primeng';
import { ConfirmationService } from 'primeng/primeng';

@Component(
    {
        templateUrl: './ViewAllPackagingMaterials.Component.html',
        styleUrls: ['./ViewAllPackagingMaterials.Component.scss']
    }
)
export /**
 * ViewAllPackagingMaterialsComponent
 */
    class ViewAllPackagingMaterialsComponent implements OnInit {
    selectedVcptStatus: any;
    selectedmaterailLifeCycleStatus: any;
    displayGrid: boolean;
    cols: any[];
    err: any;
    legacyID: string;
    MaterialDesc: string;
    SAPText: string;
    QuantityUOM: string;
    materailLifeCycleStatus: GGSMStatusModel[];
    vcptStatus: VCPTStatusModel[];
    viewPackagingMaterial: any;
    message: boolean;
    defaultDropDownOption: string;
    disabled: boolean;
    selectedRow: any;
    recordsPerPage: number;
    firstRecordIndexofGrid: number;
    messageHeader: string;
    messageIconType: string;
    readOnlyUser: boolean;
    displayMessage: boolean;
    returnMessage: MessageModel;
    formLabels: any;
    formTitle: any;
    packagingMaterialID: number;
    packagingDetailsExcel: any[];
    isActive: boolean;
    isInActive: boolean;
    userDetails: any;
    ConstantValues: any;
    // Loading Variable for ngx-Loading component.
    public loading = false;

    constructor(private viewAllPackagingMaterialService: ViewAllPackagingMaterialService,
        private router: Router,
        private confirmationService: ConfirmationService,
        private activatedRoute: ActivatedRoute,
        private securityService: SecurityService
    ) { }
    ngOnInit() {
        this.ConstantValues = ConstantValues;
        this.formLabels = FormLabelValues;
        this.loading = true;
        this.initializeForm();
        this.loading = true;
        this.readOnlyUser = this.securityService.isReadOnlyUser();
        this.activatedRoute.params.subscribe((params: Params) => {
            this.legacyID = params['id'];
        }, (error: Error) => {
            this.router.navigate([Url.error]);
            this.loading = false;
        }
        );
        Observable.forkJoin(
            this.viewAllPackagingMaterialService.getStatus(),
            this.viewAllPackagingMaterialService.getProductStatus())
            .subscribe((results: any) => {
                this.materailLifeCycleStatus = results[0];
                this.selectedmaterailLifeCycleStatus = ConstantValues.statusActiveCode;
                this.vcptStatus = results[1];
                if (this.vcptStatus.length !== 0) {
                    if (this.vcptStatus[0].statusCode === ConstantValues.productStatusDraftCode) {
                        this.vcptStatus.splice(0, 1);
                    }
                }
                this.selectedVcptStatus = ConstantValues.productStatusActiveCode;
                if (this.legacyID !== '' && this.legacyID !== undefined) {
                    this.getPackagingDetails();
                } else {
                    this.loading = false;
                }

            }, (error: Error) => {
                this.router.navigate([Url.error]);
                this.loading = false;
            }
            );
    }
    initializeMessage() {
        this.returnMessage = new MessageModel();
        this.messageHeader = '';
        this.returnMessage.listofItemsforDisplay = [];
        this.returnMessage.message = '';
        this.returnMessage.messageCode = '';
    }
    initializeForm() {
        this.loading = true;
        this.formTitle = ScreenTitles;
        this.MaterialDesc = '';
        this.SAPText = '';
        this.legacyID = '';
        this.cols = [];
        this.viewPackagingMaterial = [];
        this.returnMessage = new MessageModel();
        this.displayGrid = false;
        this.defaultDropDownOption = ConstantValues.defaultDropDownOption;
        this.selectedmaterailLifeCycleStatus = ConstantValues.statusActiveCode;
        this.selectedVcptStatus = ConstantValues.productStatusActiveCode;
        this.recordsPerPage = APP_CONSTANTS.recordsPerPageConstant;
        this.firstRecordIndexofGrid = 1;
        this.enableDisableButtons();
        this.loading = false;

    }
    showResults(): void {
        this.isActive = true;
        this.isInActive = true;
        this.getPackagingDetails();
    }
    getPackagingDetails() {
        this.loading = true;
        this.viewPackagingMaterial = [];
        const jsonParam = this.getSearchCriteria();
        this.viewAllPackagingMaterialService.getAllPackagingDetails(jsonParam).
            subscribe((viewPackagingMaterial: any) => {
                this.viewPackagingMaterial = viewPackagingMaterial;
                if (this.viewPackagingMaterial.length !== 0) {
                    this.getColumnforGrid(this.viewPackagingMaterial);
                    this.displayGrid = true;
                } else {
                    this.displayGrid = false;
                }
                this.enableDisableButtons();
            }, (err: any) => {
                this.err = err;
                if (err !== undefined) {
                    this.initializeMessage();
                    this.router.navigate([Url.error]);
                    this.enableDisableButtons();
                }
            }, () => this.loading = false);

        this.loading = false;
    }
    getColumnforGrid(obj: any): void {
        if (obj && obj.length) {
            const keys = Object.keys(obj[0]);
            const cols = [];
            keys.forEach(function (k: any) {
                let s = '';
                s = k.split('_').join(' ');
                if (k.toString().toLowerCase() === FormLabelValues.sapText.toString().toLowerCase()) {
                    s = FormLabelValues.sapText;
                }
                if (k.toString().toLowerCase() === FormLabelValues.vcptPackagingStatus.toString().toLowerCase()) {
                    s = FormLabelValues.vcptPackagingStatus;
                }
                if (k.toString().toLowerCase() !== FormLabelValues.packagingMaterialId.toString().toLowerCase()) {
                    cols.push({ field: k, header: s });
                }

            });
            this.cols = cols;
        }
    }
    s2ab(s) {
        const buf = new ArrayBuffer(s.length);
        const view = new Uint8Array(buf);
        for (let i = 0; i !== s.length; ++i) {
            view[i] = s.charCodeAt(i) & 0xFF;
        }
        return buf;
    }
    getIConforMessageDisplay() {
        switch (this.returnMessage.messageType.trim().toUpperCase()) {
            case 'Error'.toUpperCase(): this.messageIconType = APP_CONSTANTS.ErrorIcon;
                this.messageHeader = MessageItems.erroHeader; break;
            case 'Information'.toUpperCase(): this.messageIconType = APP_CONSTANTS.InformationIcon;
                this.messageHeader = MessageItems.saveHeader; break;
            case 'Warning'.toUpperCase(): this.messageIconType = APP_CONSTANTS.WarningIcon; break;
            default: this.messageIconType = APP_CONSTANTS.InformationIcon; break;
        }
    }
    markasInactive() {
        if (typeof this.selectedRow !== 'undefined' && this.selectedRow !== null) {
            if (this.selectedRow.vcpt_Material_Status.toLowerCase()
                === ConstantValues.productStatusActive.toLowerCase()) {
                this.isInActive = false;
                this.isActive = true;
            } else {
                this.isInActive = true;
                this.isActive = false;
            }
        }

    }
    inActivate() {
        if (typeof this.selectedRow !== 'undefined' && this.selectedRow !== null) {
            if (this.selectedRow.vcpt_Material_Status.toLowerCase()
                === ConstantValues.productStatusActive.toLowerCase()) {
                if (this.selectedRow.packagingMaterialID !== 0 && this.selectedRow.packagingMaterialID !== undefined) {
                    this.viewAllPackagingMaterialService.markasInactive(this.selectedRow.packagingMaterialID).
                        subscribe((returnMessage: MessageModel) => {
                            this.initializeMessage();
                            this.returnMessage.message = returnMessage.message;
                            this.returnMessage.messageType = returnMessage.messageType;
                            this.getIConforMessageDisplay();
                            this.displayMessage = true;
                            this.isInActive = true;
                            this.isActive = true;
                            this.selectedRow = 'undefined';
                            this.getPackagingDetails();
                            this.packagingMaterialID = 0;
                            return;
                        }, (err: any) => {
                            this.err = err;
                            if (err !== undefined) {
                                this.initializeMessage();
                                this.router.navigate([Url.error]);
                            }
                        }, () => this.loading = false);
                }
            }
        }

        this.loading = false;
    }

    activate() {
       if (typeof this.selectedRow !== 'undefined' && this.selectedRow !== null) {
            if (this.selectedRow.vcpt_Material_Status.toLowerCase()
                !== ConstantValues.productStatusActive.toLowerCase()) {
                if (this.selectedRow.packagingMaterialID !== 0 && this.selectedRow.packagingMaterialID !== undefined) {
                    this.viewAllPackagingMaterialService.markasActive(this.selectedRow.packagingMaterialID).
                        subscribe((returnMessage: MessageModel) => {
                            this.initializeMessage();
                            this.returnMessage.message = returnMessage.message;
                            this.returnMessage.messageType = returnMessage.messageType;
                            this.getIConforMessageDisplay();
                            this.displayMessage = true;
                            this.isInActive = true;
                            this.isActive = true;
                            this.selectedRow = 'undefined';
                            this.getPackagingDetails();
                            this.packagingMaterialID = 0;
                            return;
                        }, (err: any) => {
                            this.err = err;
                            if (err !== undefined) {
                                this.initializeMessage();
                                this.router.navigate([Url.error]);
                            }
                        }, () => this.loading = false);
                }
            }
        }

        this.loading = false;
    }
    exportExcel() {
        let timestamp = '';
        timestamp = CommonUtilitiesComponent.getCurrentDateTimeStamp();
        const sheetName = 'ViewPackagingMaterialsList' + '_' + timestamp + '.xlsx';
        this.loading = true;
        this.packagingDetailsExcel = [];
        const ws_name = 'Packaging_Details';
        const wb: WorkBook = { SheetNames: [], Sheets: {} };
        this.viewPackagingMaterial.forEach(element => {
            this.packagingDetailsExcel.push({
                'Packaging Material Legacy ID': element.packaging_Legacy_ID,
                'Packaging Material Description': element.packaging_Material_Description,
                'Sap Basic Data Text': element.sap_Basic_Data_Text,
                'Quantity UOM': element.quantity_UOM,
                'VCPT Material Status': element.vcpt_Material_Status,
                'Packaging Material LifeCycle Status': element.packaging_Material_LifeCycle_Status
            });
        });
        const ws: any = utils.json_to_sheet(this.packagingDetailsExcel);
        wb.SheetNames.push(ws_name);
        wb.Sheets[ws_name] = ws;
        const wbout = write(wb, { bookType: 'xlsx', bookSST: true, type: 'binary' });
        this.loading = false;
        saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), sheetName);
    }
    getSearchCriteria(): any {
        const searchSet = new PackagingMaterial();
        searchSet.packagingMaterialLegacyID = this.legacyID;
        if (this.MaterialDesc === undefined || this.MaterialDesc === '') {
            searchSet.packagingMaterialDescription = '';

        } else {
            searchSet.packagingMaterialDescription = this.MaterialDesc;

        }
        if (this.legacyID === undefined || this.legacyID === '') {
            searchSet.packagingMaterialLegacyID = '';

        } else {
            searchSet.packagingMaterialLegacyID = this.legacyID;

        }
        if (this.SAPText === undefined || this.SAPText === '') {
            searchSet.sapBasicDataText = '';
        } else {
            searchSet.sapBasicDataText = this.SAPText;
        }
        if (this.selectedmaterailLifeCycleStatus.trim() === ConstantValues.defaultDropDownOption) {
            searchSet.materialBusinessLifeCycleStatus.statusCode = '';

        } else {
            searchSet.materialBusinessLifeCycleStatus.statusCode = this.selectedmaterailLifeCycleStatus;
        }
        if (this.selectedVcptStatus === ConstantValues.defaultDropDownOption) {
            searchSet.vcptMaterialStatus.statusCode = 0;

        } else {
            searchSet.vcptMaterialStatus.statusCode = this.selectedVcptStatus;
        }
        const jsonParam: any = {
            'packagingMaterialLegacyID': searchSet.packagingMaterialLegacyID,
            'packagingMaterialDescription': searchSet.packagingMaterialDescription,
            'sapBasicDataText': searchSet.sapBasicDataText,
            'packagingMaterialLifeCycleStatus': searchSet.materialBusinessLifeCycleStatus.statusCode,
            'vcptMaterialStatus': searchSet.vcptMaterialStatus.statusCode

        };
        return jsonParam;
    }
    onGridPageChange(event: any) {
        this.firstRecordIndexofGrid = event.first === 1 ? event.first : event.first + 1;
        this.recordsPerPage = event.first !== 1 ? event.rows + event.first : event.rows;
    }
    enableDisableButtons() {
        if (this.readOnlyUser) {
            this.isActive = true;
            this.isInActive = true;
            this.disabled = true;
        } else {
            this.markasInactive();
            this.disabled = false;
        }
    }

}

