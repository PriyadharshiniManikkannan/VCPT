export class MaintainProductConfigurations {
    productLegacyId: string;
    productDescription: string;
    sapRelevancyStatus: string;
    productCode: string;
    dataType: string;
    facilityCollection: string;
    productStatus: string;
    productComments: string;
    productId: string;
    configurationComments: string;
    configComments: string;
    facility: string;
    productConfiguration: any[];
    configurationFacility: any[];
    productConfigurationStatus: any;
    createdBy: string;
    modifiedBy: string;
    lockedBy: string;
    productConfigId: any;
    productBusinessLifeCycleStatus: any;
    getOnlyActiveConfiguration: boolean;
    public constructor() {
        this.productLegacyId = '';
        this.productDescription = '';
        this.sapRelevancyStatus = '';
        this.productCode = '';
        this.productComments = '';
        this.getOnlyActiveConfiguration = false;
    }
}
export class UOM {
    uomId: any;
    uomName: string;
}

