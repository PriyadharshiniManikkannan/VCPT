import { Observer } from 'rxjs/Observer';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { UnsavedChangesComponent } from './../../../shared/components/UnsavedChanges/UnsavedChanges.component';
import { MessageModel } from './../../../models/MessageModel.model';
import { CanComponentDeactivate } from './../../../services/guards/CanComponentDeactivate.guard.service';
import { APP_CONSTANTS, ConstantValues, MessageItems, Url } from './../../../shared/constants/app.constants';
import { CharacteristicsListBoxModel, ProductDetails } from './../../../models/MaintainProduct.model';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MaintainProductService } from './../../../services/product/MaintainProduct.service';
import { SelectItem, Message, ConfirmationService } from 'primeng/primeng';
import { Component, OnInit, HostListener } from '@angular/core';
import { FormLabelValues, ScreenTitles } from './../../../shared/constants/form.constants';


@Component(
    {
        templateUrl: './MaintainProduct.component.html',
        styleUrls: ['./MaintainProduct.component.scss']
    }
)
export /**
 * MaintainProduct
 */
    class MaintainProductComponent implements OnInit, CanComponentDeactivate {
    facilities: SelectItem[];
    characteristics: SelectItem[];
    selectedCharacteristics: number[];
    productDescription: string;
    productCode: string;
    disableSaveAsDraftButton: boolean;
    disableSaveandActivateButton: boolean;
    displayMessage = false;
    messageHeader: string;
    formLabels: any;
    productDetails: ProductDetails;
    maintainProductForm: FormGroup;
    returnMessage: MessageModel;
    previousLegacyId: string;
    previousProductId: number;
    unsavedChangesComponent: UnsavedChangesComponent;
    productSearchForm: FormGroup;
    saveAndActivateButtonName: string;
    hideDraftButton: boolean;
    messageIconType: string;
    showOkButton: boolean;
    formTitle: any;
    // Loading variable for ngx-loading component
    public loading = false;

    constructor(
        private activatedRoute: ActivatedRoute,
        private maintainProductService: MaintainProductService,
        private confirmationService: ConfirmationService,
        private formBuilder: FormBuilder,
        private router: Router) {
    }
    ngOnInit() {
        this.loading = true;
        this.formLabels = FormLabelValues;
        this.buildForm();
        this.initializeForm(true);
        this.activatedRoute.params.subscribe((params: any) => {
            if (params) {
                if (params['legacyId'] && params['legacyId'] !== '') {
                    this.productSearchForm.get('productLegacyID').patchValue(params['legacyId']);
                    this.loading = true;
                    this.getDetails();
                }
            }
        });
    }
    /**
     * Method: buildForm
     *
     * Usage: Used to build Reactive formcontrol and group them.
     */
    buildForm() {
        this.productSearchForm = this.formBuilder.group({ productLegacyID: new FormControl('') });
        this.maintainProductForm
            = this.formBuilder.group({
                productDescription: new FormControl({ value: '' }, []),
                productCode: new FormControl({ value: '' }, []),
                sapRelevancyStatus: new FormControl({ value: '' }, []),
                productBusinessLifeCycleStatus: new FormControl({ value: '' }, []),
                applicableFacilities: new FormControl({ value: '', disabled: 'true' }, []),
                applicableCharacteristics: new FormControl({ value: [] }),
                productComments: new FormControl({ value: '' }, []),
                productStatus: new FormControl({ value: '' }, [])
            });
    }
    /**
     * Method: getDetails
     *
     * Usage: Used to get the required details from database.
     */
    getDetails() {
        this.loading = true;
        if (this.productSearchForm.get('productLegacyID').value
            && this.productSearchForm.get('productLegacyID').value.toString().trim().toUpperCase() !== '') {
                this.getCharacteristics().subscribe((characteristicsJson: CharacteristicsListBoxModel[]) => {
                    this.characteristics = [];
                    characteristicsJson.forEach(characteristics => {
                        this.characteristics.push({
                            label: characteristics.characteristicName,
                            value: characteristics.characteristicId
                        });
                    });
                }, (error: Error) => {
                    this.router.navigate([Url.error]);
                });

            this.setPreviousProdid();
            if (this.previousLegacyId === '' || this.previousLegacyId === null) {
                this.previousLegacyId = this.productSearchForm.get('productLegacyID').value;
                if (this.previousProductId !== 0) {
                    this.setPreviousProdid();
                    this.unlockProductforEdit();
                }
                this.maintainProductForm.reset();
                this.getProductDetails();
            } else {
                if (this.previousLegacyId.trim().toUpperCase() !==
                    this.productSearchForm.get('productLegacyID').value.trim().toUpperCase()) {
                    if (this.checkDirtyForm()) {
                        this.getUserConfirmation().subscribe((userInput: boolean) => {
                            if (userInput) {
                                this.previousLegacyId = this.productSearchForm.get('productLegacyID').value;
                                this.maintainProductForm.reset();
                                this.setPreviousProdid();
                                this.unlockProductforEdit();
                                this.getProductDetails();
                            }
                        });
                    } else {
                        this.previousLegacyId = this.productSearchForm.get('productLegacyID').value;
                        this.setPreviousProdid();
                        this.unlockProductforEdit();
                        this.getProductDetails();
                    }
                } else {
                    if (this.checkDirtyForm()) {
                        this.getUserConfirmation().subscribe((userInput: boolean) => {
                            if (userInput) {
                                this.maintainProductForm.reset();
                                this.getProductDetails();
                            }
                        });
                    } else {
                        this.getProductDetails();
                    }
                }
            }
        } else {
            this.initializeMessage();
            this.messageHeader = 'Get Product Details';
            this.returnMessage.message = 'Kindly enter a value for Product Legacy ID to Search.';
            this.messageIconType = APP_CONSTANTS.ErrorIcon;
            this.displayMessage = true;
            this.loading = false;
            return;
        }
    }

    getProductDetails() {
        this.loading = true;
        const params: any = {};
        if (this.productSearchForm.get('productLegacyID').value !== null
            && this.productSearchForm.get('productLegacyID').value.toString().trim() !== '') {
            params.legacyId = this.productSearchForm.get('productLegacyID').value;
        } else {
            this.loading = false;
            return;
        }
        this.maintainProductService
            .getProductDetails(params)
            .subscribe((productDetails: any) => {
                if (productDetails && productDetails.message) {
                    this.initializeMessage();
                    this.messageHeader = 'Get Product Details';
                    this.returnMessage.messageCode = productDetails.messageCode;
                    if (productDetails.listofItemsforDisplay) {
                        productDetails.listofItemsforDisplay.forEach(message =>
                            this.returnMessage.listofItemsforDisplay.push(message));
                    }
                    this.returnMessage.message = productDetails.message;
                    this.returnMessage.messageType = productDetails.messageType;
                    this.getIconforMessageDisplay();
                    this.displayMessage
                        = this.returnMessage.message !== '' && this.returnMessage.message !== null ? true : false;
                    this.initializeForm(false);
                } else {
                    if (productDetails && productDetails.productId && productDetails.productId !== 0) {
                        this.facilities = [];
                        this.selectedCharacteristics = [];
                        this.productDetails = new ProductDetails();
                        this.productDetails = productDetails;
                        this.productDetails.applicableFacilities.sort(function (a, b) {
                            return a.facilityName.localeCompare(b.facilityName);
                        });
                        this.productDetails.applicableFacilities
                            .forEach(facility =>
                                this.facilities.push({ label: facility.facilityName, value: facility.facilityID })
                            );

                        this.productDetails.applicableCharacteristics.forEach(characteristic => {
                            this.selectedCharacteristics.push(characteristic.characteristicId);
                        });
                        this.maintainProductForm.patchValue(this.productDetails);
                        this.maintainProductForm.get('productStatus').patchValue(this.productDetails.vcptProductStatus.statusDesc);
                        this.maintainProductForm.get('productBusinessLifeCycleStatus')
                            .patchValue(this.productDetails.productBusinessLifeCycleStatus.statusDesc);
                        this.maintainProductForm.get('applicableCharacteristics')
                            .patchValue(this.selectedCharacteristics);
                        this.enableDisableControls();
                    } else {
                        /** If empty model is returned there is some kind of error.*/
                        this.router.navigate([Url.error]);
                        this.loading = false;
                    }
                }
            }, (error: Error) => {
                this.router.navigate([Url.error]);
                this.loading = false;
            });
    }

    /**
     * Method: saveAsDraft
     *
     * Usage: Used to Save the Product as Draft.
     */
    saveAsDraft() {
        this.saveDetails(true);
    }

    /**
     * Method: saveAsActive
     *
     * Usage: Used to Save the Product as Active.
     */
    saveAsActive() {

        // Validate at least one applicable characteristic is available for activation.
        if (!this.validateProductCharacteristicsToActivate()) {
            this.initializeMessage();
            this.messageHeader = this.saveAndActivateButtonName;
            this.returnMessage.message = ConstantValues.productCharacteristicRequired;
            this.messageIconType = APP_CONSTANTS.ErrorIcon;
            this.displayMessage = true;
            return false;
        } else {
            this.loading = true;
        }
        let characteristicsAdded = false;
        if (this.maintainProductForm.get('applicableCharacteristics').value
            .filter(characteristicId => this.selectedCharacteristics
                .indexOf(characteristicId) < 0).length > 0) {
            characteristicsAdded = true;
        }
        if (characteristicsAdded) {
            const params: any = {};
            params.productId = this.productDetails.productId;
            this.maintainProductService
                .checkActiveConfigurationExistsforProduct(params)
                .subscribe((messagefromAPI: MessageModel) => {
                    this.initializeMessage();
                    this.returnMessage = messagefromAPI;
                    if (this.returnMessage.message && this.returnMessage.message.trim().length > 0) {
                        this.loading = false;
                        this.showOkButton = true;
                        this.confirmationService.confirm({
                            message: this.returnMessage.message,
                            icon: APP_CONSTANTS.WarningIcon,
                            header: this.saveAndActivateButtonName,
                            accept: () => {
                                this.loading = true;
                                this.saveDetails(false);
                                this.showOkButton = false;
                            }
                        }
                        );
                    } else {
                        this.saveDetails(false);
                    }

                }, (err: Error) => {
                    this.router.navigate([Url.error]);
                    this.loading = false;
                });
        } else {
            this.saveDetails(false);
        }

    }

    initializeForm(initializeMessage: boolean) {
        this.loading = true;
        this.facilities = [];
        this.characteristics = [];
        this.selectedCharacteristics = [];
        this.disableSaveAsDraftButton = true;
        this.disableSaveandActivateButton = true;
        this.productDescription = '';
        this.productCode = '';
        this.saveAndActivateButtonName = 'Save and Activate';
        this.hideDraftButton = false;
        this.productDetails = new ProductDetails();
        this.previousLegacyId = '';
        this.showOkButton = false;
        this.formTitle = ScreenTitles;
        this.previousProductId = 0;
        if (initializeMessage) {
            this.initializeMessage();
        }
        this.unsavedChangesComponent = new UnsavedChangesComponent(this.confirmationService);
        this.maintainProductForm.patchValue(this.productDetails);
        this.maintainProductForm.get('productStatus').patchValue(this.productDetails.vcptProductStatus.statusDesc);
        this.maintainProductForm.get('productBusinessLifeCycleStatus')
            .patchValue(this.productDetails.productBusinessLifeCycleStatus.statusDesc);
        this.loading = true;
        this.getCharacteristics().subscribe((characteristicsJson: CharacteristicsListBoxModel[]) => {
            this.characteristics = [];
            characteristicsJson.forEach(characteristics => {
                this.characteristics.push({
                    label: characteristics.characteristicName,
                    value: characteristics.characteristicId
                });
            });
        }, (error: Error) => {
            this.router.navigate([Url.error]);
            this.loading = false;
        }, () => this.loading = false);
        this.enableDisableControls();
    }
    getCharacteristics(): Observable<any> {
        return this.maintainProductService.getCharacteristicsDetails();
    }
    enableDisableControls() {
        this.loading = true;
        this.maintainProductForm.get('applicableFacilities').disable();
        if (this.productDetails && this.productDetails.productId !== 0) {
            this.maintainProductForm.get('productComments').enable();
            this.maintainProductForm.get('applicableCharacteristics').enable();
            if (this.productDetails.vcptProductStatus.statusCode
                === ConstantValues.productStatusDraftCode
                || this.productDetails.vcptProductStatus.statusCode === null) {
                this.disableSaveAsDraftButton = false;
                this.hideDraftButton = false;
                this.saveAndActivateButtonName = 'Save and Activate';
            } else {
                this.disableSaveAsDraftButton = true;
                this.hideDraftButton = true;
                this.saveAndActivateButtonName = 'Save';
            }
            this.disableSaveandActivateButton = false;
        } else {
            this.facilities = [];
            this.maintainProductForm.get('productComments').disable();
            this.maintainProductForm.get('applicableCharacteristics').disable();
            this.disableSaveAsDraftButton = true;
            this.disableSaveandActivateButton = true;
        }
        this.loading = false;
    }

    @HostListener('window:beforeunload', ['$event'])
    canNavigateAway(event: any) {
        if (this.checkDirtyForm()) {
            event.returnValue = APP_CONSTANTS.UnsavedChangesMessage;
        }
    }
    @HostListener('window:unload', ['$event'])
    unloadPage(event: any) {
        this.setPreviousProdid();
        this.unlockProductforEdit(true);
    }
    canDeactivate() {
        if (this.checkDirtyForm()) {
            return this.getUserConfirmation().first();
        } else {
            this.setPreviousProdid();
            this.unlockProductforEdit();
            return true;
        }
    }

    checkDirtyForm(): boolean {
        return this.maintainProductForm ? this.maintainProductForm.dirty : false;
    }
    getUserConfirmation(): Observable<boolean> {
        return Observable.create((observer: Observer<boolean>) =>
            this.unsavedChangesComponent.getUnsavedChangesConfirmation()
                .subscribe((userInput: boolean) => {
                    if (userInput) {
                        this.setPreviousProdid();
                        this.unlockProductforEdit();
                        observer.next(true);
                        observer.complete();
                    } else {
                        observer.next(false);
                        observer.complete();
                    }
                })
        );
    }
    unlockProductforEdit(synchronousCall = false) {
        if (this.previousProductId !== 0 && this.previousProductId !== null) {
            this.sendUnlockRequest(this.previousProductId, synchronousCall);
        } else {
            this.sendUnlockRequest(this.productDetails.productId, synchronousCall);
        }
    }
    initializeMessage() {
        this.loading = true;
        this.displayMessage = false;
        this.returnMessage = new MessageModel();
        this.messageHeader = '';
        this.returnMessage.listofItemsforDisplay = [];
        this.returnMessage.message = '';
        this.returnMessage.messageCode = '';
        this.loading = false;
    }
    mapFormValuetoModel() {
        let applicableCharacteristic: CharacteristicsListBoxModel;
        if (this.maintainProductForm.get('applicableCharacteristics').value) {
            this.productDetails.applicableCharacteristics = [];
            if (this.maintainProductForm.get('applicableCharacteristics').value.length > 0) {
                this.maintainProductForm.get('applicableCharacteristics').value.forEach(characteristic => {
                    applicableCharacteristic = new CharacteristicsListBoxModel();
                    applicableCharacteristic.characteristicId = characteristic;
                    this.productDetails.applicableCharacteristics.push(applicableCharacteristic);
                });
            }
        }
        this.productDetails.productComments = this.maintainProductForm.get('productComments').value;
    }
    validateProductCharacteristicsToActivate(): boolean {
        let returnValue = false;
        const applicableCharacteristicsforSave: number[] = this.maintainProductForm.get('applicableCharacteristics').value;
        if (applicableCharacteristicsforSave && this.selectedCharacteristics) {
            if (applicableCharacteristicsforSave.length === 0) {
                returnValue = false;
            } else {
                returnValue = true;
            }
        } else {
            returnValue = false;
        }
        return returnValue;
    }
    getIconforMessageDisplay() {
        if (this.returnMessage.messageType) {
            switch (this.returnMessage.messageType.trim().toUpperCase()) {
                case 'Error'.toUpperCase(): this.messageIconType = APP_CONSTANTS.ErrorIcon; break;
                case 'Information'.toUpperCase(): this.messageIconType = APP_CONSTANTS.InformationIcon; break;
                case 'Warning'.toUpperCase(): this.messageIconType = APP_CONSTANTS.WarningIcon; break;
                default: this.messageIconType = APP_CONSTANTS.InformationIcon; break;
            }
        } else {
            this.messageIconType = APP_CONSTANTS.InformationIcon;
        }
    }
    saveDetails(saveAsDraft: boolean) {
        this.loading = true;
        this.productDetails.vcptProductStatus.statusCode
            = saveAsDraft ? ConstantValues.productStatusDraftCode : ConstantValues.productStatusActiveCode;
        this.productDetails.vcptProductStatus.statusDesc
            = saveAsDraft ? ConstantValues.productStatusDraft : ConstantValues.productStatusActive;
        this.mapFormValuetoModel();
        this.maintainProductService.saveProduct(this.productDetails)
            .subscribe((returnMessage: MessageModel) => {
                this.initializeMessage();
                this.returnMessage.messageCode = returnMessage.messageCode;
                if (returnMessage.listofItemsforDisplay) {
                    returnMessage.listofItemsforDisplay.forEach(message =>
                        this.returnMessage.listofItemsforDisplay.push(message));
                }
                this.messageHeader = saveAsDraft ? 'Save as Draft' : this.saveAndActivateButtonName;
                this.returnMessage.message = returnMessage.message;
                this.returnMessage.messageType = returnMessage.messageType;
                this.getIconforMessageDisplay();
                this.displayMessage = true;
                if (this.messageIconType === APP_CONSTANTS.InformationIcon) {
                    if (!saveAsDraft) {
                        this.disableSaveAsDraftButton = true;
                    }
                    this.maintainProductForm.reset();
                    this.getProductDetails();
                    this.enableDisableControls();
                }
            },
            (err: any) => {
                if (!saveAsDraft) {
                    this.disableSaveAsDraftButton = false;
                }
                this.enableDisableControls();
                this.loading = false;
                this.router.navigate([Url.error]);
            }, () => this.loading = false);
    }
    sendUnlockRequest(productId: number, synchronousCall: boolean) {
        this.loading = true;
        if (!synchronousCall) {
            this.maintainProductService.unlockProductforEdit(productId).subscribe((data: any) => {
            }, (error: Error) => {
                this.router.navigate([Url.error]);
            }, () => this.loading = false);
        } else {
            this.maintainProductService.unlockProductforEditSynchronous(productId);
            this.loading = false;
        }
    }
    setPreviousProdid() {
        if (this.previousProductId === 0 || this.previousProductId !== this.productDetails.productId) {
            if (this.productDetails.productId !== null && this.productDetails.productId !== 0) {
                this.previousProductId = this.productDetails.productId;
            }

        }
    }

}
