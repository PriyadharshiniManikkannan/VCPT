import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import { AllProductsWithNoPackagingMaterialComponent } from './AllProductsWithNoPackagingMaterial.component';
const AllProductsWithNoPackagingMaterialRoutes: Routes = [
    {
        path: '',
        component: AllProductsWithNoPackagingMaterialComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(AllProductsWithNoPackagingMaterialRoutes)],
    exports: [RouterModule]
})
export class AllProductsWithNoPackagingMaterialRoutingModule {
}
