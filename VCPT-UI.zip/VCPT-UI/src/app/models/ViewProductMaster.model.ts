import { VCPTStatusModel } from './VCPTStatus.model';
import { GGSMStatusModel } from './GGSMStatus.model';
export class ViewProductMaster {

    productLegacyID: string;
    productDescription: string;
    sapRelevancyStatus: string;
    productCode: string;
    facilityCollection: string;
    productStatus: VCPTStatusModel;
    prodComments: string;
    productBusinessLifeCycleStatus: GGSMStatusModel;
    characteristicsCollection: string;
    facilityCode: string;
    productID: string;
    lockedBy: string;
    applicableFacilities: any[];
    constructor() {
        this.productLegacyID = '';
        this.productDescription = '';
        this.sapRelevancyStatus = '';
        this.productCode = '';
        this.facilityCollection = '';
        this.prodComments = '';
        this.characteristicsCollection = '';
        this.facilityCode = '';
        this.productID = '';
        this.productStatus = new VCPTStatusModel();
        this.productBusinessLifeCycleStatus = new GGSMStatusModel();
        this.applicableFacilities = [];
    }

}
export class Facility {
    facilityId: number;
    facilityCode: string;
    facilityName: string;
}

export class Status {
    statusCode: string;
    statusDesc: string;
}
export class ProductStatus {
    statusCode: any;
    statusDesc: string;
}

