import { Observer } from 'rxjs/Observer';
import { Observable } from 'rxjs/Observable';
import { Component } from '@angular/core';
import { ConfirmationService } from 'primeng/primeng';
import { APP_CONSTANTS } from './../../constants/app.constants';

@Component({
    templateUrl: './UnsavedChanges.component.html'
})
export class UnsavedChangesComponent {
    constructor(private confirmationService: ConfirmationService) { }
    public getUnsavedChangesConfirmation(): Observable<boolean> {
        return Observable.create((observer: Observer<boolean>) => this.confirmationService.confirm({
            message: APP_CONSTANTS.UnsavedChangesMessage,
            icon: APP_CONSTANTS.WarningIcon,
            header: 'Confirm Navigation',
            accept: () => {
                observer.next(true);
                observer.complete();
            },
            reject: () => {
                observer.next(false);
                observer.complete();
            }
        }));
    }
}
