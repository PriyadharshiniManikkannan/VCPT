import { GGSMStatusModel } from './GGSMStatus.model';
import { VCPTStatusModel } from './VCPTStatus.model';
export class ProductDetails {
    productId: number;
    productLegacyID: string;
    productDescription: string;
    sapRelevancyStatus: string;
    productCode: string;
    productComments: string;
    productBusinessLifeCycleStatus: GGSMStatusModel;
    vcptProductStatus: VCPTStatusModel;
    applicableFacilities: any[];
    applicableCharacteristics: CharacteristicsListBoxModel[];
    createdBy: string;
    modifiedBy: string;
    createdDate: any;
    modifiedDate: any;
    lockedBy: string;
    lockStatus: boolean;

    public constructor() {
        this.productLegacyID = '';
        this.productDescription = '';
        this.sapRelevancyStatus = '';
        this.productCode = '';
        this.productComments = '';
        this.productBusinessLifeCycleStatus = new GGSMStatusModel();
        this.applicableFacilities = [];
        this.applicableCharacteristics = [];
        this.createdBy = '';
        this.modifiedBy = '';
        this.productId = 0;
        this.vcptProductStatus = new VCPTStatusModel();
    }
}

export class CharacteristicsListBoxModel {
    characteristicId?: number;
    characteristicName: string;
    public constructor() {
        this.characteristicId = null;
        this.characteristicName = '';
    }
}
