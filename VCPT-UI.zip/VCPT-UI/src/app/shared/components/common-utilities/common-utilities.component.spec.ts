import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonUtilitiesComponent } from './common-utilities.component';

describe('CommonUtilitiesComponent', () => {
  let component: CommonUtilitiesComponent;
  let fixture: ComponentFixture<CommonUtilitiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonUtilitiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonUtilitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
