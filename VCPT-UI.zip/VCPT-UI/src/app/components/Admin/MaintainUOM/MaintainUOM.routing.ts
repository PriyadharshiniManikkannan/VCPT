import { MaintainUOMComponent } from './MaintainUOM.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


const maintainUomRoutes: Routes = [
    {
        path: '',
        component: MaintainUOMComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(maintainUomRoutes)],
    exports: [RouterModule]
})
export class MaintainUOMRouteModule {

}
