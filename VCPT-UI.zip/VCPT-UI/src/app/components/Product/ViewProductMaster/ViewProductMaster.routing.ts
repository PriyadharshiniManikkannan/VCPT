import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ViewProductMasterComponent } from './ViewProductMaster.Component';
export const viewProductRoutes: Routes = [
    {
        path: '',
        component: ViewProductMasterComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(viewProductRoutes)],
    exports: [RouterModule]
})
export class ViewProductRoutingModule {
}
