import {
    Url, APP_CONSTANTS
} from './../../../shared/constants/app.constants';
import { Router } from '@angular/router';
import { MessageModel } from './../../../models/MessageModel.model';
import { MaintainProductConfigurationsService } from './../../../services/product/MaintainProductConfigurations.service';
import {
    PackagingMaterialsForProductConfiguration
} from './../../../models/PackagingMaterialForProductConfiguration.model';
import { Component, OnInit, Input, OnChanges, HostListener, Output, EventEmitter } from '@angular/core';
@Component({
    selector: 'print-template',
    templateUrl: 'PrintAllPackagingMaterialAssociation.component.html',
    styleUrls: ['./PrintAllPackagingMaterialAssociation.component.scss']
})
export class PrintAllPackagingMaterialAssociationComponent implements OnInit, OnChanges {
    @Input() packagingMaterialDetails: PackagingMaterialsForProductConfiguration;
    @Input() productConfigId: number;
    packagingMaterialForProductConfiguration: PackagingMaterialsForProductConfiguration;
    charateristicsSelectedUOM: any[];
    returnMessage: MessageModel;
    appConstant: any;
    /**
     *
     */
    constructor(private maintainProductConfigurationService: MaintainProductConfigurationsService, private router: Router) {

    }
    ngOnInit(): void {
        this.packagingMaterialForProductConfiguration = new PackagingMaterialsForProductConfiguration();
        this.returnMessage = new MessageModel();
        this.charateristicsSelectedUOM = [];
        this.appConstant = APP_CONSTANTS;
    }
    ngOnChanges() {
        this.handleDataChange();
    }

    getUOMName(characteristic): any {
        const uomName = this.charateristicsSelectedUOM
            .find(characteristicMap => characteristicMap.characteristicId === characteristic.characteristicId) ?
            this.charateristicsSelectedUOM
                .find(characteristicMap => characteristicMap.characteristicId === characteristic.characteristicId).uomName : '';
        return uomName;
    }

    getDecimalValue(characteristic: any) {
        return parseFloat(characteristic).toFixed(this.appConstant.globalDecimalPlace);
    }

    handleDataChange() {
        this.charateristicsSelectedUOM = [];
        this.packagingMaterialForProductConfiguration = new PackagingMaterialsForProductConfiguration();
        this.packagingMaterialForProductConfiguration =
            JSON.parse(JSON.stringify(this.packagingMaterialDetails));
        if (this.productConfigId && this.productConfigId > 0) {
            this.maintainProductConfigurationService
                .getCharacteristicsByConfigIDNoLock(this.productConfigId).subscribe(
                (configurationDetails: any) => {
                    if (configurationDetails && configurationDetails.message) {
                        this.returnMessage = configurationDetails;
                    } else {
                        this.packagingMaterialForProductConfiguration.configurationDetails = [];
                        this.packagingMaterialForProductConfiguration.configurationDetails = configurationDetails;
                        configurationDetails.forEach(configuration => {
                            this.charateristicsSelectedUOM.push({
                                characteristicId: configuration.characteristicId,
                                uomName: configuration.characteristicUOMs.find(uom => uom.uomId === configuration.selectedUOM)
                                    ? configuration.characteristicUOMs.find(uom => uom.uomId === configuration.selectedUOM).uomName : ''
                            });
                        }
                        );
                    }
                },
                (err) => {
                    if (err !== undefined) {
                        this.router.navigate([Url.error]);
                        return;
                    }
                });
        }

    }
}
