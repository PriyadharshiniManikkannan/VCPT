import { AppMenus } from './../../shared/constants/menu.constants';
import { environment } from './../../../environments/environment';
import { Observer } from 'rxjs/Observer';
import { SecurityService } from './../Security.service';
import { Url, APP_CONSTANTS } from './../../shared/constants/app.constants';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import { LoginService } from '../Login.service';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';

@Injectable()
export class AuthGuardService implements CanActivate {

    constructor(private router: Router,
        private loginService: LoginService,
        private securityService: SecurityService) {
    }

    forbidden() {
        this.router.navigate([Url.notAuthorized]);
    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<any> | boolean {
        return Observable
            .forkJoin(this.loginService.authenticated().first(),
            this.authorizeURLAccess(route).first())
            .toPromise()
            .then((returnResults) => {
                let finalResult = true;
                returnResults.forEach(result =>
                    finalResult = finalResult && result
                );
                if (!finalResult) {
                    this.forbidden();
                }
                return finalResult;
            });
    }

    authorizeURLAccess(route: ActivatedRouteSnapshot): Observable<boolean> {
        return Observable.create((observer: Observer<boolean>) => {
            this.securityService.populateUser().subscribe((isUserPopulated: boolean) => {
                if (environment.production === true) {
                    const activatedURLParent = route.parent.url;
                    const activatedURL = route.url;
                    let isURLEditable = false;
                    AppMenus.menus.forEach(menu => {
                        if (menu.SubMenu
                            .filter(submenu => submenu.editable === true
                                && submenu.routePath.toString().trim().toUpperCase()
                                === activatedURL.toString().trim().toUpperCase()).length > 0) { isURLEditable = true; }
                    });

                    // Authorize only Valid User Pin
                    if (this.securityService.isValidUser()) {
                        if (activatedURLParent.toString().trim().toUpperCase() === APP_CONSTANTS.adminMenuName.trim().toUpperCase()
                            && !this.securityService.isAdminUser()) {
                            observer.next(false);
                            observer.complete();
                        } else if (isURLEditable
                            && this.securityService.isReadOnlyUser()) {
                            observer.next(false);
                            observer.complete();
                        } else {
                            observer.next(true);
                            observer.complete();
                        }
                    } else {
                        // Navigate to Unauthorized page if User Pin is not valid.
                        observer.next(false);
                        observer.complete();
                    }

                } else {
                    observer.next(true);
                    observer.complete();
                }
            });
        });
    }
}

