import { MaintainPackagingMaterialsForProductComponent } from './MaintainPackagingMaterialsForProduct.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const maintainpackagingmaterialsforproductroutes: Routes = [
     {
        path: '',
        component: MaintainPackagingMaterialsForProductComponent
    },
    {
        path: ':id',
        component: MaintainPackagingMaterialsForProductComponent
    }];
@NgModule({
    imports: [RouterModule.forChild(maintainpackagingmaterialsforproductroutes)],
    exports: [RouterModule]
})
export class MaintainPackagingMaterialsForProductRouteModule {

}
