import {
    PackagingMaterialForProductConfigurationService
} from './../../../services/packaging/PackagingMaterialsForProductConfiguration.service';
import { MaintainPackagingMaterialsForProductService } from './../../../services/packaging/MaintainPackagingMaterialsForProduct.service';
import {
    excludeColumns, APP_CONSTANTS, ConstantValues,
    MessageItems, RouteURLs, containsSearchfilterColumns
} from './../../../shared/constants/app.constants';
import { MaintainProductConfigurations } from './../../../models/MaintainProductConfigurations.model';
import { PackagingMaterialsForProductConfiguration } from './../../../models/PackagingMaterialForProductConfiguration.model';
import { MessageModel } from './../../../models/MessageModel.model';
import { ProductConfigurationPackagingMaterialMapping } from './../../../models/ProductConfigurationPackagingMaterialMapping.model';
import { ProductDetails } from './../../../models/MaintainProduct.model';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { FormLabelValues, ScreenTitles } from './../../../shared/constants/form.constants';
import { Url } from './../../../shared/constants/app.constants';
import { Component, OnInit, HostListener } from '@angular/core';
import { SelectItem, Message } from 'primeng/primeng';
import { DialogModule } from 'primeng/primeng';
import { ConfirmationService } from 'primeng/primeng';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Observer } from 'rxjs/Observer';
import { Observable } from 'rxjs/Observable';
import { UnsavedChangesComponent } from './../../../shared/components/UnsavedChanges/UnsavedChanges.component';

@Component({
    templateUrl: 'MaintainPackagingMaterialsForConfiguration.component.html',
    styleUrls: ['./MaintainPackagingMaterialsForConfiguration.component.scss'],
    providers: [ConfirmationService]
})

export class MaintainPackagingMaterialsForConfigurationComponent implements OnInit {
    facilityDropdownItems: string[];
    packagingConfiguration: any[];
    packagingSupplies: any[];
    associatedPackagingSupplies: any[];
    activeConfiguration: any[];
    displayConfigGrid: boolean;
    displayPackagingGrid: boolean;
    displayAssociateGrid: boolean;
    columnNamesForConfigurationGrid: any[];
    recordsPerPageforConfigurationGrid: number;
    firstRecordIndexofConfigurationGrid: number;
    vals: any[];
    legacyID: string;
    SAPRelevancy: string;
    ProductCode: string;
    ProductDesc: string;
    Facility: string;
    msgs: Message[];
    facilities: any[];
    selectedFacilities: string[];
    ProductComments: string;
    disableFacilityDropdown: boolean;
    configurationComments: string;
    displayDialog: boolean;
    PackagingMaterialLegacyId: any;
    PackagingMaterialDescription: any;
    SAPBasicDataText: any;
    Quantity: any;
    QuantityUOM: any;
    Scrap: any;
    popupTitle: string;
    formLabels: any = FormLabelValues;
    formTitle: any;
    unsavedChangesComponent: UnsavedChangesComponent;
    messageHeader: string;
    displayMessage: boolean;
    returnMessage: MessageModel;
    searchFormGroup: FormGroup;
    commaSeperatedFacilities: string;
    commaSeperatedFacilityIds: string;
    public loading = false;
    showOkButton: boolean;
    packagingMaterialDetails: PackagingMaterialsForProductConfiguration;
    messageIconType: string;
    packagingMaterialId: number;
    form: FormGroup;
    ProductConfigurationId: number;
    ProductConfigurationPackagingMaterialMappingId: number;
    isQuantityValidate: boolean;
    isScrapValidate: boolean;
    isLegacyIdValidate: boolean;
    legacyMessage: string;
    scrapMessage: string;
    data: string;
    facilityId: any;
    isDisable: boolean;
    productDetailSelected: boolean;
    previousProductConfigId: number;
    isLegacyBoxDisable: boolean;
    ConstantValues: any;
    constructor(private formBuilder: FormBuilder,
        private confirmationService: ConfirmationService,
        private packagingMaterialsForProductConfigurationService: PackagingMaterialForProductConfigurationService,
        private maintainPackagingMaterialsForProductService: MaintainPackagingMaterialsForProductService,
        private activatedRoute: ActivatedRoute,
        private router: Router) { }

    ngOnInit() {
        this.loading = true;
        this.ConstantValues = ConstantValues;
        this.buildForm();
        this.initializeform(true);
        this.loading = false;
        this.activatedRoute.params.subscribe((params: any) => {
            if (params) {
                if (params['id'] && params['id'] !== '') {
                    this.searchFormGroup.get('productLegacyID').patchValue(params['id']);
                    this.loading = true;
                    this.showResults();
                }
            }
        },
            (err) => {
                if (err !== undefined) {
                    // this.messageHeader = MessageItems.erroHeader;
                    // this.returnMessage.message = MessageItems.errorMessgae;
                    // this.messageIconType = APP_CONSTANTS.ErrorIcon;
                    // this.displayMessage = true;
                    this.router.navigate([Url.error]);
                    return;
                }
            });
    }
    buildForm() {
        this.searchFormGroup = this.formBuilder.group({ productLegacyID: new FormControl('') });
        this.form = this.formBuilder.group({
            quantity: new FormControl({ value: '' }),
            scrap: new FormControl({ value: '1' }),
        });
    }
    showResults(): void {
        this.loading = true;
        this.packagingMaterialDetails.configurationDetails = [];
        this.packagingMaterialDetails.productPackagingMaterialsMapping = [];
        this.packagingMaterialDetails.packagingDetails = [];
        const jsonParam = {
            legacyID: this.searchFormGroup.get('productLegacyID').value,
            maintainPackagingMaterialForConfigurationScreen: true
        };
        this.initializeMessage();
        this.messageHeader = 'Get Details for Product';
        if (this.searchFormGroup.get('productLegacyID').value) {
            this.packagingMaterialsForProductConfigurationService
                .getProductDetails(jsonParam)
                .subscribe((productDetails: any) => {
                    if (productDetails && productDetails.message) {
                        this.showMessage(productDetails, this.messageHeader);
                        this.initializeform(false);
                    } else if (productDetails.productId) {
                        this.packagingMaterialDetails.productDetails = productDetails;
                        this.packagingMaterialDetails.productDetails.applicableFacilities.sort(function (a, b) {
                            return a.facilityName.localeCompare(b.facilityName);
                        });
                        this.maintainPackagingMaterialsForProductService
                            .getPackagingDetailsByProductId(this.packagingMaterialDetails.productDetails.productId)
                            .subscribe((packagingMaterialsForProduct: any) => {
                                if (packagingMaterialsForProduct && packagingMaterialsForProduct.message) {
                                    this.showMessage(packagingMaterialsForProduct, this.messageHeader);
                                    this.packagingMaterialDetails = new PackagingMaterialsForProductConfiguration();
                                    this.disableFacilityDropdown = true;
                                } else if (packagingMaterialsForProduct && packagingMaterialsForProduct.length > 0
                                    && packagingMaterialsForProduct[0].pkgConfigMapId) {
                                    this.packagingMaterialDetails.productPackagingMaterialsMapping = packagingMaterialsForProduct;

                                }
                            });
                        this.productDetailSelected = true;
                        this.disableFacilityDropdown = false;
                    }

                }, (error: Error) => {
                    this.router.navigate([Url.error]);
                    this.loading = false;
                }, () => this.loading = false
                );
        } else {
            this.initializeform(false);
            const returnMessage = { message: '', messageType: '' };
            returnMessage.message = MessageItems.draftMessage;
            returnMessage.messageType = 'Error';
            this.showMessage(returnMessage, MessageItems.productHeader);
            this.loading = false;
            return;
        }
    }
    showConfigGrid(value): void {
        if (value === 'Select') {
            this.displayConfigGrid = false;
        } else {
            this.displayConfigGrid = true;
            this.configurationComments = 'Any special packing instructions';
        }
    }
    showPackagingGrid(): void {
        this.displayAssociateGrid = true;
    }
    getColumnforConfigurationGrid(obj: any): void {
        if (obj && obj.length) {
            const keys = Object.keys(obj[0]);
            const cols = [];
            keys.filter(key => excludeColumns.columns.indexOf(key) < 0
                && excludeColumns.hiddenColumns.indexOf(key) < 0)
                .forEach(key => cols.push({
                    field: key, header: key,
                    filter: containsSearchfilterColumns.columns.indexOf(key) < 0 ?
                        ConstantValues.equalsFilter : ConstantValues.containsFilter,
                    hidden: excludeColumns.hiddenColumns.indexOf(key) < 0 ? false : true
                }));

            this.columnNamesForConfigurationGrid = cols;
        }
    }
    canDeactivate(): Observable<boolean> | boolean {
        this.unlockProductConfigurationforEdit(false);
        return true;
    }

    getUserConfirmation(): Observable<boolean> {
        return this.unsavedChangesComponent.getUnsavedChangesConfirmation();
    }
    checkDirtyForm(): boolean {
        return this.form ? this.form.dirty : false;
    }
    clearDialogFields(): void {
        this.PackagingMaterialLegacyId = '';
        this.PackagingMaterialDescription = '';
        this.SAPBasicDataText = '';
        this.Quantity = '';
        this.QuantityUOM = '';
        this.Scrap = '1';
        this.data = '';
        this.scrapMessage = '';
        this.isQuantityValidate = false;
        this.isScrapValidate = false;
        this.isLegacyIdValidate = false;
        this.legacyMessage = '';
    }
    initializeform(initializeMessage: boolean) {
        this.unsavedChangesComponent = new UnsavedChangesComponent(this.confirmationService);
        this.loading = true;
        this.packagingMaterialDetails = new PackagingMaterialsForProductConfiguration();
        this.commaSeperatedFacilities = '';
        this.commaSeperatedFacilityIds = '';
        this.activeConfiguration = [];
        this.firstRecordIndexofConfigurationGrid = 1;
        this.recordsPerPageforConfigurationGrid = APP_CONSTANTS.recordsPerPageConstant;
        this.SAPRelevancy = '';
        this.ProductCode = '';
        this.ProductDesc = '';
        this.productDetailSelected = false;
        this.Facility = '';
        this.configurationComments = '';
        this.displayConfigGrid = false;
        this.displayPackagingGrid = false;
        this.displayAssociateGrid = false;
        this.columnNamesForConfigurationGrid = [];
        this.msgs = [];
        this.ProductComments = '';
        this.facilities = [];
        this.selectedFacilities = [];
        this.disableFacilityDropdown = true;
        this.displayDialog = false;
        this.packagingConfiguration = [];
        this.packagingSupplies = [];
        this.associatedPackagingSupplies = [];
        this.formTitle = ScreenTitles;
        this.messageIconType = '';
        this.loading = false;
        this.packagingMaterialId = 0;
        this.ProductConfigurationId = 0;
        this.ProductConfigurationPackagingMaterialMappingId = 0;
        this.isDisable = true;
        this.previousProductConfigId = 0;
        if (initializeMessage) {
            this.initializeMessage();
        }
        this.loading = false;
    }
    unlockProductConfigurationforEdit(synchronousCall = false) {
        if (this.ProductConfigurationId !== 0 && this.ProductConfigurationId !== null) {
            const packageDetails = new ProductConfigurationPackagingMaterialMapping();
            packageDetails.facilityId = this.facilityId;
            packageDetails.productConfigurationId = this.ProductConfigurationId;
            this.sendUnlockRequest(packageDetails, synchronousCall);
        }
    }
    configurationGridRowSelect(event: any) {
        this.packagingMaterialDetails.packagingDetails = [];
        if (this.ProductConfigurationId !== undefined && this.ProductConfigurationId !== 0) {
            this.unlockProductConfigurationforEdit(false);
        }
        this.configurationComments = event.data['Configuration Comments'] ? event.data['Configuration Comments'].toString() : '';
        this.ProductConfigurationId = event.data['ProdConfigId'];
        if (this.ProductConfigurationId) {
            this.isDisable = false;
            this.getPackagingMaterialforConfiguration(this.ProductConfigurationId);
        } else {
            this.isDisable = true;
        }
    }
    getCommaSeperatedFacilities(): string {
        this.commaSeperatedFacilities = '';
        if (this.packagingMaterialDetails.productDetails.applicableFacilities
            && this.packagingMaterialDetails.productDetails.applicableFacilities.length > 0) {
            for (let i = 0; i < this.packagingMaterialDetails.productDetails.applicableFacilities.length; i++) {
                if (i !== this.packagingMaterialDetails.productDetails.applicableFacilities.length - 1) {
                    this.commaSeperatedFacilities =
                        this.commaSeperatedFacilities
                        + this.packagingMaterialDetails.productDetails.applicableFacilities[i].facilityName + ', ';
                } else {
                    this.commaSeperatedFacilities = this.commaSeperatedFacilities
                        + this.packagingMaterialDetails.productDetails.applicableFacilities[i].facilityName;
                }
            }
        }
        return this.commaSeperatedFacilities;
    }
    getCommaSeperatedFacilityIds(): string {
        this.commaSeperatedFacilityIds = '';
        if (this.packagingMaterialDetails.productDetails.applicableFacilities
            && this.packagingMaterialDetails.productDetails.applicableFacilities.length > 0) {
            for (let i = 0; i < this.packagingMaterialDetails.productDetails.applicableFacilities.length; i++) {
                if (i !== this.packagingMaterialDetails.productDetails.applicableFacilities.length - 1) {
                    this.commaSeperatedFacilityIds =
                        this.commaSeperatedFacilities
                        + this.packagingMaterialDetails.productDetails.applicableFacilities[i].facilityID + ',';
                } else {
                    this.commaSeperatedFacilities = this.commaSeperatedFacilities
                        + this.packagingMaterialDetails.productDetails.applicableFacilities[i].facilityID;
                }
            }
        }
        return this.commaSeperatedFacilities;
    }
    getConfigurationsForFacility(event: any) {
        this.isDisable = true;
        this.packagingMaterialDetails.configurationDetails = [];
        this.packagingMaterialDetails.packagingDetails = [];
        if (event !== null) {
            this.configurationComments = '';

        }
        if (this.ProductConfigurationId !== undefined && this.ProductConfigurationId !== 0) {
            this.unlockProductConfigurationforEdit(false);
        }
        if (event && event !== null) {
            if (event.target.value > 0) {
                this.loading = true;
                const productConfigurations = new MaintainProductConfigurations();
                productConfigurations.productId = this.packagingMaterialDetails.productDetails.productId.toString();
                productConfigurations.facilityCollection = event.target.value;

                this.facilityId = event.target.value;
                productConfigurations.getOnlyActiveConfiguration = true;
                if (this.packagingMaterialDetails.productDetails.productId > 0) {
                    this.packagingMaterialsForProductConfigurationService
                        .getProductConfigurationDetails(productConfigurations)
                        .subscribe((activeConfigurations: any) => {
                            if (activeConfigurations && activeConfigurations.message) {
                                this.returnMessage = activeConfigurations;
                            } else if (activeConfigurations && activeConfigurations.length && activeConfigurations.length > 0) {
                                this.packagingMaterialDetails.configurationDetails = [];
                                this.packagingMaterialDetails.configurationDetails = activeConfigurations;
                                this.getColumnforConfigurationGrid(this.packagingMaterialDetails.configurationDetails);
                            }
                            this.loading = false;
                        }, (error: Error) => {
                            this.router.navigate([Url.error]);
                            this.loading = false;
                        }
                        );
                }
            }else{
                 this.loading = false;
            }
        } else if (this.facilityId.length > 0) {
             if (this.returnMessage.messageType === MessageItems.erroHeader) {
                 this.configurationComments = '';
             }
            this.loading = true;
            this.packagingMaterialDetails.packagingDetails = [];
            const productConfigurations = new MaintainProductConfigurations();
            productConfigurations.productId = this.packagingMaterialDetails.productDetails.productId.toString();
            productConfigurations.facilityCollection = this.facilityId;
            productConfigurations.getOnlyActiveConfiguration = true;
            if (this.packagingMaterialDetails.productDetails.productId > 0) {
                this.packagingMaterialsForProductConfigurationService
                    .getProductConfigurationDetails(productConfigurations)
                    .subscribe((activeConfigurations: any) => {
                        if (activeConfigurations && activeConfigurations.message) {
                            this.returnMessage = activeConfigurations;
                        } else if (activeConfigurations && activeConfigurations.length && activeConfigurations.length > 0) {

                            this.packagingMaterialDetails.configurationDetails = [];
                            this.packagingMaterialDetails.configurationDetails = activeConfigurations;
                            this.getColumnforConfigurationGrid(this.packagingMaterialDetails.configurationDetails);
                        } else {
                            this.ProductConfigurationId = 0;
                            this.getPackagingMaterialforConfiguration(this.ProductConfigurationId);
                        }
                        this.loading = false;
                    }, (error: Error) => {
                        this.router.navigate([Url.error]);
                        this.loading = false;
                    }
                    );
            }

        } else {
            this.loading = false;
            this.packagingMaterialDetails.configurationDetails = [];
            this.columnNamesForConfigurationGrid = [];
        }
    }
    onConfigurationGridPageChange(event: any) {
        this.firstRecordIndexofConfigurationGrid = event.first === 1 ? event.first : event.first + 1;
        this.recordsPerPageforConfigurationGrid = event.first !== 1 ? event.rows + event.first : event.rows;
    }
    legacyIdChange() {
        if (this.PackagingMaterialLegacyId.length === ConstantValues.productLegacyIDLength) {
            this.maintainPackagingMaterialsForProductService.getPackagingDetailsByLegacyId(this.PackagingMaterialLegacyId).
                subscribe((data: any) => {
                    if (data && !data.message) {
                        this.loading = false;
                        this.PackagingMaterialDescription = data.packagingMaterialDescription;
                        this.SAPBasicDataText = data.sapBasicDataText;
                        this.QuantityUOM = data.quantityUOM;
                        this.packagingMaterialId = data.packagingMaterialID;
                    } else {
                        this.displayDialog = false;
                        this.showMessage(data, 'Get Packaging Details');
                        this.loading = false;
                        return;

                    }
                },
                (err) => {
                    if (err !== undefined) {
                        this.router.navigate([Url.error]);
                        return;
                    }
                });

        }

    }
    cancel() {
        if (!this.form.dirty) {
            this.displayDialog = false;
        } else {
            this.confirmationService.confirm({
                message: APP_CONSTANTS.UnsavedChangesMessage,
                icon: APP_CONSTANTS.WarningIcon,
                header: 'Confirmation',
                accept: () => {
                    this.displayDialog = false;
                    this.form.reset();
                },
                reject: () => {
                    this.displayDialog = true;
                }
            });
        }
    }
    edit(packageDetails: any) {
        this.clearDialogFields();
        this.displayDialog = true;
        this.isLegacyBoxDisable = true;
        this.popupTitle = 'Edit Packaging Details for Product';
        this.PackagingMaterialLegacyId = packageDetails.packagingMaterialLegacyID;
        this.PackagingMaterialDescription = packageDetails.packagingMaterialDescription;
        this.SAPBasicDataText = packageDetails.sapBasicDataText;
        this.QuantityUOM = packageDetails.quantityUOM;
        this.Quantity = packageDetails.productConfigurationMapping.quantity;
        this.packagingMaterialId = packageDetails.packagingMaterialID;
        this.Scrap = packageDetails.productConfigurationMapping.scrapPercentage;
        this.ProductConfigurationPackagingMaterialMappingId =
            packageDetails.productConfigurationMapping.productConfigurationPackagingMaterialMappingId;

    }
    showDialogToAdd() {
        this.clearDialogFields();
        this.isLegacyBoxDisable = false;
        this.displayDialog = true;
        this.popupTitle = 'Add Packaging Details for Product';
        this.ProductConfigurationPackagingMaterialMappingId = 0;
    }
    save() {
        this.isLegacyIdValidate = false;
        this.isScrapValidate = false;
        this.isQuantityValidate = false;
        const packagingDetails = new ProductConfigurationPackagingMaterialMapping();
        packagingDetails.packagingMaterialId = this.packagingMaterialId;
        packagingDetails.quantity = this.Quantity;
        packagingDetails.scrapPercentage = this.Scrap;
        packagingDetails.productConfigurationId = this.ProductConfigurationId;
        packagingDetails.productConfigurationPackagingMaterialMappingId = this.ProductConfigurationPackagingMaterialMappingId;
        //  packagingDetails.createdBy = 'a5r88zz';
        packagingDetails.facilityId = this.facilityId;
        this.scrapMessage = '';
        if (this.PackagingMaterialLegacyId === '' || this.PackagingMaterialLegacyId === undefined
            || this.PackagingMaterialLegacyId.length !== ConstantValues.productLegacyIDLength) {
            this.legacyMessage = MessageItems.packagingLegacyEmptyMessage;
            this.isLegacyIdValidate = true;
            this.isScrapValidate = false;
            this.isQuantityValidate = false;
            return;
        }
        if (this.Quantity === '' || this.Quantity === undefined || this.Quantity === null) {
            this.data = MessageItems.quantityEmptyMessage;
            this.isQuantityValidate = true;
            this.isLegacyIdValidate = false;
            this.isScrapValidate = false;
            return;
        }
        if (this.Scrap === '' || this.Scrap === undefined || this.Scrap === null) {
            this.scrapMessage = MessageItems.scrapEmptyMessage;
            this.isScrapValidate = true;
            this.isLegacyIdValidate = false;

            this.isQuantityValidate = false;
            return;
        }
        this.packagingMaterialsForProductConfigurationService.SavePackagingMaterialForProductConfiguration(packagingDetails).
            subscribe((returnMessage: MessageModel) => {
                this.showMessage(returnMessage, 'Save Details');
                this.form.reset();
                this.getPackagingMaterialforConfiguration(this.ProductConfigurationId);
                this.displayDialog = false;
                this.getConfigurationsForFacility(null);
            }, (error: Error) => {
                this.router.navigate([Url.error]);
                this.loading = false;
            }
            );
    }
    initializeMessage() {
        this.displayMessage = false;
        this.returnMessage = new MessageModel();
        this.messageHeader = '';
        this.messageIconType = 'Information';
    }
    getIconforMessageDisplay() {
        switch (this.returnMessage.messageType.trim().toUpperCase()) {
            case 'Error'.toUpperCase(): this.messageIconType = APP_CONSTANTS.ErrorIcon;
                break;
            case 'Information'.toUpperCase(): this.messageIconType = APP_CONSTANTS.InformationIcon;
                break;
            case 'Warning'.toUpperCase(): this.messageIconType = APP_CONSTANTS.WarningIcon; break;
            default: this.messageIconType = APP_CONSTANTS.InformationIcon; break;
        }
    }
    delete(packageDetails: any) {
        this.confirmationService.confirm({
            message: MessageItems.packagingAssociationDeleteMessage,
            icon: APP_CONSTANTS.WarningIcon,
            header: 'Confirmation',
            accept: () => {
                this.packagingMaterialsForProductConfigurationService.
                    deletePackageAssociation(packageDetails.productConfigurationMapping.productConfigurationPackagingMaterialMappingId).
                    subscribe((data: any) => {
                        this.form.reset();
                        this.getPackagingMaterialforConfiguration(this.ProductConfigurationId);
                    });
            },
            reject: () => {
                return;
            }
        });
    }

    @HostListener('window:beforeunload', ['$event'])
    canNavigateAway(event: any) {
        if (this.form.dirty) {
            event.returnValue = APP_CONSTANTS.UnsavedChangesMessage;
        }
    }

    @HostListener('window:unload', ['$event'])
    unloadPage(event: any) {
        this.unlockProductConfigurationforEdit(true);
    }

    viewPackagingConfiguration() {
        this.loading = true;
        if (this.searchFormGroup.get('productLegacyID').value !== ''
            && (this.searchFormGroup.get('productLegacyID').value).length === ConstantValues.productLegacyIDLength) {
            this.unlockProductConfigurationforEdit(true);
            this.router
                .navigateByUrl(RouteURLs.ViewPackagingMaterialsConfigurationPath +
                ';id=' + this.searchFormGroup.get('productLegacyID').value);
        }
    }
    showMessage(messageToShow: any, messageHeader: any) {
        this.initializeMessage();
        this.returnMessage.messageCode = messageToShow.messageCode;
        this.returnMessage.messageHeader = messageHeader;
        if (messageToShow.listofItemsforDisplay) {
            messageToShow.listofItemsforDisplay.forEach(message =>
                this.returnMessage.listofItemsforDisplay.push(message));
        }
        this.returnMessage.message = messageToShow.message;
        this.returnMessage.messageType = messageToShow.messageType;
        this.getIconforMessageDisplay();
        this.returnMessage.messageIconClass = this.messageIconType;
        this.displayMessage
            = this.returnMessage.message !== '' && this.returnMessage.message !== null ? true : false;
    }
    sendUnlockRequest(packageDetails: any, synchronousCall: boolean) {
        this.loading = true;
        if (!synchronousCall) {
            this.packagingMaterialsForProductConfigurationService
                .unlockProductConfigforEdit(packageDetails).subscribe((data: any) => {
                }, (error: Error) => {
                    this.router.navigate([Url.error]);
                    this.loading = false;
                });
        } else {
            this.packagingMaterialsForProductConfigurationService
                .unlockProductConfigforEditSynchronous(packageDetails);
            this.loading = false;
        }
    }
    getPackagingMaterialforConfiguration(prodconfigid: number) {
        const jsonParam: any = {};
        jsonParam.ProductConfigurationID = prodconfigid;
        jsonParam.FacilityID = this.facilityId;
        this.loading = true;
        this.packagingMaterialsForProductConfigurationService
            .getPackagingMaterialsForProductConfiguration(jsonParam)
            .subscribe((packagingDetails: any) => {
                this.loading = true;
                if (packagingDetails && packagingDetails.message) {
                    this.loading = false;
                    this.initializeMessage();
                    this.showMessage(packagingDetails, 'Get Details for Configuration');
                    this.isDisable = true;
                } else if (packagingDetails && packagingDetails.length > 0) {
                    this.packagingMaterialDetails.packagingDetails = packagingDetails;
                    this.isDisable = false;
                } else if (packagingDetails && packagingDetails.length === 0) {
                    this.packagingMaterialDetails.packagingDetails = [];
                    this.isDisable = false;
                }
                this.loading = false;
            }, (error: Error) => {
                this.router.navigate([Url.error]);
                this.loading = false;
            }
            );
    }
}
