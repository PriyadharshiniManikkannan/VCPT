import { environment } from './../../environments/environment';
import { Router } from '@angular/router';
import { Observer } from 'rxjs/Observer';
import { Observable } from 'rxjs/Observable';
import { SessionConstants, Url } from './../shared/constants/app.constants';
import { UserDetails } from './../models/UserDetails.model';
import { Injectable, OnInit } from '@angular/core';
import { CookieService } from 'ngx-cookie';

@Injectable()
export class LoginService {

  userToken: any;
  constructor(private cookieService: CookieService,
    private router: Router) {

  }

  authenticated(): Observable<boolean> {
    return Observable.create((observer: Observer<boolean>) => {
      if (environment.production === true) {
        if (!this.isvalid(this.cookieService.get(SessionConstants.userToken))) {
          observer.next(false);
          observer.complete();
        } else {
          observer.next(true);
          observer.complete();
        }
      } else {
        observer.next(true);
        observer.complete();
      }
    });
  }

  private getToken() {
    this.userToken = this.cookieService.get(SessionConstants.userToken);
  }

  private isvalid(value) {
    return value && value != null && value.length > 0;
  }
}
