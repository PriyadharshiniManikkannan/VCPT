import { CanDeactivateGuard } from './../services/guards/CanComponentDeactivate.guard.service';
import { AuthGuardService } from './../services/guards/AuthGuardService.service';

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LayoutComponent } from './layout.component';
import { MaintainProductComponent } from '../components/Product/MaintainProduct/MaintainProduct.component';
import { HomeComponent } from './../components/Home/Home.component';
import {
    MaintainProductCharacteristicsComponent
} from './../components/Admin/MaintainProductCharacteristics/MaintainProductCharacteristics.component';
import { MaintainUOMComponent } from './../components/Admin/MaintainUOM/MaintainUOM.component';
import { ViewProductMasterComponent } from '../components/Product/ViewProductMaster/ViewProductMaster.Component';
import {
    MaintainProductConfigurationsComponent
} from '../components/Product/MaintainProductConfigurations/MaintainProductConfigurations.component';
import { ViewProductConfigurationsComponent } from './../components/Product/ViewProductConfigurations/ViewProductConfigurations.component';
import {
    PackagingMaterialWhereUsedComponent
} from './../components/Reports/PackagingMaterialWhereUsed/PackagingMaterialWhereUsed.component';
import { ExtractAllDataComponent } from '../components/Reports/ExtractAllData/ExtractAllData.component';
import {
    AllProductsWithNoPackagingMaterialComponent
} from '../components/Reports/AllProductsWithNoPackagingMaterial/AllProductsWithNoPackagingMaterial.component';
import { ImportPackagingMaterialComponent } from '../components/Packaging/ImportPackagingMaterial/ImportPackagingMaterial.component';
import {
    AddObsoletePackagingMaterialComponent
} from './../components/Packaging/AddObsoletePackagingMaterial/AddObsoletePackagingMaterial.component';
import {
    ViewAllPackagingMaterialsforProductComponent
} from './../components/Packaging/ViewAllPackagingMaterialsforProduct/ViewAllPackagingMaterialsforProduct.component';
import {
    ViewAllPackagingMaterialsforConfigurationsComponent
} from './../components/Packaging/ViewAllPackagingMaterialsforConfigurations/ViewAllPackagingMaterialsforConfigurations.component';
import {
    ViewAllPackagingMaterialsComponent
} from './../components/Packaging/ViewAllPackagingMaterials/ViewAllPackagingMaterials.component';
import {
    MaintainPackagingMaterialsForProductComponent
} from './../components/Packaging/MaintainPackagingMaterialsForProduct/MaintainPackagingMaterialsForProduct.component';
import {
    MaintainPackagingMaterialsForConfigurationComponent
} from './../components/Packaging/MaintainPackagingMaterialsForConfiguration/MaintainPackagingMaterialsForConfiguration.component';

import { NotAuthorizedComponent } from './../shared/components/notAuthorized/NotAuthorized.component';
import { ErrorComponent } from './../shared/components/Error/ErrorComponent.component';
export const layoutRoutes: Routes = [
    {
        path: 'notAuthorized',
        component: NotAuthorizedComponent
    },
    {
        path: 'error',
        component: ErrorComponent
    },
    {
        path: '',
        component: LayoutComponent,
        children: [
            {
                path: 'Home',
                component: HomeComponent,
                canActivate: [AuthGuardService]
            }
        ],
    },
    {
        path: 'Admin',
        component: LayoutComponent,
        children: [
            {
                path: 'MaintainProductCharacteristics',
                canActivate: [AuthGuardService],
                component: MaintainProductCharacteristicsComponent
            },
            {
                path: 'MaintainUOM',
                canActivate: [AuthGuardService],
                component: MaintainUOMComponent
            },
        ]
    },
    {
        path: 'Product',
        component: LayoutComponent,
        children: [
            {
                path: 'MaintainProduct',
                component: MaintainProductComponent,
                canActivate: [AuthGuardService],
                canDeactivate: [CanDeactivateGuard]
            },
            {
                path: 'ViewProductMaster',
                canActivate: [AuthGuardService],
                component: ViewProductMasterComponent
            },
            {
                path: 'MaintainProductConfigurations',
                canActivate: [AuthGuardService],
                component: MaintainProductConfigurationsComponent
            },

            {
                path: 'ViewProductConfigurations',
                canActivate: [AuthGuardService],
                component: ViewProductConfigurationsComponent
            },
        ]
    },
    {
        path: 'Packaging',
        component: LayoutComponent,
        children: [
            {
                path: 'AddObsoletePackagingMaterial',
                canActivate: [AuthGuardService],
                component: AddObsoletePackagingMaterialComponent,
                canDeactivate: [CanDeactivateGuard]
            },
            {
                path: 'ImportPackagingMaterial',
                canActivate: [AuthGuardService],
                component: ImportPackagingMaterialComponent,
                canDeactivate: [CanDeactivateGuard]
            },
            {
                path: 'MaintainPackagingMaterialsForConfiguration',
                canActivate: [AuthGuardService],
                canDeactivate: [CanDeactivateGuard],
                component: MaintainPackagingMaterialsForConfigurationComponent
            },
            {
                path: 'MaintainPackagingMaterialsForProduct',
                canActivate: [AuthGuardService],
                component: MaintainPackagingMaterialsForProductComponent,
                canDeactivate: [CanDeactivateGuard]
            },
            {
                path: 'ViewAllPackagingMaterials',
                canActivate: [AuthGuardService],
                component: ViewAllPackagingMaterialsComponent
            },
            {
                path: 'ViewAllPackagingMaterialsforConfigurations',
                canActivate: [AuthGuardService],
                component: ViewAllPackagingMaterialsforConfigurationsComponent
            },
            {
                path: 'ViewAllPackagingMaterialsforProduct',
                canActivate: [AuthGuardService],
                component: ViewAllPackagingMaterialsforProductComponent
            }
        ]
    },
    {
        path: 'Reports',
        component: LayoutComponent,
        children: [
            {
                path: 'PackagingMaterialWhereUsed',
                canActivate: [AuthGuardService],
                component: PackagingMaterialWhereUsedComponent
            },
            {
                path: 'ExtractAllData',
                canActivate: [AuthGuardService],
                component: ExtractAllDataComponent
            },
            {
                path: 'AllProductsWithNoPackagingAssociation',
                canActivate: [AuthGuardService],
                component: AllProductsWithNoPackagingMaterialComponent
            }
        ]
    }
];

@NgModule({
    imports: [
        RouterModule.forChild(layoutRoutes)
    ],
    exports: [RouterModule]
})
export class LayoutRoutingModule {
}
