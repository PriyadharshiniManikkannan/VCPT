
export class MaintainUOM {
    uomName: string;
    uomCode: string;
    createdBy: string;
    modifiedBy: string;
}


