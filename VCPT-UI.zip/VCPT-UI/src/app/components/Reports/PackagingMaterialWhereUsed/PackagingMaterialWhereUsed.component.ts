import { CommonUtilitiesComponent } from './../../../shared/components/common-utilities/common-utilities.component';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormLabelValues, ScreenTitles } from './../../../shared/constants/form.constants';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { APP_CONSTANTS, ConstantValues, MessageItems, Url } from './../../../shared/constants/app.constants';
import { MessageModel } from './../../../models/MessageModel.model';
import { PackagingMaterialWhereUsedService } from './../../../services/reports/PackagingMaterialWhereUsed.service';
import { Report } from './../../../models/Report.model';
import { utils, write, WorkBook } from 'xlsx';
import { saveAs } from 'file-saver';

@Component(
    {
        templateUrl: './PackagingMaterialWhereUsed.Component.html',
        styleUrls: ['./PackagingMaterialWhereUsed.Component.scss']
    }
)
export class PackagingMaterialWhereUsedComponent implements OnInit {
    formLabels: any;
    formTitle: any;
    legacyId: string;
    numberofProducts: any;
    numberofConfigurations: any;
    packagingSearchForm: FormGroup;
    displayMessage: boolean;
    messageHeader: string;
    returnMessage: MessageModel;
    messageIconType: string;
    productDetails: any[];
    isNoRecords: boolean;
    // Loading variable for ngx-loading component
    public loading = false;
    constructor(
        private formBuilder: FormBuilder,
        private _router: Router,
        private packagingMaterialWhereUsedService: PackagingMaterialWhereUsedService
    ) {
    }
    ngOnInit() {
        this.formLabels = FormLabelValues;
        this.formTitle = ScreenTitles;
        this.buildForm();
        this.initializeForm();
        this.initializeMessage();
    }
    showResults(): void {
        this.isNoRecords = true;
        this.numberofProducts = '';
        this.numberofConfigurations = '';
        this.loading = true;
        if (this.legacyId !== '' && this.legacyId.length === ConstantValues.productLegacyIDLength) {
            this.packagingMaterialWhereUsedService.getPackageDetailsByLegacyID(this.legacyId).subscribe((data: any) => {
                this.loading = false;
                if (data.isValid && data.isActive) {
                    this.numberofProducts = data.productCount;
                    this.numberofConfigurations = data.productConfigCount;
                    if (this.numberofProducts === 0 && this.numberofConfigurations === 0) {
                        this.isNoRecords = true;
                    } else {
                        this.isNoRecords = false;
                    }

                } else if (data.isValid) {
                    if (!data.isActive) {
                        this.isNoRecords = true;
                        this.loading = false;
                        this.messageHeader = MessageItems.packagingHeader;
                        this.returnMessage.message = MessageItems.packagingIdInactiveMessage;
                        this.messageIconType = APP_CONSTANTS.ErrorIcon;
                        this.displayMessage = true;
                        return;

                    }

                } else {
                    this.isNoRecords = true;
                    this.loading = false;
                    this.messageHeader = MessageItems.packagingHeader;
                    this.returnMessage.message = MessageItems.packagingIdSearchMessage;
                    this.messageIconType = APP_CONSTANTS.ErrorIcon;
                    this.displayMessage = true;
                    return;

                }
            },
                (err) => {
                    if (err !== undefined) {
                        // this.messageHeader = MessageItems.erroHeader;
                        // this.returnMessage.message = MessageItems.errorMessgae;
                        // this.messageIconType = APP_CONSTANTS.ErrorIcon;
                        // this.displayMessage = true;
                        this._router.navigate([Url.error]);
                        return;
                    }
                });

        } else {
            this.isNoRecords = true;
            this.loading = false;
            this.messageHeader = MessageItems.erroHeader;
            this.returnMessage.message = MessageItems.packagingIdSearchMessage;
            this.messageIconType = APP_CONSTANTS.ErrorIcon;
            this.displayMessage = true;
            return;
        }
    }
    buildForm() {
        this.packagingSearchForm = this.formBuilder.group({ legacyId: new FormControl('') });
    }
    initializeForm() {
        this.legacyId = '';
        this.isNoRecords = true;
        this.numberofProducts = '';
        this.numberofConfigurations = '';
        this.returnMessage = new MessageModel();
    }
    initializeMessage() {
        this.displayMessage = false;
        this.returnMessage = new MessageModel();
        this.messageHeader = '';
        this.returnMessage.listofItemsforDisplay = [];
        this.returnMessage.message = '';
        this.returnMessage.messageCode = '';
    }
    s2ab(s) {
        const buf = new ArrayBuffer(s.length);
        const view = new Uint8Array(buf);
        for (let i = 0; i !== s.length; ++i) {
            view[i] = s.charCodeAt(i) & 0xFF;
        }
        return buf;
    }
    // legacyIdChange() {
    //     this.isNoRecords = false;
    // }
    exportToExcel() {
        let timestamp = '';
        timestamp = CommonUtilitiesComponent.getCurrentDateTimeStamp();
        const sheetName = 'ShowAllPackagingMaterialsWhereUsed' + '_' + timestamp + '.xlsx';
        const ws_product = 'Product';
        const wb: WorkBook = { SheetNames: [], Sheets: {} };
        const ws_Config = 'Configurations';
        if (this.legacyId !== '' && this.legacyId.length === ConstantValues.productLegacyIDLength) {
            this.packagingMaterialWhereUsedService.getPackageDetailsForExportByLegacyID(this.legacyId).subscribe((productDetails: any) => {
                const ws: any = utils.json_to_sheet(productDetails);
                if (productDetails.length !== 0) {
                    wb.SheetNames.push(ws_product);
                    wb.Sheets[ws_product] = ws;
                }

                this.packagingMaterialWhereUsedService.
                    getPackageConfigDetailsForExportByLegacyID(this.legacyId).subscribe((config: any) => {
                        const wsConfig: any = utils.json_to_sheet(config);
                        if (config.length !== 0) {
                            wb.SheetNames.push(ws_Config);
                            wb.Sheets[ws_Config] = wsConfig;
                        }

                        if (productDetails.length !== 0 || config.length !== 0) {
                            this.isNoRecords = false;
                            const wbout = write(wb, { bookType: 'xlsx', bookSST: true, type: 'binary' });
                            saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }),
                                sheetName);
                        } else {
                            this.isNoRecords = true;
                        }
                    },
                    (err) => {
                        if (err !== undefined) {
                            // this.messageHeader = MessageItems.erroHeader;
                            // this.returnMessage.message = MessageItems.errorMessgae;
                            // this.messageIconType = APP_CONSTANTS.ErrorIcon;
                            // this.displayMessage = true;
                            this._router.navigate([Url.error]);
                            return;
                        }
                    });
            },
                (err) => {
                    if (err !== undefined) {
                        // this.messageHeader = MessageItems.erroHeader;
                        // this.returnMessage.message = MessageItems.errorMessgae;
                        // this.messageIconType = APP_CONSTANTS.ErrorIcon;
                        // this.displayMessage = true;
                        this._router.navigate([Url.error]);
                        return;
                    }
                });

        } else {
            this.messageHeader = MessageItems.erroHeader;
            this.returnMessage.message = MessageItems.packagingIdSearchMessage;
            this.messageIconType = APP_CONSTANTS.ErrorIcon;
            this.displayMessage = true;
            this.loading = false;
            return;
        }

    }
}
