import { APP_CONSTANTS } from './../../../shared/constants/app.constants';
import { LoadingModule } from 'ngx-loading';
import { MaintainProductCharacteristicsService } from './../../../services/admin/MaintainProductCharacteristics.service';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaintainProductCharacteristicsRouteModule } from './MaintainProductCharacteristics.routing';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { DialogDisplayModule } from './../../../shared/components/dialog-display/dialog-display.module';
// Import Components
import { MaintainProductCharacteristicsComponent } from './MaintainProductCharacteristics.component';

// Import Services

import {
    DialogModule,
    InputTextModule,
    DataTableModule,
    SharedModule,
    ListboxModule, ButtonModule, ConfirmDialogModule, PaginatorModule
} from 'primeng/primeng';

@NgModule({
    imports: [
        DialogModule,
        InputTextModule,
        DataTableModule,
        SharedModule,
        FormsModule,
        CommonModule,
        ListboxModule, ButtonModule, ReactiveFormsModule, BrowserModule, DialogDisplayModule, PaginatorModule,
        MaintainProductCharacteristicsRouteModule, ConfirmDialogModule,
        LoadingModule.forRoot(APP_CONSTANTS.loaderConfig)
    ],
    providers: [MaintainProductCharacteristicsService],
    declarations: [MaintainProductCharacteristicsComponent],
    exports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule
    ]
})
export class MaintainCharacteristicsModule {

}
