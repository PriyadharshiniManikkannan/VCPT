import { TestBed, inject } from '@angular/core/testing';

import { ViewProductConfigurationsComponent } from './ViewProductConfigurations.component';

describe('a ViewProductConfigurations component', () => {
	let component: ViewProductConfigurationsComponent;

	// register all needed dependencies
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [
				ViewProductConfigurationsComponent
			]
		});
	});

	// instantiation through framework injection
	beforeEach(inject([ViewProductConfigurationsComponent], (ViewProductConfigurationsComponent) => {
		component = ViewProductConfigurationsComponent;
	}));

	it('should have an instance', () => {
		expect(component).toBeDefined();
	});
});