import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewProductConfigurationsComponent } from './ViewProductConfigurations.component';

const viewproductconfigurationroutes: Routes = [  {
        path: '',
        component: ViewProductConfigurationsComponent
    },
    {
        path: ':id',
        component: ViewProductConfigurationsComponent
    }];
@NgModule({
    imports: [RouterModule.forChild(viewproductconfigurationroutes)],
    exports: [RouterModule]
})
export class ViewProductConfigurationRouteModule {

}
