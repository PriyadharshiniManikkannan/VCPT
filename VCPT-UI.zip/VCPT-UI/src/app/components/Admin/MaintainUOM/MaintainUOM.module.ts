import { APP_CONSTANTS } from './../../../shared/constants/app.constants';
import { LoadingModule } from 'ngx-loading';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MaintainUOMRouteModule } from './MaintainUOM.routing';
import { MaintainUOMComponent } from './MaintainUOM.component';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { DialogDisplayModule } from './../../../shared/components/dialog-display/dialog-display.module';
// Import Services
import { MaintainUOMService } from './../../../services/admin/MaintainUOM.service';

import { DataTableModule, SharedModule, DialogModule, ButtonModule, ConfirmDialogModule, PaginatorModule } from 'primeng/primeng';

@NgModule({
    imports: [
        DataTableModule,
        SharedModule,
        DialogModule,
        ButtonModule,
        FormsModule,
        CommonModule,
        DialogDisplayModule, ConfirmDialogModule,
        MaintainUOMRouteModule, ReactiveFormsModule, BrowserModule, PaginatorModule,
        LoadingModule.forRoot(APP_CONSTANTS.loaderConfig)],
    providers: [MaintainUOMService],
    declarations: [MaintainUOMComponent],
    exports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule
    ]

})
export class MaintainUOMModule {

}
