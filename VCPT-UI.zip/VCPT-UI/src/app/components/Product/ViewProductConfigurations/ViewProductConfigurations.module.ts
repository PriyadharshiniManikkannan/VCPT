import { DialogDisplayModule } from './../../../shared/components/dialog-display/dialog-display.module';
import { LoadingModule } from 'ngx-loading';
import { APP_CONSTANTS } from './../../../shared/constants/app.constants';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { ViewProductConfigurationRouteModule } from './ViewProductConfigurations.routing';
import { ViewProductConfigurationsService } from './../../../services/product/ViewProductConfiguration.service';
import { ViewProductConfigurations } from './../../../models/ViewProductConfigurations.model';

import {
    ListboxModule,
    AccordionModule,
    DataTableModule,
    SharedModule,
    InputMaskModule,
    DialogModule, ButtonModule, PaginatorModule
} from 'primeng/primeng';

import { ViewProductConfigurationsComponent } from './ViewProductConfigurations.component';

@NgModule({
    imports: [
        AccordionModule,
        FormsModule,
        CommonModule,
        ListboxModule,
        DataTableModule,
        SharedModule,
        DialogModule,
        InputMaskModule,
        ButtonModule,
        ViewProductConfigurationRouteModule,
        DialogDisplayModule,
        LoadingModule.forRoot(APP_CONSTANTS.loaderConfig),
        PaginatorModule
    ],
    declarations: [ViewProductConfigurationsComponent],
    providers: [ViewProductConfigurationsService]
})
export class ViewProductConfigurationsModule {

}
