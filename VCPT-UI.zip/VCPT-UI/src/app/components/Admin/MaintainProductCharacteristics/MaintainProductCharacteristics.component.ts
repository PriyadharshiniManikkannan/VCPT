import { Router } from '@angular/router';
import { APP_CONSTANTS, MessageItems, StatusCode, Url, excludeColumns } from './../../../shared/constants/app.constants';
import { MaintainProductCharacteristicsService } from './../../../services/admin/MaintainProductCharacteristics.service';
import { MaintainProductCharacteristics, UOM } from './../../../models/MaintainProductCharacteristics.model';
import { Component, OnInit } from '@angular/core';
import { ConstantValues, DataTypeDropdown } from '../../../shared/constants/app.constants';
import { ScreenTitles, FormLabelValues } from '../../../shared/constants/form.constants';
import { Message } from 'primeng/primeng';
import { FormGroup, FormControl, FormBuilder, Validators, NgForm } from '@angular/forms';
import { HostListener } from '@angular/core';
import { MessageModel } from './../../../models/MessageModel.model';

import { SelectItem, ConfirmationService } from 'primeng/primeng';
@Component(
    {
        templateUrl: './MaintainProductCharacteristics.component.html',
        styleUrls: ['./MaintainProductCharacteristics.component.scss'],
        providers: [ConfirmationService]
    }
)
export class MaintainProductCharacteristicsComponent implements OnInit {
    form: FormGroup;
    UOMDropdownItems: SelectItem[];
    selectedDataType: string;
    selectedUOM: string[];
    newProdConfig: boolean;
    displayDialog: boolean;
    Name: string;
    DataType: string;
    UOMArray: string[];
    data: any;
    err: any;
    statusCode: string;
    message: boolean;
    Submit: boolean;
    MaintainProductCharacteristics: MaintainProductCharacteristics[];
    UOM: UOM[];
    nameValidation: boolean;
    codeValidation: boolean;
    dataTypeValidation: boolean;
    recordsPerPage: number;
    firstRecordIndexofGrid: number;
    messageHeader: string;
    messageIconType: string;
    displayMessage: boolean;
    returnMessage: MessageModel;
    formTitle: any;
    formLabelValues: any;
    messageItems: any;
    ConstantValues: any;
    DataTypeDropdown: any;
    isChecked: boolean;
    isReadOnly: boolean;
    Range: string;
    public loading = false;
    constructor(private ProductCharacteristicsService: MaintainProductCharacteristicsService,
        private confirmationService: ConfirmationService,
        private _router: Router
        , private fb: FormBuilder

    ) { }


    @HostListener('window:beforeunload', ['$event'])
    unloadNotification($event: any) {

        if (this.form.dirty) {
            if (!this.Submit) { $event.returnValue = APP_CONSTANTS.UnsavedChangesMessage; }
        }
    }
    ngOnInit() {
        this.loading = true;
        this.isReadOnly = false;
        this.Range = FormLabelValues.range;
        this.Name = '';
        this.isChecked = false;
        this.formTitle = ScreenTitles;
        this.formLabelValues = FormLabelValues;
        this.ConstantValues = ConstantValues;
        this.messageItems = MessageItems;
        this.DataTypeDropdown = DataTypeDropdown;
        this.selectedDataType = '';
        this.returnMessage = new MessageModel();
        this.form = this.fb.group({
            name: new FormControl({ value: '' }),
            uom: new FormControl({ value: '' }),
            DataTypeDropdown: new FormControl({ value: '' }),
            chkRange: new FormControl({})
        });
        this.UOMDropdownItems = [];
        this.err = '';
        this.getProductCharacteristics();
        this.UOMDropdownItems = [];
        this.recordsPerPage = APP_CONSTANTS.recordsPerPageConstant;
        this.firstRecordIndexofGrid = 1;
        this.MaintainProductCharacteristics = [];
        this.ProductCharacteristicsService.getUOMList().
            subscribe((UOM: UOM[]) => UOM.forEach(element => {
                this.UOMDropdownItems.push({ label: element.uomName, value: element.uomId });
            }), (err: any) => {
                this.err = err;
                if (err !== undefined) {
                    this._router.navigate([Url.error]);
                }
            }, () => this.loading = false);
    }

    showDialogToAdd() {
        this.newProdConfig = true;
        this.selectedDataType = '';
        this.displayDialog = true;
        this.selectedUOM = [];
        this.Name = '';
        this.nameValidation = false;
        this.codeValidation = false;
        this.dataTypeValidation = false;
        this.form.get('chkRange').disable();
        this.Submit = false;
    }
    save(): void {
        this.Submit = false;
        this.UOMArray = [];
        this.nameValidation = false;
        this.codeValidation = false;
        this.dataTypeValidation = false;
        if (this.selectedUOM !== undefined && this.selectedUOM !== null) {
            for (const UOM of this.selectedUOM) {
                this.UOMArray.push(UOM);
            }
        }
        const main = new MaintainProductCharacteristics();
        if (this.Name !== '' && this.selectedDataType !== '' && this.UOMArray.length !== 0) {
            main.characteristicName = this.Name;
            main.dataType = this.selectedDataType;
            main.applicableUOMs = this.UOMArray;
            main.range = this.isChecked;
            this.ProductCharacteristicsService.addProductCharacteristics(main).subscribe(data => {
                this.data = data;
                if (this.data === StatusCode.successCode) {
                    this.statusCode = StatusCode.successCode;
                    this.displayDialog = false;
                    this.messageHeader = MessageItems.saveHeader;
                    this.returnMessage.message = MessageItems.saveMessage;
                    this.messageIconType = APP_CONSTANTS.InformationIcon;
                    this.displayMessage = true;
                    this.Submit = true;
                    this.form.reset();
                    this.getProductCharacteristics();
                    return;
                }
                if (this.data === StatusCode.duplicateCode) {
                    this.messageHeader = MessageItems.erroHeader;
                    this.returnMessage.message = MessageItems.duplicateCharacteristicsMessage;
                    this.messageIconType = APP_CONSTANTS.ErrorIcon;
                    this.displayMessage = true;
                    this.Submit = true;
                    return;
                }
            },
                (err) => {
                    if (err !== undefined) {
                        this._router.navigate([Url.error]);
                        this.form.reset();
                        return;
                    }
                }
            );
        } else {
            this.displayDialog = true;
            if (this.Name === '' && this.UOMArray.length !== 0 && this.selectedDataType !== '') {
                this.nameValidation = true;
                this.codeValidation = false;
                this.dataTypeValidation = false;
            }
            if (this.UOMArray.length === 0 && this.Name !== '' && this.selectedDataType !== '') {
                this.codeValidation = true;
                this.nameValidation = false;
                this.dataTypeValidation = false;
            }
            if (this.UOMArray.length === 0 && this.Name === '' && this.selectedDataType === '') {
                this.codeValidation = true;
                this.nameValidation = true;
                this.dataTypeValidation = true;
            }
            if (this.Name !== '' && this.UOMArray.length !== 0 && this.selectedDataType === '') {
                this.nameValidation = false;
                this.codeValidation = false;
                this.dataTypeValidation = true;
            }
            if (this.Name !== '' && this.UOMArray.length === 0 && this.selectedDataType === '') {
                this.nameValidation = false;
                this.codeValidation = true;
                this.dataTypeValidation = true;
            }
            if (this.Name === '' && this.UOMArray.length === 0 && this.selectedDataType !== '') {
                this.nameValidation = true;
                this.codeValidation = true;
                this.dataTypeValidation = false;
            }
            if (this.Name === '' && this.UOMArray.length !== 0 && this.selectedDataType === '') {
                this.nameValidation = true;
                this.codeValidation = false;
                this.dataTypeValidation = true;
            }
        }
    }
    cancel() {
        // this.UOMArray = [];
        // if (this.selectedUOM !== undefined && this.selectedUOM !== null) {
        //     for (const UOM of this.selectedUOM) {
        //         this.UOMArray.push(UOM);
        //     }
        // }

        if (!this.form.dirty) {
            this.displayDialog = false;
        } else {
            this.confirmationService.confirm({
                message: APP_CONSTANTS.UnsavedChangesMessage,
                icon: APP_CONSTANTS.WarningIcon,
                header: 'Confirmation',
                accept: () => {
                    this.displayDialog = false; this.Submit = true; this.form.reset();
                },
                reject: () => {
                    this.displayDialog = true;
                }
            });
        }
    }
    getProductCharacteristics() {
        this.ProductCharacteristicsService.getProductCharacteristics().
            subscribe((MaintainProductCharacteristics: MaintainProductCharacteristics[]) => {
                this.MaintainProductCharacteristics = MaintainProductCharacteristics;
            },
            (err: any) => {
                this.err = err;
                if (err !== undefined) {
                    this._router.navigate([Url.error]);
                    return;
                }
            });
    }
    onGridPageChange(event: any) {
        this.firstRecordIndexofGrid = event.first === 1 ? event.first : event.first + 1;
        this.recordsPerPage = event.first !== 1 ? event.rows + event.first : event.rows;
    }
    dataTypeChange() {
        this.isChecked = false;
        for (let i = 0; i <= excludeColumns.RangeColumns.length - 1; i++) {
            if (excludeColumns.RangeColumns[i].toString().trim().toLowerCase() === this.selectedDataType.toString().trim().toLowerCase()) {
                this.form.get('chkRange').enable();
            } else {
                this.form.get('chkRange').disable();
            }
        }
    }
}
