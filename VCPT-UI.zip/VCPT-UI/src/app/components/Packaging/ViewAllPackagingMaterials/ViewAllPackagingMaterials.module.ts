import { DialogDisplayModule } from './../../../shared/components/dialog-display/dialog-display.module';
import { APP_CONSTANTS } from './../../../shared/constants/app.constants';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ViewAllPackagingMaterialsRouteModule } from './../../Packaging/ViewAllPackagingMaterials/ViewAllPackagingMaterials.routing';
 import { ViewAllPackagingMaterialsComponent } from './../../Packaging/ViewAllPackagingMaterials/ViewAllPackagingMaterials.component';
import { ViewAllPackagingMaterialService } from './../../../services/packaging/ViewAllPackagingMaterials.service';

import { DialogModule, InputMaskModule, MessagesModule, ListboxModule, DataTableModule, AccordionModule,
     ButtonModule, ConfirmationService, PaginatorModule, ConfirmDialogModule, RadioButtonModule } from 'primeng/primeng';
@NgModule({
    imports: [
         CommonModule,
        ViewAllPackagingMaterialsRouteModule,
        DialogModule,
        InputMaskModule,
        ConfirmDialogModule,
        ListboxModule,
        ButtonModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        DialogDisplayModule,
        DataTableModule,
        RadioButtonModule,
        PaginatorModule,
        LoadingModule.forRoot(APP_CONSTANTS.loaderConfig), AccordionModule
        ],
    providers: [ViewAllPackagingMaterialService, ConfirmationService],
    declarations: [ViewAllPackagingMaterialsComponent]
})
export class ViewAllPackagingMaterialsModule {

}
