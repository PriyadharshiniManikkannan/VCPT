import { UnsavedChangesComponent } from './UnsavedChanges.component';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';

@NgModule({
    imports: [
        CommonModule,
        ConfirmDialogModule
    ],
    declarations: [UnsavedChangesComponent],
    providers: [ConfirmationService]
})
export class UnsavedChangesModule {

}
