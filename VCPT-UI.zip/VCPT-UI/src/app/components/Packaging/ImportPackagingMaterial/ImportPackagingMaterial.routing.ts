import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ImportPackagingMaterialComponent } from './ImportPackagingMaterial.component';

const importPackagingMaterialRoutes: Routes = [
    {
        path: '',
        component: ImportPackagingMaterialComponent
    },
     {
        path: ':id',
        component: ImportPackagingMaterialComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(importPackagingMaterialRoutes)],
    exports: [RouterModule]
})
export class ImportPackagingMaterialRouteModule {

}
