import { NotAuthorizedComponent } from './NotAuthorized.component';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { NotAuthorizedRoutingModule } from './NotAuthorized.routing';

@NgModule({
    imports: [NotAuthorizedRoutingModule, CommonModule],
    declarations: [NotAuthorizedComponent],
})
export class NotAuthorizedModule {

}
