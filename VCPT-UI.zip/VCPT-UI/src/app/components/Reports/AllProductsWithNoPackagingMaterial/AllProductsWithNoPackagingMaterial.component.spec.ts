import { TestBed, inject } from '@angular/core/testing';
import { HttpModule } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Rx';

import { AllConfigurationsWithNoPackagingMaterialComponent } from './AllProductsWithNoPackagingMaterial.component';
import { AllConfigurationsWithNoPackagingMaterialService } from './shared/AllProductsWithNoPackagingMaterial.service';
import { AllConfigurationsWithNoPackagingMaterial } from './shared/AllProductsWithNoPackagingMaterial.model';

describe('a AllConfigurationsWithNoPackagingMaterial component', () => {
	let component: AllConfigurationsWithNoPackagingMaterialComponent;

	// register all needed dependencies
	beforeEach(() => {
		TestBed.configureTestingModule({
			imports: [HttpModule],
			providers: [
				{ provide: AllConfigurationsWithNoPackagingMaterialService, useClass: MockAllConfigurationsWithNoPackagingMaterialService },
				AllConfigurationsWithNoPackagingMaterialComponent
			]
		});
	});

	// instantiation through framework injection
	beforeEach(inject([AllConfigurationsWithNoPackagingMaterialComponent], (AllConfigurationsWithNoPackagingMaterialComponent) => {
		component = AllConfigurationsWithNoPackagingMaterialComponent;
	}));

	it('should have an instance', () => {
		expect(component).toBeDefined();
	});
});

// Mock of the original AllConfigurationsWithNoPackagingMaterial service
class MockAllConfigurationsWithNoPackagingMaterialService extends AllConfigurationsWithNoPackagingMaterialService {
	getList(): Observable<any> {
		return Observable.from([ { id: 1, name: 'One'}, { id: 2, name: 'Two'} ]);
	}
}
