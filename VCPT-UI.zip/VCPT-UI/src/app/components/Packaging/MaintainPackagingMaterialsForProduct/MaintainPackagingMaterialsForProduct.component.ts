import { GGSMStatusModel } from './../../../models/GGSMStatus.model';
import { VCPTStatusModel } from './../../../models/VCPTStatus.model';
import { APP_CONSTANTS, StatusCode, Url } from './../../../shared/constants/app.constants';
import { Component, OnInit, HostListener, Input } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { MaintainPackagingMaterialsForProductService } from './../../../services/packaging/MaintainPackagingMaterialsForProduct.service';
import { PackagingMaterial } from './../../../models/PackagingMaterial.model';
import { ViewProductMaster } from './../../../models/ViewProductMaster.model';
import { utils, write, WorkBook } from 'xlsx';
import { saveAs } from 'file-saver';
import { element } from 'protractor';
import { ConstantValues, RouteURLs, MessageItems } from '../../../shared/constants/app.constants';
import { MessageModel } from './../../../models/MessageModel.model';
import { FormLabelValues, ScreenTitles } from './../../../shared/constants/form.constants';
import { FormGroup, FormControl, FormBuilder, Validators, NgForm } from '@angular/forms';
import { UnsavedChangesComponent } from './../../../shared/components/UnsavedChanges/UnsavedChanges.component';
import { CanComponentDeactivate } from './../../../services/guards/CanComponentDeactivate.guard.service';
import { Observable } from 'rxjs/Observable';

import { SelectItem, Message } from 'primeng/primeng';
import { ConfirmationService, DialogModule } from 'primeng/primeng';
@Component({
    templateUrl: './MaintainPackagingMaterialsForProduct.component.html',
    styleUrls: ['./MaintainPackagingMaterialsForProduct.component.scss']
})

export class MaintainPackagingMaterialsForProductComponent implements OnInit {
    form: FormGroup;
    displayConfigGrid: boolean;
    viewPackagingMaterialForProduct: any[];
    cols: any[] = [];
    legacyID: string;
    productID: any;
    SAPRelevancy: string;
    ProductCode: string;
    ProductDesc: string;
    productStatusDesc: VCPTStatusModel;
    productBusinessLifeCycleStatus: GGSMStatusModel;
    Facility: string;
    data: any;
    scrapMessage: string;
    err: any;
    message: boolean;
    editAccess: boolean;
    adminAccess: boolean;
    viewProductDetails: any;
    disabled: boolean;
    facilityCollection: any[];
    packagingExcel: any[];
    displayButton: boolean;
    productComments: string;
    recordsPerPage: number;
    firstRecordIndexofGrid: number;
    messageHeader: string;
    messageIconType: string;
    displayMessage: boolean;
    returnMessage: MessageModel;
    formLabels: any;
    formTitle: any;
    displayDialog: boolean;
    popupTitle: string;
    materialDesc: string;
    sAPText: string;
    quantityUOM: string;
    quantity: any;
    packagingLegacyID: string;
    scrapPercent: string;
    unsavedChangesComponent: UnsavedChangesComponent;
    submit: boolean;
    productDetailSelected: boolean;
    packageConfigMapID: number;
    isQuantityValidate: boolean;
    isScrapValidate: boolean;
    isLegacyIdValidate: boolean;
    legacyMessage: string;
    previousProductId: number;
    previousLegacyId: string;
    packagingMaterialId: number;
    isLegacyBoxDisable: boolean;
    ConstantValues: any;
    // Loading variable for ngx-loading component
    public loading = false;

    constructor(private maintainPackagingMaterialsForProductService: MaintainPackagingMaterialsForProductService, private router: Router,
        private activatedRoute: ActivatedRoute,
        private confirmationService: ConfirmationService,
        private fb: FormBuilder
    ) { }
    ngOnInit() {
        this.formLabels = FormLabelValues;
        this.ConstantValues = ConstantValues;
        this.loading = true;
        this.disabled = true;
        this.form = this.fb.group({
            quantity: new FormControl({ value: '' }),
            scrap: new FormControl({ value: '1' }),
        });
        this.initializeForm();
        this.returnMessage = new MessageModel();
        this.activatedRoute.params.subscribe((params: Params) => {
            this.legacyID = params['id'];

            if (this.legacyID !== undefined && this.legacyID !== '' && this.legacyID.length === ConstantValues.productLegacyIDLength) {
                const prod = new ViewProductMaster();
                prod.productLegacyID = this.legacyID;
                prod.facilityCode = '';
                prod.productStatus.statusCode = 0;
                prod.productBusinessLifeCycleStatus.statusCode = '';
                prod.productDescription = '';
                prod.productCode = '';
                if (this.previousProductId === 0 || this.previousProductId !== this.productID) {
                    if (this.productID !== undefined && this.productID !== 0) {
                        this.previousProductId = this.productID;
                    }
                }
                if (this.previousLegacyId === '' || this.previousLegacyId === undefined) {
                    this.previousLegacyId = this.legacyID;
                    if (this.previousProductId !== 0) {
                        this.unlockProductforEdit(false);
                    }
                    this.getProductDetails(prod);
                }
            }
        }, (error: Error) => {
            this.router.navigate([Url.error]);
            this.loading = false;
        }
        );
        this.loading = false;
    }
    initializeForm() {
        this.loading = true;
        this.formTitle = ScreenTitles;
        this.SAPRelevancy = '';
        this.ProductCode = '';
        this.ProductDesc = '';
        this.Facility = '';
        this.productComments = '';
        this.displayConfigGrid = false;
        this.editAccess = true;
        this.adminAccess = true;
        this.recordsPerPage = APP_CONSTANTS.recordsPerPageConstant;
        this.firstRecordIndexofGrid = 1;
        this.displayButton = false;
        this.viewPackagingMaterialForProduct = [];
        this.displayDialog = false;
        this.popupTitle = '';
        this.submit = false;
        this.productDetailSelected = false;
        this.isQuantityValidate = false;
        this.isScrapValidate = false;
        this.isLegacyIdValidate = false;
        this.previousProductId = 0;
        this.packagingMaterialId = 0;
        this.unsavedChangesComponent = new UnsavedChangesComponent(this.confirmationService);
        this.loading = false;
    }
    initializePopUpScreen() {
        this.loading = true;
        this.scrapPercent = '1';
        this.quantity = '';
        this.quantityUOM = '';
        this.packagingLegacyID = '';
        this.sAPText = '';
        this.materialDesc = '';
        this.data = '';
        this.scrapMessage = '';
        this.isQuantityValidate = false;
        this.isScrapValidate = false;
        this.isLegacyIdValidate = false;
        this.legacyMessage = '';
        this.loading = false;
    }
    showResults(): void {
        this.loading = true;
        this.displayConfigGrid = false;
        this.displayButton = false;
        this.viewPackagingMaterialForProduct = [];
        if (this.legacyID !== undefined && this.legacyID !== '' && this.legacyID.length === ConstantValues.productLegacyIDLength) {
            const prod = new ViewProductMaster();
            prod.productLegacyID = this.legacyID;
            if (this.previousProductId === 0 || this.previousProductId !== this.productID) {
                if (this.productID !== undefined && this.productID !== 0) {
                    this.previousProductId = this.productID;
                }
            }

            if (this.previousLegacyId === '' || this.previousLegacyId === undefined) {
                this.previousLegacyId = this.legacyID;
                if (this.previousProductId !== 0) {
                    this.unlockProductforEdit(false);
                }
                this.getProductDetails(prod);
            } else {
                this.previousLegacyId = this.legacyID;
                this.unlockProductforEdit(false);
                this.getProductDetails(prod);
            }
        } else {
            this.SAPRelevancy = '';
            this.ProductCode = '';
            this.ProductDesc = '';
            this.Facility = '';
            this.productComments = '';
            this.messageHeader = MessageItems.productHeader;
            this.returnMessage.message = MessageItems.draftMessage;
            this.messageIconType = APP_CONSTANTS.ErrorIcon;
            this.displayMessage = true;
            this.loading = false;
            return;
        }
    }
    getPackagingDetails() {
        this.loading = true;
        this.disabled = true;
        this.viewPackagingMaterialForProduct = [];
        this.maintainPackagingMaterialsForProductService.getPackagingDetailsByProductId(this.productID).
            subscribe((viewPackagingMaterialForProduct: any) => {
                this.viewPackagingMaterialForProduct = viewPackagingMaterialForProduct;
                if (this.viewPackagingMaterialForProduct.length !== 0) {
                    this.getColumnforGrid(this.viewPackagingMaterialForProduct);
                    this.displayConfigGrid = true;
                    this.disabled = false;
                } else {
                    this.displayConfigGrid = false;
                    this.disabled = true;
                }
            }, (err: any) => {
                this.err = err;
                if (err !== undefined) {
                    this.initializeMessage();
                    this.router.navigate([Url.error]);
                }
            }, () => this.loading = false);
    }
    initializeMessage() {
        this.returnMessage = new MessageModel();
        this.messageHeader = '';
        this.returnMessage.listofItemsforDisplay = [];
        this.returnMessage.message = '';
        this.returnMessage.messageCode = '';
    }
    getColumnforGrid(obj: any): void {
        if (obj && obj.length) {
            const keys = Object.keys(obj[0]);
            const cols = [];
            keys.forEach(function (k: any) {
                let s = '';
                s = k.split('_').join(' ');
                if (k.toString().toLowerCase() === FormLabelValues.sapText.toString().toLowerCase()) {
                    s = FormLabelValues.sapText;
                }
                if (k.toString().toLowerCase() === FormLabelValues.vcptPackagingStatus.toString().toLowerCase()) {
                    s = FormLabelValues.vcptPackagingStatus;
                }
                if (k.toString().toLowerCase() !== FormLabelValues.packagingMaterialId.toString().toLowerCase()) {
                    cols.push({ field: k, header: s });
                }

            });
            this.cols = cols;
        }
    }
    getProductDetails(prod) {
        this.loading = true;
        this.SAPRelevancy = '';
        this.ProductCode = '';
        this.ProductDesc = '';
        this.productID = 0;
        this.Facility = '';
        this.data = '';
        this.productComments = '';
        this.viewProductDetails = [];
        this.viewPackagingMaterialForProduct = [];
        this.maintainPackagingMaterialsForProductService.getProductDetailsByLegacyID(prod).
            subscribe((ViewProductDetails: any) => {
                this.viewProductDetails = ViewProductDetails;
                if (this.viewProductDetails && this.viewProductDetails.message) {
                    this.initializeMessage();
                    this.messageHeader = 'Get Details';
                    this.returnMessage.messageCode = this.viewProductDetails.messageCode;
                    this.returnMessage.message = this.viewProductDetails.message;
                    this.returnMessage.messageType = this.viewProductDetails.messageType;
                    this.getIconforMessageDisplay();
                    this.displayMessage = true;
                    this.productDetailSelected = false;
                } else if (this.viewProductDetails) {
                    const prodStatus = this.viewProductDetails.vcptProductStatus.statusDesc;
                    const busStatus = this.viewProductDetails.productBusinessLifeCycleStatus.statusDesc;
                    this.productStatusDesc = prodStatus;
                    this.productBusinessLifeCycleStatus = busStatus;
                    if (this.productStatusDesc.toString().toLowerCase().trim() ===
                        ConstantValues.productStatusActive.toString().toLowerCase().trim()
                        && this.productBusinessLifeCycleStatus.toString().toLowerCase().trim() !==
                        ConstantValues.productStatusInActive.toString().toLowerCase().trim()
                        && this.productBusinessLifeCycleStatus.toString().toLowerCase() !== ConstantValues.statusObsolete.toLowerCase()
                    ) {
                        this.SAPRelevancy = this.viewProductDetails.sapRelevancyStatus;
                        this.ProductCode = this.viewProductDetails.productCode;
                        this.ProductDesc = this.viewProductDetails.productDescription;
                        this.productID = this.viewProductDetails.productId;
                        this.productComments = this.viewProductDetails.productComments;
                        const facilityItems = [];
                        if (this.viewProductDetails.applicableFacilities !== undefined) {
                            this.viewProductDetails.applicableFacilities.forEach(e => {
                                facilityItems.push({
                                    label: e.facilityName,
                                    value: e.facilityName
                                });
                            });
                            facilityItems.sort(function (a, b) {
                                return a.label.localeCompare(b.label);
                            });
                            this.Facility = '';
                            facilityItems.forEach(e => {
                                this.Facility += e.label + ', ';
                            });
                            if (this.Facility !== '') {
                                this.Facility = this.Facility.substring(0, this.Facility.length - 2);
                            }
                        }
                        this.productDetailSelected = true;
                        this.getPackagingDetails();
                    } else if (this.productStatusDesc.toString().toLowerCase().trim() ===
                        ConstantValues.productStatusDraft.toString().toLowerCase().trim()) {
                        this.messageHeader = MessageItems.productHeader;
                        this.returnMessage.message = MessageItems.draftMessage;
                        this.messageIconType = APP_CONSTANTS.ErrorIcon;
                        this.initializeForm();
                        this.displayMessage = true;
                    } else if (this.productStatusDesc.toString().toLowerCase().trim() ===
                        ConstantValues.productStatusInActive.toString().toLowerCase().trim()) {
                        this.messageHeader = MessageItems.productHeader;
                        this.returnMessage.message = MessageItems.inactiveMessage;
                        this.messageIconType = APP_CONSTANTS.ErrorIcon;
                        this.initializeForm();
                        this.displayMessage = true;
                    } else {
                        this.messageHeader = MessageItems.productHeader;
                        this.returnMessage.message = MessageItems.inactiveMessage;
                        this.messageIconType = APP_CONSTANTS.ErrorIcon;
                        this.initializeForm();
                        this.displayMessage = true;
                    }

                } else {
                    this.initializeForm();
                    this.messageHeader = MessageItems.productHeader;
                    this.returnMessage.message = MessageItems.draftMessage;
                    this.messageIconType = APP_CONSTANTS.ErrorIcon;
                    this.displayMessage = true;
                }
            }, (error: Error) => {
                this.router.navigate([Url.error]);
                this.loading = false;
            }, () => this.loading = false
            );
    }
    onGridPageChange(event: any) {
        this.firstRecordIndexofGrid = event.first === 1 ? event.first : event.first + 1;
        this.recordsPerPage = event.first !== 1 ? event.rows + event.first : event.rows;
    }
    viewPackagingMaterials() {
        if (this.legacyID !== '' && this.legacyID.length === ConstantValues.productLegacyIDLength) {
            this.router.navigateByUrl(RouteURLs.ViewPackagingMaterialsforProductPath + ';id=' + this.legacyID);
        }
    }
    edit(packageDetails: any) {
        this.initializePopUpScreen();
        this.isLegacyBoxDisable = true;
        this.displayDialog = true;
        this.popupTitle = 'Edit Packaging Details for Product';
        this.packagingLegacyID = packageDetails.packagingMaterialLegacyID;
        this.materialDesc = packageDetails.packagingMaterialDescription;
        this.sAPText = packageDetails.sapBasicDataText;
        this.quantityUOM = packageDetails.quantityUOM;
        this.quantity = packageDetails.quantity;
        this.packageConfigMapID = packageDetails.pkgConfigMapId;
        this.packagingMaterialId = packageDetails.packagingMaterialID;
        this.scrapPercent = packageDetails.scrap;
    }
    delete(packageDetails: any) {
        this.confirmationService.confirm({
            message: MessageItems.packagingAssociationDeleteMessage,
            icon: APP_CONSTANTS.WarningIcon,
            header: 'Confirmation',
            accept: () => {
                this.maintainPackagingMaterialsForProductService.deletePackageAssociation(packageDetails.pkgConfigMapId).
                    subscribe((data: any) => {
                        this.getPackagingDetails();
                    });
            },
            reject: () => {
                return;
            }
        });
    }
    showDialogToAdd() {
        if (this.viewProductDetails && !this.viewProductDetails.message) {
            this.initializePopUpScreen();
            this.isLegacyBoxDisable = false;
            this.displayDialog = true;
            this.popupTitle = 'Add Packaging Details for Product';
            this.packageConfigMapID = 0;
        }
    }
    legacyIdChange() {
        if (this.packagingLegacyID.length === ConstantValues.productLegacyIDLength) {
            this.maintainPackagingMaterialsForProductService.getPackagingDetailsByLegacyId(this.packagingLegacyID).
                subscribe((data: any) => {
                    if (data && !data.message) {
                        this.loading = false;
                        this.materialDesc = data.packagingMaterialDescription;
                        this.sAPText = data.sapBasicDataText;
                        this.quantityUOM = data.quantityUOM;
                        this.packagingMaterialId = data.packagingMaterialID;
                    } else {
                        this.displayDialog = false;
                        this.messageHeader = MessageItems.erroHeader;
                        this.returnMessage.message = data.message;
                        this.messageIconType = APP_CONSTANTS.ErrorIcon;
                        this.displayMessage = true;
                        this.loading = false;
                        return;

                    }
                });

        }

    }
    save() {
        this.isLegacyIdValidate = false;
        this.isScrapValidate = false;
        this.isQuantityValidate = false;
        const packagingDetails = new PackagingMaterial();
        packagingDetails.packagingMaterialLegacyID = this.packagingLegacyID;
        packagingDetails.packagingMaterialDescription = this.materialDesc;
        packagingDetails.sapBasicDataText = this.sAPText;
        packagingDetails.quantityUOM = this.quantityUOM;
        packagingDetails.quantity = this.quantity;
        packagingDetails.scrap = this.scrapPercent;
        packagingDetails.PkgConfigMapId = this.packageConfigMapID;
        packagingDetails.productID = this.productID;
        packagingDetails.PackagingMaterialID = this.packagingMaterialId;
        //    packagingDetails.createdBy = 'a5r88zz';
        this.scrapMessage = '';
        if (this.packagingLegacyID === '' || this.packagingLegacyID === undefined ||
            this.packagingLegacyID.length !== ConstantValues.productLegacyIDLength) {
            this.legacyMessage = MessageItems.packagingLegacyEmptyMessage;
            this.isLegacyIdValidate = true;
            this.isScrapValidate = false;
            this.isQuantityValidate = false;
            return;
        }
        if (this.quantity === '' || this.quantity === undefined || this.quantity === null) {
            this.data = MessageItems.quantityEmptyMessage;
            this.isQuantityValidate = true;
            this.isScrapValidate = false;
            this.isLegacyIdValidate = false;
            return;
        }
        if (this.scrapPercent === '' || this.scrapPercent === undefined || this.scrapPercent === null) {
            this.scrapMessage = MessageItems.scrapEmptyMessage;
            this.isScrapValidate = true;
            this.isQuantityValidate = false;
            this.isLegacyIdValidate = false;
            return;
        }
        this.maintainPackagingMaterialsForProductService.savePackageAssociation(packagingDetails).
            subscribe((returnMessage: MessageModel) => {
                this.initializeMessage();
                this.returnMessage.message = returnMessage.message;
                this.returnMessage.messageType = returnMessage.messageType;
                this.getIConforMessageDisplay();
                this.displayMessage = true;
                this.submit = true;
                this.getPackagingDetails();
                this.displayDialog = false;
                this.form.reset();
            }, (error: Error) => {
                this.router.navigate([Url.error]);
                this.loading = false;
            }
            );
    }
    getIConforMessageDisplay() {
        switch (this.returnMessage.messageType.trim().toUpperCase()) {
            case 'Error'.toUpperCase(): this.messageIconType = APP_CONSTANTS.ErrorIcon;
                this.messageHeader = MessageItems.erroHeader; break;
            case 'Information'.toUpperCase(): this.messageIconType = APP_CONSTANTS.InformationIcon;
                this.messageHeader = MessageItems.saveHeader; break;
            case 'Warning'.toUpperCase(): this.messageIconType = APP_CONSTANTS.WarningIcon; break;
            default: this.messageIconType = APP_CONSTANTS.InformationIcon; break;
        }
    }

    @HostListener('window:beforeunload', ['$event'])
    canNavigateAway(event: any) {
        if (this.checkDirtyForm()) {
            event.returnValue = APP_CONSTANTS.UnsavedChangesMessage;
        }
    }

    @HostListener('window:unload', ['$event'])
    unloadPage(event: any) {
        this.unlockProductforEdit(true);
    }
    canDeactivate(): Observable<boolean> | boolean {
        if (this.checkDirtyForm()) {
            if (this.getUserConfirmation().first()) {
                this.unlockProductforEdit(false);
                return true;
            } else {
                return false;
            }
        } else {
            this.unlockProductforEdit(false);
            return true;
        }
    }

    getUserConfirmation(): Observable<boolean> {
        return this.unsavedChangesComponent.getUnsavedChangesConfirmation();
    }
    checkDirtyForm(): boolean {
        return this.form ? this.form.dirty : false;
    }
    cancel() {
        if (!this.form.dirty) {
            this.displayDialog = false;
        } else {
            this.confirmationService.confirm({
                message: APP_CONSTANTS.UnsavedChangesMessage,
                icon: APP_CONSTANTS.WarningIcon,
                header: 'Confirmation',
                accept: () => {
                    this.displayDialog = false;
                    this.form.reset();
                },
                reject: () => {
                    this.displayDialog = true;
                }
            });
        }
    }
    unlockProductforEdit(synchronousCall = false) {
        if (this.previousProductId !== 0 && this.previousProductId !== null) {
            this.sendUnlockRequest(this.previousProductId, synchronousCall);
        } else {
            this.sendUnlockRequest(this.productID, synchronousCall);
        }
    }
    getIconforMessageDisplay() {
        if (this.returnMessage.messageType) {
            switch (this.returnMessage.messageType.trim().toUpperCase()) {
                case 'Error'.toUpperCase(): this.messageIconType = APP_CONSTANTS.ErrorIcon; break;
                case 'Information'.toUpperCase(): this.messageIconType = APP_CONSTANTS.InformationIcon; break;
                case 'Warning'.toUpperCase(): this.messageIconType = APP_CONSTANTS.WarningIcon; break;
                default: this.messageIconType = APP_CONSTANTS.InformationIcon; break;
            }
        } else {
            this.messageIconType = APP_CONSTANTS.InformationIcon;
        }
    }
    sendUnlockRequest(productId: number, synchronousCall: boolean) {
        this.loading = true;
        if (!synchronousCall) {
            this.maintainPackagingMaterialsForProductService.unlockProductforEdit(productId).
                subscribe((data: any) => {
                }, (error: Error) => {
                    this.router.navigate([Url.error]);
                    this.loading = false;
                });
        } else {
            this.maintainPackagingMaterialsForProductService.unlockProductforEditSynchronous(productId);
            this.loading = false;
        }
    }
}
