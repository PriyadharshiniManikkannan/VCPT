import { ProductConfigurationPackagingMaterialMapping } from './ProductConfigurationPackagingMaterialMapping.model';
import { GGSMStatusModel } from './GGSMStatus.model';
import { VCPTStatusModel } from './VCPTStatus.model';
export class PackagingMaterial {
    packagingMaterialLegacyID: string;
    packagingMaterialDescription: string;
    sapBasicDataText: string;
    quantityUOM: any;
    materialBusinessLifeCycleStatus: GGSMStatusModel;
    vcptMaterialStatus: VCPTStatusModel;
    PackagingMaterialID: number;
    ModifiedBy: string;
    quantity: any;
    scrap: string;
    PkgConfigMapId: number;
    createdBy: string;
    productID: number;
    productConfigurationMapping: ProductConfigurationPackagingMaterialMapping;
 public constructor() {
        this.packagingMaterialLegacyID = '';
        this.packagingMaterialDescription = '';
        this.sapBasicDataText = '';
        this.quantityUOM = '';
        this.PackagingMaterialID = 0;
        this.materialBusinessLifeCycleStatus = new GGSMStatusModel();
        this.vcptMaterialStatus = new VCPTStatusModel();
        this.ModifiedBy = '';
        this.productConfigurationMapping = new  ProductConfigurationPackagingMaterialMapping();
    }
}
