export class UserDetails {
    private static _userDetail: UserDetails = new UserDetails();
    private _userID: string;
    private _fullName = 'Guest User';
    private _isAdminUser = false;
    private _isReadOnlyUser = true;
    private _userToken: string;
    private _isValidUser = false;
    constructor() {
        if (UserDetails._userDetail) {
            throw new Error('Use Get Instance for initialization');
        }
        UserDetails._userDetail = this;
    }
    public static getInstance(): UserDetails {
        return UserDetails._userDetail;
    }
    public get UserID(): string {
        return this._userID;
    }
    public setUserID(value: string) {
        this._userID = value;
    }

    public get FullName(): string {
        return this._fullName;
    }
    public setFullName(value: string) {
        this._fullName = value;
    }

    public get IsAdminUser(): boolean {
        return this._isAdminUser;
    }
    public setIsAdminUser(value: boolean) {
        this._isAdminUser = value;
    }

    public get IsReadOnlyUser(): boolean {
        return this._isReadOnlyUser;
    }
    public setIsReadOnlyUser(value: boolean) {
        this._isReadOnlyUser = value;
    }

    public get UserToken(): string {
        return this._userToken;
    }
    public setUserToken(value: string) {
        this._userToken = value;
    }

    public get IsValidUser(): boolean {
        return this._isValidUser;
    }
    public setIsValidUser(value: boolean) {
        this._isValidUser = value;
    }
}
