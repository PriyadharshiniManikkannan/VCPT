import { Report } from './../../models/Report.model';
import { Url } from './../../shared/constants/app.constants';
import { HttpService } from './../base/http.service';
import { Observable } from 'rxjs/Observable';
import {  Http, Response, RequestOptions, Headers  } from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';


@Injectable()
export class ExtractAllDataService {
    constructor(private httpService: HttpService) { }
   extractAllData( facilities: string, legacyId: string ) {
    let jsonParam: any;
    jsonParam = {
      'facilityId': facilities,
      'productLegacyId': legacyId
    };
    return this.httpService.get(Url.ExtractAllDataUrl, jsonParam);
  }
}
