import { Url } from './../shared/constants/app.constants';
import { HttpService } from './base/http.service';
import { Injectable } from '@angular/core';

@Injectable()
export class HomeService {

  constructor(private httpService: HttpService) { }

  getHelpFileURL() {
    return this.httpService.get(Url.HelpFileUrl);
  }
}
