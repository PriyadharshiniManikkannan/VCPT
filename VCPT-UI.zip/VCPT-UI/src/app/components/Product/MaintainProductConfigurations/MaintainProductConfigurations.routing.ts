import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MaintainProductConfigurationsComponent } from './MaintainProductConfigurations.component';

const maintainproductconfigurationroutes: Routes = [
     {
        path: '',
        component: MaintainProductConfigurationsComponent
    },
    {
        path: ':id',
        component: MaintainProductConfigurationsComponent
    }];
@NgModule({
    imports: [RouterModule.forChild(maintainproductconfigurationroutes)],
    exports: [RouterModule]
})
export class MaintainProductConfigurationRouteModule {

}
