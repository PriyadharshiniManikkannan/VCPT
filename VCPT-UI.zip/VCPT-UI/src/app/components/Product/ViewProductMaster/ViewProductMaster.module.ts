import { APP_CONSTANTS } from './../../../shared/constants/app.constants';
import { LoadingModule } from 'ngx-loading';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { ViewProductMasterComponent } from './ViewProductMaster.Component';
import { ViewProductRoutingModule } from './ViewProductMaster.routing';
import { ViewProductMasterService  } from './../../../services/product/ViewProductMaster.service';
import { ViewProductMaster } from './../../../models/ViewProductMaster.Model';
import {HttpModule} from '@angular/http';
import {RouterModule} from '@angular/router';
import { DialogDisplayModule } from './../../../shared/components/dialog-display/dialog-display.module';

import { InputMaskModule, DataTableModule, AccordionModule,
     SharedModule, DialogModule, ButtonModule, PaginatorModule } from 'primeng/primeng';

@NgModule({
    imports: [
        FormsModule,
        CommonModule,
        InputMaskModule,
        DataTableModule,
        SharedModule, DialogModule, ButtonModule, HttpModule, RouterModule, DialogDisplayModule,
        ViewProductRoutingModule,
         LoadingModule.forRoot(APP_CONSTANTS.loaderConfig),
         PaginatorModule,
         AccordionModule
    ],
    declarations: [ViewProductMasterComponent],
    providers : [ViewProductMasterService]
})
export class ViewProductMasterModule {

}
