import { UserDetails } from './../models/UserDetails.model';
import { Observer } from 'rxjs/Observer';
import { Observable } from 'rxjs/Observable';
import { SessionConstants, Url } from './../shared/constants/app.constants';
import { Injectable, OnInit } from '@angular/core';
import { HttpService } from './base/http.service';

@Injectable()
export class SecurityService implements OnInit {
    userDetails: any;
    constructor(private http: HttpService) {

    }

    ngOnInit() {
        this.userDetails = UserDetails.getInstance();
    }

    public populateUser(): Observable<boolean> {
        return Observable.create((observer: Observer<boolean>) => {
            this.http.get(Url.UserDetailsUrl)
                .subscribe((userDetails: any) => {
                    this.setUserDetails(userDetails);
                    observer.next(true);
                }, (err: any) => {
                    observer.next(false);
                }, () => observer.complete());
        }
        );
    }
    public isAdminUser(): boolean {
        this.userDetails = UserDetails.getInstance();
        return this.userDetails.IsAdminUser;
    }
    public isReadOnlyUser(): boolean {
        this.userDetails = UserDetails.getInstance();
        return this.userDetails.IsReadOnlyUser;
    }

    public isValidUser(): boolean {
        this.userDetails = UserDetails.getInstance();
        return this.userDetails.IsValidUser;
    }
    private setUserDetails(userDetails: any) {
        this.userDetails = UserDetails.getInstance();
        this.userDetails.setUserID(userDetails.userID ? userDetails.userID : '');
        this.userDetails.setFullName(userDetails.fullName ? userDetails.fullName : '');
        this.userDetails
            .setIsValidUser(typeof userDetails.isValidUser !== 'undefined'
                && userDetails.isValidUser !== null
                && userDetails.isValidUser === true ? true : false);
        this.userDetails
            .setIsAdminUser(typeof userDetails.isAdminUser !== 'undefined' && userDetails.isAdminUser ? true : false);
        this.userDetails
            .setIsReadOnlyUser(typeof userDetails.isReadOnlyUser !== 'undefined' && userDetails.isReadOnlyUser ? true : false);
        this.userDetails
            .setUserToken(userDetails.UserToken && userDetails.UserToken.length > 0 ? userDetails.UserToken : '');
    }
}
