import { Component, OnInit } from '@angular/core';

@Component({
	templateUrl: 'Home.component.html',
	styleUrls: ['./Home.component.scss']
})

export class HomeComponent implements OnInit {

	ngOnInit() { }
}