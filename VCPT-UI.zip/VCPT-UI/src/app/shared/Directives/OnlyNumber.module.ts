import { OnlyNumberDirective } from './OnlyNumber.directive';


import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';


@NgModule({
    declarations: [OnlyNumberDirective],
    exports: [
        OnlyNumberDirective
    ]
})
export class OnlyNumberModule {

}
