import { PackagingMaterial } from './PackagingMaterial.model';
export class ProductConfigurationPackagingMaterialMapping {
    productConfigurationPackagingMaterialMappingId: number;
    packagingMaterialId: number;
    facilityId: number;
    quantity: any;
    scrapPercentage: number;
    productConfigurationId: number;
    createdBy: string;
}
