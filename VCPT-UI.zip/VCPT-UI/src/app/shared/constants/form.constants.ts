// Add all Form Level Labels that will be constant across all the screens here.
export const FormLabelValues = {

    // Product Detail Labels
    productCode: 'Product Code',
    productLegacyID: 'Product Legacy ID',
    productDescription: 'Product Description',
    productCharacteristic: 'Product Characteristic(s)',
    productComments: 'Product Comments',
    vcptProductStatus: 'VCPT Product Status',
    productBusinessLifecycleStatus: 'Product Business Lifecycle Status',
    sapRelevancyStatus: 'SAP Relevancy Status',
    // Facility Detail Labels
    facilityTerm: 'Facility',
    facilityPlural: 'Facilities',
    facility: 'Facility',
    // Characteristic Details Labels
    characteristicID: 'Characteristic ID',
    characteristicName: 'Name',
    dataType: 'Datatype',
    productCharacteristicsList: 'Product Characteristics List.',
    uOMList : 'UOM List',
    range: 'Range',
    // UOM Detail Labels
    uomPlural: 'UOM(s)',
    uomSingular: 'UOM',
    uomCode: 'UOM Code',
uomCodePlural: 'UOM Code(s)',
configComment: 'Configuration Comments',
maxValue: 'Max Value',
minValue: 'Min Value',
value: 'Value',
characteristic: 'Characteristic',
activeConfigurationslist: 'Active Configurations list.',
    // Configuration Details Label

    // Packaging Material Details Label

    packagingMaterialLegacyId: 'Packaging Material Legacy ID',
    sapText: 'SAP Basic Data Text',
    materialDesc: 'Packaging Material Description',
    quantityUOm: 'Quantity UOM',
    status: 'Packaging Material Lifecycle Status',
    selectFacilityStatement: 'Select the facility where these packaging supplies will be used',
    vcptPackagingStatus: 'VCPT Packaging Material Status',
    packagingMaterialId: 'PackagingMaterialID',
    quantity: 'Quantity',
    scrapPercenatge: 'Scrap%',
    countMessage: 'Below is a count of packaging material association at product and configuration level.',
    numberofProducts: 'Number of Products',
    numberofConfigurations: 'Number of Configurations',
    noteMessage: 'Use Export to Excel to get details of Products & Configurations using this packaging item.'

};

export const ScreenTitles = {
    // Admin
    maintainProductCharacteristics: 'Maintain Product Characteristics',
    maintainUOM: 'Maintain UOM',
    // Product
    viewProductMasterList: 'View Product Master List',
    viewProductConfigurations: 'View Product Configurations',
    maintainProductConfiguration: 'Maintain Product Configuration',
    maintainProduct: 'Maintain Product',
    // Packaging
    addObsoletePackagingMaterial: 'Add Obsolete Packaging Material',
    importPackagingMaterial: 'Import Packaging Material',
    maintainPackagingMaterialsForProduct: 'Maintain Packaging Materials For Product',
    viewPackagingMaterialsList: 'View Packaging Materials List',
    viewPackagingMaterialsForProductConfiguration: 'View Packaging Materials For Product Configuration',
    viewPackagingMaterialsforProduct: 'View Packaging Materials for Product',
    maintainPackagingMaterialForProductConfiguration: 'Maintain Packaging Materials for Product Configuration',
    viewPackagingMaterialForProductConfiguration: 'View Packaging Materials for Product Configuration',
    // Reports
    showAllProductswithNoPackagingAssociation: 'Show All Products with No Packaging Association',
    extractAllData: 'Extract All Data',
    showPackagingMaterialsWhereUsed: 'Show Packaging Materials Where Used'
};
