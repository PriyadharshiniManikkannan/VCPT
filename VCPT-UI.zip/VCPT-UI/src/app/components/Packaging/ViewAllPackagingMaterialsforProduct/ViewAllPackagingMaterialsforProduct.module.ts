import { DialogDisplayModule } from './../../../shared/components/dialog-display/dialog-display.module';
import { LoadingModule } from 'ngx-loading';
import { APP_CONSTANTS } from './../../../shared/constants/app.constants';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { ViewAllPackagingMaterialsforProductsRouteModule } from './ViewAllPackagingMaterialsforProduct.routing';
import { ViewAllPackagingMaterialsforProductService } from './../../../services/packaging/ViewAllPackagingMaterialsforProduct.service';
import { ViewAllPackagingMaterialsforProductComponent } from './ViewAllPackagingMaterialsforProduct.component';
import {
    ListboxModule,
    DataTableModule,
    SharedModule,
    InputMaskModule,
    AccordionModule,
    DialogModule, ButtonModule, PaginatorModule
} from 'primeng/primeng';

@NgModule({
    imports: [
        FormsModule,
        CommonModule,
        ListboxModule,
        DataTableModule,
        SharedModule,
        DialogModule,
        InputMaskModule,
        ButtonModule,
        AccordionModule,
        ViewAllPackagingMaterialsforProductsRouteModule,
        DialogDisplayModule,
        LoadingModule.forRoot(APP_CONSTANTS.loaderConfig),
        PaginatorModule
    ],
    declarations: [ViewAllPackagingMaterialsforProductComponent],
    providers: [ViewAllPackagingMaterialsforProductService]
})
export class ViewAllPackagingMaterialsforProductModule {

}
