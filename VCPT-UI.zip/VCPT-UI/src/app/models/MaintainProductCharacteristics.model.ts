export class MaintainProductCharacteristics {
    characteristicName: string;
    dataType: string;
    applicableUOMs: string[];
    applicableUOMNames: string[];
    createdBy: string;
    range: boolean;
    rangeInGrid: string;
}

export class UOM {
    uomId: any;
    uomName: string;
}



