import { APP_CONSTANTS, StatusCode, MessageItems, ConstantValues, Url } from './../../../shared/constants/app.constants';
import { Component, OnInit } from '@angular/core';
import { MaintainUOMService } from './../../../services/admin/MaintainUOM.service';
import { MaintainUOM } from './../../../models/MaintainUOM.model';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, FormBuilder, Validators, NgForm } from '@angular/forms';
import { HostListener } from '@angular/core';
import { MessageModel } from './../../../models/MessageModel.model';
import { ScreenTitles, FormLabelValues } from '../../../shared/constants/form.constants';

import { Message, ConfirmationService } from 'primeng/primeng';
@Component(
    {
        templateUrl: './MaintainUOM.component.html',
        styleUrls: ['./MaintainUOM.component.scss'],
        providers: [ConfirmationService]
    }
)
export class MaintainUOMComponent implements OnInit {
    myForm: FormGroup;
    Submit: Boolean;
    Name: string;
    Code: string;
    displayDialog: boolean;
    DataText: string;
    data: any;
    err: any;
    statusCode: string;
    MaintainUOM: MaintainUOM[];
    message: boolean;
    nameValidation: boolean;
    codeValidation: boolean;
    recordsPerPage: number;
    firstRecordIndexofGrid: number;
    messageHeader: string;
    messageIconType: string;
    displayMessage: boolean;
    returnMessage: MessageModel;
    formTitle: any;
    ConstantValues: any;
    formLabelValues: any;
    messageItems: any;
    public loading = false;
    constructor(private UOMService: MaintainUOMService,
        private confirmationService: ConfirmationService
        , private _router: Router
        , private _fb: FormBuilder
        , private _route: ActivatedRoute

    ) { }
    @HostListener('window:beforeunload', ['$event'])
    unloadNotification($event: any) {
        if (this.myForm.dirty) {
            if (!this.Submit) { $event.returnValue = APP_CONSTANTS.UnsavedChangesMessage; }
        }
    }
    ngOnInit() {
        this.loading = true;
        this.MaintainUOM = [];
        this.formTitle = ScreenTitles;
        this.ConstantValues = ConstantValues;
        this.formLabelValues = FormLabelValues;
        this.messageItems = MessageItems;
        this.returnMessage = new MessageModel();
        this.Name = '';
        this.Code = '';
        this.recordsPerPage = APP_CONSTANTS.recordsPerPageConstant;
        this.firstRecordIndexofGrid = 1;
        this.myForm = this._fb.group({
            name: [''],
            code: ['']
        });
        this.getUOM();
    }

    getUOM() {
        this.err = '';
        this.loading = true;
        this.UOMService.getUOM().
            subscribe((MaintainUOM: MaintainUOM[]) => {
                this.MaintainUOM = MaintainUOM;
            }, (err: any) => {
                this.err = err;
                if (err !== undefined) {
                    this._router.navigate([Url.error]);
                }
            }, () => this.loading = false);
    }
    showDialogToAdd() {
        this.displayDialog = true;
        this.nameValidation = false;
        this.codeValidation = false;
        this.Submit = false;
        this.Name = '';
        this.Code = '';
    }
    save(): void {
        this.Submit = false;
        this.data = '';
        this.validateUserInput();
        if (!this.nameValidation && !this.codeValidation) {
            const addUOM = new MaintainUOM();
            addUOM.uomName = this.Name;
            addUOM.uomCode = this.Code;
            this.message = false;
            this.UOMService.addUOM(addUOM).subscribe(data => {
                this.data = data;
                if (this.data === StatusCode.successCode) {
                    this.displayDialog = false;
                    this.messageHeader = MessageItems.saveHeader;
                    this.returnMessage.message = MessageItems.saveMessage;
                    this.messageIconType = APP_CONSTANTS.InformationIcon;
                    this.displayMessage = true;
                    this.statusCode = StatusCode.successCode;
                    this.Submit = true;
                    this.getUOM();
                    this.myForm.reset();

                }
                if (this.data === StatusCode.duplicateCode) {
                    this.displayDialog = true;
                    this.messageHeader = MessageItems.erroHeader;
                    this.returnMessage.message = MessageItems.duplicateUOMMessage;
                    this.messageIconType = APP_CONSTANTS.ErrorIcon;
                    this.displayMessage = true;
                    this.Submit = true;
                    this.getUOM();
                    return;

                }
            },
                (err) => {
                    if (err !== undefined) {
                        this._router.navigate([Url.error]);
                        this.myForm.reset();
                        return;
                    }
                }
            );

        } else {
            this.displayDialog = true;
        }
    }
    cancel() {
        if (!this.myForm.dirty) {
            this.displayDialog = false;
        } else {
            this.confirmationService.confirm({
                message: APP_CONSTANTS.UnsavedChangesMessage,
                icon: APP_CONSTANTS.WarningIcon,
                header: 'Confirmation',
                accept: () => {
                    this.displayDialog = false; this.Submit = true; this.myForm.reset();
                },
                reject: () => {
                    this.displayDialog = true;
                }
            });
        }
    }

    validateUserInput() {
        this.nameValidation = (this.Name === '');
        this.codeValidation = (this.Code === '');
    }
    onGridPageChange(event: any) {
        this.firstRecordIndexofGrid = event.first === 1 ? event.first : event.first + 1;
        this.recordsPerPage = event.first !== 1 ? event.rows + event.first : event.rows;
    }

}
