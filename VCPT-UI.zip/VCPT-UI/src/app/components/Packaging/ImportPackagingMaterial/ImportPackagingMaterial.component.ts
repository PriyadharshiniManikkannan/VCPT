import { GGSMStatusModel } from './../../../models/GGSMStatus.model';
import { Component, OnInit, HostListener } from '@angular/core';
import { PackagingMaterial } from './../../../models/PackagingMaterial.model';
import { ImportPackagingMaterialService } from './../../../services/packaging/ImportPackagingMaterial.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { UnsavedChangesComponent } from './../../../shared/components/UnsavedChanges/UnsavedChanges.component';
import { MessageModel } from './../../../models/MessageModel.model';
import { CanComponentDeactivate } from './../../../services/guards/CanComponentDeactivate.guard.service';
import { APP_CONSTANTS, ConstantValues, MessageItems, RouteURLs, Url } from './../../../shared/constants/app.constants';
import { FormLabelValues, ScreenTitles } from './../../../shared/constants/form.constants';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';

import { ConfirmationService, Message } from 'primeng/primeng';
@Component({
  templateUrl: 'ImportPackagingMaterial.component.html',
  styleUrls: ['./ImportPackagingMaterial.component.scss']
})
export class ImportPackagingMaterialComponent implements OnInit {
  MaterialDesc: string;
  SAPText: string;
  QuantityUOM: string;
  MaterialLifeCycleStatus: string;
  legacyID: string;
  returnMessage: MessageModel;
  messageHeader: string;
  displayMessage = false;
  messageIconType: string;
  importPackagingForm: FormGroup;
  unsavedChangesComponent: UnsavedChangesComponent;
  submit: boolean;
  formLabels: any;
  formTitle: any;
  // Loading variable for ngx-loading component
  public loading = false;

  constructor(
    private activatedRoute: ActivatedRoute,
    private importPackagingService: ImportPackagingMaterialService,
    private confirmationService: ConfirmationService,
    private formBuilder: FormBuilder,
    private router: Router) {
  }
  ngOnInit() {
    this.loading = true;
    this.formLabels = FormLabelValues;
    this.returnMessage = new MessageModel();
    this.initializeForm();
    this.initializeMessage();
    this.buildForm();
    this.loading = false;
  }
  initializeForm() {
    this.formTitle = ScreenTitles;
    this.MaterialDesc = '';
    this.SAPText = '';
    this.QuantityUOM = '';
    this.MaterialLifeCycleStatus = '';
    this.unsavedChangesComponent = new UnsavedChangesComponent(this.confirmationService);
    if (this.importPackagingForm && this.importPackagingForm !== null) {
      this.importPackagingForm.markAsPristine();
      this.importPackagingForm.markAsUntouched();
    }
  }
  showResults(): void {
    this.loading = true;
    this.returnMessage = new MessageModel();
    this.legacyID = this.importPackagingForm.get('legacyID').value;
    if (this.legacyID !== '' && this.legacyID !== undefined
    ) {
      this.initializeMessage();
      const params: any = {};
      params.PackagingLegacyId = this.legacyID;
      this.importPackagingService.getPackagingDetails(params).subscribe((packagingDetails: any) => {
        if (packagingDetails && packagingDetails.message) {
          this.messageHeader = MessageItems.erroHeader;
          this.returnMessage.message = packagingDetails.message;
          this.messageIconType = APP_CONSTANTS.ErrorIcon;
          this.displayMessage = true;
          this.loading = false;
          this.initializeForm();
          return;
        } else {
          this.loading = false;
          this.MaterialDesc = packagingDetails.packagingMaterialDescription;
          this.SAPText = packagingDetails.sapBasicDataText;
          this.QuantityUOM = packagingDetails.quantityUOM;
          this.MaterialLifeCycleStatus = packagingDetails.materialBusinessLifeCycleStatus.statusDesc;
        }
      }, (err: Error) => {
        if (err !== undefined) {
          this.router.navigate([Url.error]);
          this.loading = false;
          this.initializeForm();
          return;
        }

      });
    } else {
      this.messageHeader = MessageItems.erroHeader;
      this.returnMessage.message = MessageItems.packagingIdEmptyMessage;
      this.messageIconType = APP_CONSTANTS.ErrorIcon;
      this.displayMessage = true;
      this.loading = false;
      this.initializeForm();
      return;
    }
  }
  initializeMessage() {
    this.returnMessage = new MessageModel();
    this.messageHeader = '';
    this.returnMessage.listofItemsforDisplay = [];
    this.returnMessage.message = '';
    this.returnMessage.messageCode = '';
  }
  import() {
    this.legacyID = this.importPackagingForm.get('legacyID').value;
    if (this.legacyID !== '' && this.legacyID !== undefined
    ) {
      const packagingDetails = new PackagingMaterial();
      packagingDetails.packagingMaterialLegacyID = this.legacyID;
      this.importPackagingService.importPackagingDetails(packagingDetails).subscribe((returnMessage: MessageModel) => {
        this.initializeMessage();
        this.returnMessage.message = returnMessage.message;
        this.returnMessage.messageType = returnMessage.messageType;
        this.getIConforMessageDisplay();
        this.displayMessage = true;
        this.loading = false;
        if (returnMessage.messageType !== MessageItems.erroHeader) {
          this.MaterialDesc = '';
          this.SAPText = '';
          this.QuantityUOM = '';
          this.MaterialLifeCycleStatus = '';
        this.buildForm();
        }else {
          this.MaterialDesc = '';
          this.SAPText = '';
          this.QuantityUOM = '';
          this.MaterialLifeCycleStatus = '';

        }
        return;
      }, (err: Error) => {
        if (err !== undefined) {
          this.router.navigate([Url.error]);
          this.loading = false;
          this.initializeForm();
          return;
        }

      });
    } else {
      this.messageHeader = MessageItems.erroHeader;
      this.returnMessage.message = MessageItems.packagingIdImportEmptyMessage;
      this.messageIconType = APP_CONSTANTS.ErrorIcon;
      this.displayMessage = true;
      this.loading = false;
      this.initializeForm();
      return;
    }

  }
  @HostListener('window:beforeunload', ['$event'])
  canNavigateAway(event: any) {
    if (this.checkDirtyForm()) {
      event.returnValue = APP_CONSTANTS.UnsavedChangesMessage;
    }
  }
  canDeactivate(): Observable<boolean> | boolean {
    if (this.checkDirtyForm()) {
      return this.getUserConfirmation().first();
    } else {
      return true;
    }
  }

  getUserConfirmation(): Observable<boolean> {
    return this.unsavedChangesComponent.getUnsavedChangesConfirmation();
  }
  checkDirtyForm(): boolean {
    return this.importPackagingForm ? this.importPackagingForm.dirty : false;
  }
  getIConforMessageDisplay() {
    switch (this.returnMessage.messageType.trim().toUpperCase()) {
      case 'Error'.toUpperCase(): this.messageIconType = APP_CONSTANTS.ErrorIcon;
        this.messageHeader = MessageItems.erroHeader; break;
      case 'Information'.toUpperCase(): this.messageIconType = APP_CONSTANTS.InformationIcon;
        this.messageHeader = MessageItems.saveHeader; break;
      case 'Warning'.toUpperCase(): this.messageIconType = APP_CONSTANTS.WarningIcon; break;
      default: this.messageIconType = APP_CONSTANTS.InformationIcon; break;
    }
  }
  buildForm() {
    this.importPackagingForm
      = this.formBuilder.group({
        legacyID: new FormControl(),
        MaterialDesc: new FormControl(),
        SAPText: new FormControl(),
        QuantityUOM: new FormControl(),
        MaterialLifeCycleStatus: new FormControl(),
      });
  }
  viewPackaging() {
    this.legacyID = this.importPackagingForm.get('legacyID').value;
    if (this.legacyID !== '' && this.legacyID.length === ConstantValues.productLegacyIDLength) {
      this.router.navigateByUrl(RouteURLs.ViewPackagingMaterialsPath + ';id=' + this.legacyID);
    } else {
      this.messageHeader = MessageItems.erroHeader;
      this.returnMessage.message = MessageItems.packagingIdSearchMessage;
      this.messageIconType = APP_CONSTANTS.ErrorIcon;
      this.displayMessage = true;
      this.loading = false;
      this.initializeForm();
      return;
    }
  }
}
