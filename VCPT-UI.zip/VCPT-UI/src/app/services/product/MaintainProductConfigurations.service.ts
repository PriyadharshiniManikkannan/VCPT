import { MaintainProductConfigurations } from './../../models/MaintainProductConfigurations.model';
import { ViewProductMaster } from './../../models/ViewProductMaster.model';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { Url } from '../../shared/constants/app.constants';
import { HttpService } from '../../services/base/http.service';
@Injectable()
export class MaintainProductConfigurationsService {
  constructor(private _http: Http, private _httpService: HttpService) { }
  getProductDetailsByLegacyID(prodDetails: ViewProductMaster) {
    let jsonParam: any;
    jsonParam = {
      'productLegacyId': prodDetails.productLegacyID,
      'facilityCode': prodDetails.facilityCode,
      'productStatus': prodDetails.productStatus.statusCode,
      'productBusinessLifeCycleStatus': prodDetails.productBusinessLifeCycleStatus.statusCode,
      'productDescription': prodDetails.productDescription,
      'productCode': prodDetails.productCode
    };
    return this._httpService.get(Url.ProductSearchUrl, jsonParam);
  }
  getProductConfigurationByFacility(viewProductConfig: MaintainProductConfigurations) {
    let jsonParam: any;
    jsonParam = {
      'productId': viewProductConfig.productId,
      'facilityCollection': viewProductConfig.facilityCollection,
      'getOnlyActiveConfiguration': viewProductConfig.getOnlyActiveConfiguration
    };
    return this._httpService.get(Url.ProductConfigurationsUrl, jsonParam);
  }
  getUOMList() {
    return this._httpService.get(Url.UomDetailsUrl);
  }

  getCharacteristicsByConfigID(ProductConfigId) {
    let jsonParam: any;
    jsonParam = {
      'ProductConfigId': ProductConfigId
    };
    return this._httpService.get(Url.CharacteristicsForProductConfigurationUrl, jsonParam);
  }
  getCharacteristicsByConfigIDNoLock(ProductConfigId) {
    let jsonParam: any;
    jsonParam = {
      'ProductConfigId': ProductConfigId
    };
    return this._httpService.get(Url.CharacteristicsForProductConfigurationNoLockUrl, jsonParam);
  }

  DuplicateProdConfigDetail(ProductConfigId) {
    let jsonParam: any;
    jsonParam = {
      'ProdConfigId': ProductConfigId
    };
    return this._httpService.get(Url.ReplicateProductConfigDetailUrl, jsonParam);
  }
  getFacilityByProducID(ProductId) {
    let jsonParam: any;
    jsonParam = {
      'ProductId': ProductId
    };
    return this._httpService.get(Url.FacilitiesByProductUrl, jsonParam);
  }
  getCharacteristicsByProductID(ProductId) {
    let jsonParam: any;
    jsonParam = {
      'ProductId': ProductId
    };
    return this._httpService.get(Url.CharacteristicsForProductUrl, jsonParam);
  }
  saveConfiguration(MaintainProductConfigurations: MaintainProductConfigurations) {
    return this._httpService.post(Url.ProductConfigurationUrl, MaintainProductConfigurations);
  }
  unlockProductConfiguration(prodConfigId) {
    return this._httpService.post(Url.UnlockProductConfigUrl, prodConfigId);
  }
  unlockProductConfigurationSynchronous(prodConfigId) {
    return this._httpService.synchronousPost(Url.UnlockProductConfigUrl, prodConfigId);
  }

}
