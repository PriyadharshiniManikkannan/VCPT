import { CommonUtilitiesComponent } from './../../../shared/components/common-utilities/common-utilities.component';
import { SecurityService } from './../../../services/Security.service';
import { GGSMStatusModel } from './../../../models/GGSMStatus.model';
import { VCPTStatusModel } from './../../../models/VCPTStatus.model';
import { APP_CONSTANTS, Url } from './../../../shared/constants/app.constants';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ViewAllPackagingMaterialsforProductService } from './../../../services/packaging/ViewAllPackagingMaterialsforProduct.service';
import { PackagingMaterial } from './../../../models/PackagingMaterial.model';
import { ViewProductMaster } from './../../../models/ViewProductMaster.model';
import { utils, write, WorkBook } from 'xlsx';
import { saveAs } from 'file-saver';
import { element } from 'protractor';
import { ConstantValues, RouteURLs, MessageItems } from '../../../shared/constants/app.constants';
import { MessageModel } from './../../../models/MessageModel.model';
import { FormLabelValues, ScreenTitles } from './../../../shared/constants/form.constants';

import { SelectItem, Message } from 'primeng/primeng';
import { ConfirmationService, DialogModule } from 'primeng/primeng';
@Component({
    templateUrl: './ViewAllPackagingMaterialsforProduct.component.html',
    styleUrls: ['./ViewAllPackagingMaterialsforProduct.component.scss']
})

export class ViewAllPackagingMaterialsforProductComponent implements OnInit {
    displayConfigGrid: boolean;
    viewPackagingMaterialForProduct: any[];
    cols: any[] = [];
    legacyID: string;
    productID: string;
    SAPRelevancy: string;
    ProductCode: string;
    ProductDesc: string;
    productStatusDesc: VCPTStatusModel;
    productBusinessLifeCycleStatus: GGSMStatusModel;
    Facility: string;
    data: any;
    err: any;
    message: boolean;
    readOnlyUser: boolean;
    viewProductDetails: any;
    disabled: boolean;
    facilityCollection: any[];
    packagingExcel: any[];
    displayButton: boolean;
    productComments: string;
    recordsPerPage: number;
    firstRecordIndexofGrid: number;
    messageHeader: string;
    messageIconType: string;
    displayMessage: boolean;
    productDetailSelected: boolean;
    returnMessage: MessageModel;
    formLabels: any;
    formTitle: any;
    disableMaintainPackagingMaterialsForProductButton: boolean;
    disableMaintainPackagingMaterialsForProductConfigurationButton: boolean;
    ConstantValues: any;
    // Loading variable for ngx-loading component
    public loading = false;

    constructor(private viewAllPackagingMaterialsforProductService: ViewAllPackagingMaterialsforProductService,
        private router: Router,
        private activatedRoute: ActivatedRoute,
        confirmationService: ConfirmationService,
        private securityService: SecurityService
    ) { }
    ngOnInit() {
        this.legacyID = '';
        this.formLabels = FormLabelValues;
        this.ConstantValues = ConstantValues;
        this.loading = true;
        this.disabled = true;
        this.productDetailSelected = false;
        this.disableMaintainPackagingMaterialsForProductButton = true;
        this.disableMaintainPackagingMaterialsForProductConfigurationButton = true;
        this.initializeForm();
        this.returnMessage = new MessageModel();
        this.readOnlyUser = this.securityService.isReadOnlyUser();
        this.activatedRoute.params.subscribe((params: Params) => {
            this.legacyID = params['id'];

            if (this.legacyID !== undefined && this.legacyID !== '' && this.legacyID.length === ConstantValues.productLegacyIDLength) {
                const prod = new ViewProductMaster();
                prod.productLegacyID = this.legacyID;
                this.getProductDetails(prod);
            }
        }, (error: Error) => {
            this.enableDisableButtons();
            this.router.navigate([Url.error]);
            this.loading = false;
        }
        );
        this.loading = false;
    }
    initializeForm() {
        this.loading = true;
        this.formTitle = ScreenTitles;
        this.SAPRelevancy = '';
        this.ProductCode = '';
        this.ProductDesc = '';
        this.Facility = '';
        this.productComments = '';
        this.displayConfigGrid = false;
        this.productDetailSelected = false;
        this.readOnlyUser = this.securityService.isReadOnlyUser();
        this.recordsPerPage = APP_CONSTANTS.recordsPerPageConstant;
        this.firstRecordIndexofGrid = 1;
        this.displayButton = false;
        this.viewPackagingMaterialForProduct = [];
        this.enableDisableButtons();
        this.loading = false;
    }
    showResults(): void {
        this.viewPackagingMaterialForProduct = [];
        this.loading = true;
        this.displayConfigGrid = false;
        this.displayButton = false;
        if (this.legacyID !== undefined && this.legacyID !== '' && this.legacyID.length === ConstantValues.productLegacyIDLength) {
            const prod = new ViewProductMaster();
            prod.productLegacyID = this.legacyID;
            prod.facilityCode = '';
            prod.productStatus.statusCode = 0;
            prod.productBusinessLifeCycleStatus.statusCode = '';
            prod.productDescription = '';
            prod.productCode = '';
            this.getProductDetails(prod);
        } else {
            this.loading = true;
            this.SAPRelevancy = '';
            this.ProductCode = '';
            this.ProductDesc = '';
            this.Facility = '';
            this.productComments = '';
            this.messageHeader = MessageItems.productHeader;
            this.returnMessage.message = MessageItems.draftMessage;
            this.messageIconType = APP_CONSTANTS.ErrorIcon;
            this.displayMessage = true;
            this.loading = false;
            return;
        }
        this.enableDisableButtons();
    }
    getPackagingDetails() {
        this.loading = true;
        this.viewPackagingMaterialForProduct = [];
        this.viewAllPackagingMaterialsforProductService.getPackagingDetailsByProductId(this.productID).
            subscribe((viewPackagingMaterialForProduct: any) => {
                this.viewPackagingMaterialForProduct = viewPackagingMaterialForProduct;
                if (this.viewPackagingMaterialForProduct.length !== 0) {
                    this.getColumnforGrid(this.viewPackagingMaterialForProduct);
                    this.displayConfigGrid = true;
                    this.disabled = false;
                    this.disableMaintainPackagingMaterialsForProductButton = false;
                    this.disableMaintainPackagingMaterialsForProductConfigurationButton = false;
                } else {
                    this.displayConfigGrid = false;

                    this.disabled = true;
                    this.disableMaintainPackagingMaterialsForProductButton = true;
                    this.disableMaintainPackagingMaterialsForProductConfigurationButton = true;
                }
            }, (err: any) => {
                this.err = err;
                if (err !== undefined) {
                    this.initializeMessage();
                    this.router.navigate([Url.error]);
                }
            }, () => {
                this.enableDisableButtons();
                this.loading = false;
            });
    }
    initializeMessage() {
        this.returnMessage = new MessageModel();
        this.messageHeader = '';
        this.returnMessage.listofItemsforDisplay = [];
        this.returnMessage.message = '';
        this.returnMessage.messageCode = '';
    }
    getColumnforGrid(obj: any): void {
        if (obj && obj.length) {
            const keys = Object.keys(obj[0]);
            const cols = [];
            keys.forEach(function (k: any) {
                let s = '';
                s = k.split('_').join(' ');
                if (k.toString().toLowerCase() === FormLabelValues.sapText.toString().toLowerCase()) {
                    s = FormLabelValues.sapText;
                }
                if (k.toString().toLowerCase() === FormLabelValues.vcptPackagingStatus.toString().toLowerCase()) {
                    s = FormLabelValues.vcptPackagingStatus;
                }
                if (k.toString().toLowerCase() !== FormLabelValues.packagingMaterialId.toString().toLowerCase()) {
                    cols.push({ field: k, header: s });
                }

            });
            this.cols = cols;
        }
    }
    getProductDetails(prod) {
        this.loading = true;
        this.SAPRelevancy = '';
        this.ProductCode = '';
        this.ProductDesc = '';
        this.productID = '';
        this.Facility = '';
        this.data = '';
        this.productComments = '';
        this.viewProductDetails = [];
        this.viewAllPackagingMaterialsforProductService.getProductDetailsByLegacyID(prod).
            subscribe((ViewProductDetails: any) => {
                this.viewProductDetails = ViewProductDetails;
                if (this.viewProductDetails && !this.viewProductDetails.message) {
                    const prodStatus = this.viewProductDetails.vcptProductStatus.statusDesc;
                    const busStatus = this.viewProductDetails.productBusinessLifeCycleStatus.statusDesc;
                    this.productStatusDesc = prodStatus;
                    this.productBusinessLifeCycleStatus = busStatus;
                    if (this.productStatusDesc.toString().toLowerCase().trim() ===
                        ConstantValues.productStatusActive.toString().toLowerCase().trim()
                        && this.productBusinessLifeCycleStatus.toString().toLowerCase().trim() !==
                        ConstantValues.productStatusInActive.toString().toLowerCase().trim()
                        && this.productBusinessLifeCycleStatus.toString().toLowerCase() !== ConstantValues.statusObsolete.toLowerCase()
                    ) {
                        this.SAPRelevancy = this.viewProductDetails.sapRelevancyStatus;
                        this.ProductCode = this.viewProductDetails.productCode;
                        this.ProductDesc = this.viewProductDetails.productDescription;
                        this.productID = this.viewProductDetails.productId;
                        this.productComments = this.viewProductDetails.productComments;
                        const facilityItems = [];
                        if (this.viewProductDetails.applicableFacilities !== undefined) {
                            this.viewProductDetails.applicableFacilities.forEach(e => {

                                facilityItems.push({
                                    label: e.facilityName
                                    ,
                                    value: e.facilityName
                                });
                            });
                            facilityItems.sort(function (a, b) {
                                return a.label.localeCompare(b.label);
                            });
                            this.Facility = '';
                            facilityItems.forEach(e => {
                                this.Facility += e.label + ', ';
                            });
                            if (this.Facility !== '') {
                                this.Facility = this.Facility.substring(0, this.Facility.length - 2);
                            }
                        }
                        this.productDetailSelected = true;
                        this.getPackagingDetails();
                    } else if (this.productStatusDesc.toString().toLowerCase().trim() ===
                        ConstantValues.productStatusDraft.toString().toLowerCase().trim()) {
                        this.messageHeader = 'Get Details';
                        this.returnMessage.message = MessageItems.draftMessage;
                        this.messageIconType = APP_CONSTANTS.ErrorIcon;
                        this.initializeForm();
                        this.displayMessage = true;
                    } else if (this.productStatusDesc.toString().toLowerCase().trim() ===
                        ConstantValues.productStatusInActive.toString().toLowerCase().trim()) {
                        this.messageHeader = 'Get Details';
                        this.returnMessage.message = MessageItems.inactiveMessage;
                        this.messageIconType = APP_CONSTANTS.ErrorIcon;
                        this.initializeForm();
                        this.displayMessage = true;
                    } else {
                        this.messageHeader = 'Get Details';
                        this.returnMessage.message = MessageItems.inactiveMessage;
                        this.messageIconType = APP_CONSTANTS.ErrorIcon;
                        this.initializeForm();
                        this.displayMessage = true;
                    }

                } else {
                    this.initializeForm();
                    this.messageHeader = 'Get Details';
                    this.returnMessage.message = this.viewProductDetails.message;
                    this.messageIconType = APP_CONSTANTS.ErrorIcon;
                    this.displayMessage = true;
                }
            }, (error: Error) => {
                this.enableDisableButtons();
                this.router.navigate([Url.error]);
                this.loading = false;
            }
            );

    }

    s2ab(s) {
        const buf = new ArrayBuffer(s.length);
        const view = new Uint8Array(buf);
        for (let i = 0; i !== s.length; ++i) {
            view[i] = s.charCodeAt(i) & 0xFF;
        }
        return buf;
    }

    exportExcel() {
        let timestamp = '';
        timestamp = CommonUtilitiesComponent.getCurrentDateTimeStamp();
        const sheetName = 'ViewPackagingMaterials' + '_' + timestamp + '.xlsx';
        this.packagingExcel = [];
        const ws_name = 'PackagingDetails';
        const wb: WorkBook = { SheetNames: [], Sheets: {} };
        this.viewAllPackagingMaterialsforProductService.getPackagingDetailsByProductIdForExcel(this.productID).
            subscribe((ViewProductDetails: any) => {
                if (ViewProductDetails.length !== 0) {
                    ViewProductDetails.forEach(element => {
                        this.packagingExcel.push({
                            'Product Legacy ID': element.productLegacyID,
                            'Product Description': element.productDescription,
                            'Product Code': element.productCode,
                            'SAP Relevancy Status': element.sapRelevancyStatus,
                            'Product Comments': element.productComments,
                            'Facility': element.facilityName,
                            'Packaging Material Legacy ID': element.packagingMaterialLegacyID,
                            'Material Description': element.packagingMaterialDescription,
                            'SAP Basic Data Text': element.sapBasicDataText,
                            'Quantity': element.quantity,
                            'Quantity UOM': element.quantityUOM,
                            'Scrap%': element.scrap
                        });
                    });
                }
                const ws: any = utils.json_to_sheet(this.packagingExcel);
                wb.SheetNames.push(ws_name);
                wb.Sheets[ws_name] = ws;
                const wbout = write(wb, { bookType: 'xlsx', bookSST: true, type: 'binary' });
                saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), sheetName);
            },
            (err) => {
                if (err !== undefined) {
                    this.router.navigate([Url.error]);
                    return;
                }
            });
    }
    onGridPageChange(event: any) {
        this.firstRecordIndexofGrid = event.first === 1 ? event.first : event.first + 1;
        this.recordsPerPage = event.first !== 1 ? event.rows + event.first : event.rows;
    }
    viewPackagingConfiguration() {
        if (this.legacyID !== '' && this.legacyID !== undefined && this.legacyID.length === ConstantValues.productLegacyIDLength) {
            this.router.navigateByUrl(RouteURLs.ViewPackagingMaterialsConfigurationPath + ';id=' + this.legacyID);
        }
    }
    maintainPackagingConfiguration() {
        if (this.legacyID !== '' &&   this.legacyID !== undefined && this.legacyID.length === ConstantValues.productLegacyIDLength) {
            this.router.navigateByUrl(RouteURLs.MaintainPackagingMaterialsConfigurationPath + ';id=' + this.legacyID);
        }
    }
    maintainPackagingMaterials() {
        if (this.legacyID !== '' && this.legacyID !== undefined && this.legacyID.length === ConstantValues.productLegacyIDLength) {
            this.router.navigateByUrl(RouteURLs.MaintainPackagingMaterialsPath + ';id=' + this.legacyID);
        }
    }
    enableDisableButtons() {
        this.disabled = true;
        this.disableMaintainPackagingMaterialsForProductButton = true;
        this.disableMaintainPackagingMaterialsForProductConfigurationButton = true;
        if (this.readOnlyUser) {
            this.disableMaintainPackagingMaterialsForProductButton = true;
            this.disableMaintainPackagingMaterialsForProductConfigurationButton = true;
        } else {
            this.disableMaintainPackagingMaterialsForProductButton = false;
            this.disableMaintainPackagingMaterialsForProductConfigurationButton = false;
        }

        if (this.viewPackagingMaterialForProduct && this.viewPackagingMaterialForProduct.length > 0) {
            this.disabled = false;
        }
    }

}
