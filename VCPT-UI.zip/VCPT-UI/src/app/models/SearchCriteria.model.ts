export class ProductSearchModel {
    productLegacyId: string;
    productDescription: string;
    facilityCode: string;
    productCode: string;
    productBusinessLifeCycleStatus: string;
    vcptProductStatus: number;
    constructor() {
        this.productLegacyId = '';
        this.productDescription = '';
        this.productCode = '';
        this.facilityCode = '';
        this.productBusinessLifeCycleStatus = '';
        this.vcptProductStatus = 0;
    }
}
