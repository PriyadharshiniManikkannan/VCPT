import { PackagingMaterial } from './../../models/PackagingMaterial.model';
import { Url } from './../../shared/constants/app.constants';
import { HttpService } from './../base/http.service';
import { Observable } from 'rxjs/Observable';
import {  Http, Response, RequestOptions, Headers  } from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';


@Injectable()
export class ViewAllPackagingMaterialService {
    constructor(private _httpService: HttpService) { }
    getAllPackagingDetails(jsonParam: any) {
        return this._httpService.get(Url.PackagingMaterialDetailsUrl, jsonParam);
    }
    getStatus() {
        return this._httpService.get(Url.GGSMStatusesUrl);
    }
    getProductStatus() {
        return this._httpService.get(Url.VCPTStatusesUrl);
    }
    markasInactive(packagingMaterialID) {
        return this._httpService.post(Url.InactivatePackagingMaterialUrl, packagingMaterialID);
    }
    markasActive(packagingMaterialID) {
        return this._httpService.post(Url.ActivatePackagingMaterialUrl, packagingMaterialID);
    }
}
