import { PackagingMaterial } from './../../models/PackagingMaterial.model';
import { ViewProductMaster } from './../../models/ViewProductMaster.model';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { Url } from '../../shared/constants/app.constants';
import { HttpService } from '../../services/base/http.service';

@Injectable()
export class MaintainPackagingMaterialsForProductService {
  constructor(private _http: Http, private _httpService: HttpService) { }
  getProductDetailsByLegacyID(prodDetails: ViewProductMaster) {
    let jsonParam: any;
    jsonParam = {
      'LegacyId': prodDetails.productLegacyID
      //  'LockedBy': prodDetails.lockedBy
    };
    return this._httpService.get(Url.ActiveProductUrl, jsonParam);
  }
  getPackagingDetailsByProductId(productId) {
    let jsonParam: any;
    jsonParam = {
      'productId': productId
    };
    return this._httpService.get(Url.AssociatedPackagingMaterialUrl, jsonParam);
  }
  getPackagingDetailsByProductIdForExcel(productId) {
    let jsonParam: any;
    jsonParam = {
      'productId': productId,
      'isExport': true
    };
    return this._httpService.get(Url.AssociatedPackagingMaterialUrl, jsonParam);
  }
  deletePackageAssociation(pkgConfigMapId) {
    return this._httpService.post(Url.DisassociatePackagingMaterialForProductUrl, pkgConfigMapId);
  }
  savePackageAssociation(packagingMaterial: PackagingMaterial) {
    return this._httpService.post(Url.PackagingMaterialForProductUrl, packagingMaterial);
  }
  getPackagingDetailsByLegacyId(packagingLegacyId) {
    let jsonParam: any;
    jsonParam = {
      'pckgmatlLgcyId': packagingLegacyId
    };
    return this._httpService.get(Url.AssociatedPackagingMaterialUrl, jsonParam);
  }
  unlockProductforEdit(productId: number) {
    return this._httpService.post(Url.UnlockProductUrl, productId);
  }
  unlockProductforEditSynchronous(productId: number) {
    return this._httpService.synchronousPost(Url.UnlockProductUrl, productId);
  }

}
