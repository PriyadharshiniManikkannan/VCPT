import { MaintainProductCharacteristics } from './../../models/MaintainProductCharacteristics.model';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { HttpService  } from '../../services/base/http.service';
import { environment } from './../../../environments/environment';
import {Url } from '../../shared/constants/app.constants';
@Injectable()
export class MaintainProductCharacteristicsService {
    constructor(private _http: Http, private _httpService: HttpService) { }
    getProductCharacteristics() {
         return this._httpService.get(Url.CharacteristicDetailsUrl);

    }
    getUOMList() {
          return this._httpService.get(Url.UomDetailsUrl);
    }

    addProductCharacteristics(MaintainProductCharacteristics: MaintainProductCharacteristics) {
        return  this._httpService.post(Url.CharacteristicDetailsUrl , MaintainProductCharacteristics);
    }
}



