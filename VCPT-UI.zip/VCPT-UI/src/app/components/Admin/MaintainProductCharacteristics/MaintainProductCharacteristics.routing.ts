import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { MaintainProductCharacteristicsComponent } from './MaintainProductCharacteristics.component';

const maintainproductcharacteristicsroutes: Routes = [
    {
        path: '',
        component: MaintainProductCharacteristicsComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(maintainproductcharacteristicsroutes)],
    exports: [RouterModule]
})
export class MaintainProductCharacteristicsRouteModule {

}
