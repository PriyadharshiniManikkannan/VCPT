import { DialogDisplayModule } from './../../../shared/components/dialog-display/dialog-display.module';
import { APP_CONSTANTS } from './../../../shared/constants/app.constants';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MaintainProductRoutingModule } from './MaintainProduct.routing';
import { MaintainProductComponent } from './MaintainProduct.component';
import { DialogModule, InputMaskModule, ListboxModule, ButtonModule, ConfirmationService, ConfirmDialogModule } from 'primeng/primeng';
import { MaintainProductService } from './../../../services/product/MaintainProduct.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
    imports: [
        CommonModule,
        MaintainProductRoutingModule,
        DialogModule,
        InputMaskModule,
        ConfirmDialogModule,
        ListboxModule,
        ButtonModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        DialogDisplayModule,
        LoadingModule.forRoot(APP_CONSTANTS.loaderConfig)
    ],
    declarations: [MaintainProductComponent],
    providers: [MaintainProductService, ConfirmationService],
    exports: [MaintainProductRoutingModule]
})
export class MaintainProductModule {

}
