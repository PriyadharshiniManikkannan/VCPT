import { PackagingMaterial } from './../../models/PackagingMaterial.model';
import { Url } from './../../shared/constants/app.constants';
import { HttpService } from './../base/http.service';
import { Observable } from 'rxjs/Observable';
import {  Http, Response, RequestOptions, Headers  } from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';


@Injectable()
export class AddObsoletePackagingMaterialService {
    constructor(private httpService: HttpService) { }
     addObsoleteDetails (packagingMaterial: PackagingMaterial) {
        return this.httpService.post(Url.ImportObsoletePackagingMaterial, packagingMaterial);
    }
}
