import { ViewProductMaster } from './../../models/ViewProductMaster.model';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { Url } from '../../shared/constants/app.constants';
import { HttpService } from '../../services/base/http.service';

@Injectable()
export class ViewAllPackagingMaterialsforProductService {
  constructor(private _http: Http, private _httpService: HttpService) { }
  getProductDetailsByLegacyID(prodDetails: ViewProductMaster) {
    let jsonParam: any;
    jsonParam = {
      'LegacyId': prodDetails.productLegacyID
    };
    return this._httpService.get(Url.ActiveProductWithNoLockUrl, jsonParam);
  }
getPackagingDetailsByProductId(productId) {
    let jsonParam: any;
    jsonParam = {
      'ProductId': productId
    };
    return this._httpService.get(Url.AssociatedPackagingMaterialUrl, jsonParam);
  }
  getPackagingDetailsByProductIdForExcel(productId) {
    let jsonParam: any;
    jsonParam = {
      'ProductId': productId
    };
    return this._httpService.get(Url.AssociatedPackagingMaterialExportUrl, jsonParam);
  }
}
