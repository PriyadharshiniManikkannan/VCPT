import { ProductDetails, CharacteristicsListBoxModel } from './../../models/MaintainProduct.model';
import { Url } from './../../shared/constants/app.constants';
import { HttpService } from './../base/http.service';
import { Observable } from 'rxjs/Observable';
import { Http, Response } from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/map';
@Injectable()
export class MaintainProductService {
    constructor(private _httpService: HttpService) { }
    getActiveProduct(jsonParam: any) {
        return this._httpService.get(Url.ActiveProductWithNoLockUrl, jsonParam);
    }
    getProductDetails(jsonParam: any) {
        return this._httpService.get(Url.ProductDetailsUrl, jsonParam);
    }
    getCharacteristicsDetails() {
        return this._httpService.get(Url.CharacteristicDetailsUrl);
    }
    saveProduct(jsonParam: ProductDetails) {
        return this._httpService.post(Url.ProductDetailsUrl, jsonParam);
    }
    unlockProductforEdit(productId: number) {
        return this._httpService.post(Url.UnlockProductUrl, productId);
    }
    unlockProductforEditSynchronous(productId: number) {
        return this._httpService.synchronousPost(Url.UnlockProductUrl, productId);
    }
    checkActiveConfigurationExistsforProduct(productId: number) {
        return this._httpService.get(Url.CheckActiveConfigurationExistsforProductUrl, productId);
    }
}
