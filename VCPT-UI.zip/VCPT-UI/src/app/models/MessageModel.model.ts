export class MessageModel {
    messageHeader: string;
    messageCode: string;
    messageType: string;
    messageIconClass: string;
    message: string;
    listofItemsforDisplay: string[];
    constructor() {
        this.messageCode = '';
        this.messageType = 'Information';
        this.message = '';
        this.listofItemsforDisplay = [];
        this.messageIconClass = '';
        this.messageHeader = '';
    }
}
