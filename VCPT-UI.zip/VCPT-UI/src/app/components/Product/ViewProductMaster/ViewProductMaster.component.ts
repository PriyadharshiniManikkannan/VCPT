import { CommonUtilitiesComponent } from './../../../shared/components/common-utilities/common-utilities.component';
import { SecurityService } from './../../../services/Security.service';
import {
    RouteURLs, APP_CONSTANTS,
    ConstantValues, StatusCode, MessageItems, Url
} from './../../../shared/constants/app.constants';
import { Observable } from 'rxjs/Observable';
import { ProductSearchModel } from './../../../models/SearchCriteria.model';
import { element } from 'protractor';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { utils, write, WorkBook } from 'xlsx';
import { saveAs } from 'file-saver';
import { MessageModel } from './../../../models/MessageModel.model';
import { ViewProductMasterService } from './../../../services/product/ViewProductMaster.service';
import { ViewProductMaster, Facility, Status, ProductStatus } from './../../../models/ViewProductMaster.model';
import { FormLabelValues, ScreenTitles } from './../../../shared/constants/form.constants';

import { SelectItem, Message, DialogModule, ButtonModule } from 'primeng/primeng';
import { ConfirmationService } from 'primeng/primeng';

@Component(
    {
        templateUrl: './ViewProductMaster.Component.html',
        styleUrls: ['./ViewProductMaster.Component.scss']
    }
)
export /**
 * ViewProductMasterComponents
 */
    class ViewProductMasterComponent implements OnInit {
    productDescription: string;
    productCode: string;
    selectedFacility: string;
    selectedProductStatus: any;
    selectedProductLifeCycleStatus: string;
    displayGrid: boolean;
    cols: any[];
    err: any;
    productDetails: any[];
    legacyID: string;
    facility: Facility[];
    prodBusLifeCycleStatus: Status[];
    prodStatus: ProductStatus[];
    viewProductMaster: ViewProductMaster[];
    message: boolean;
    defaultDropDownOption: string;
    characteristcis: string;
    facilitiesStacked: string;
    facilitiesVal: any[];
    disabled: boolean;
    readOnlyUser: boolean;
    disableMaintainProductButton: boolean;
    selectedRow: ViewProductMaster;
    recordsPerPage: number;
    firstRecordIndexofGrid: number;
    messageHeader: string;
    messageIconType: string;
    displayMessage: boolean;
    returnMessage: MessageModel;
    formLabels: any;
    formTitle: any;
    ConstantValues: any;
    // Loading Variable for ngx-Loading component.
    public loading = false;

    constructor(private ViewProductMasterService: ViewProductMasterService,
        private _router: Router,
        confirmationService: ConfirmationService,
        private securityService: SecurityService
    ) { }
    ngOnInit() {
        this.formLabels = FormLabelValues;
        this.ConstantValues = ConstantValues;
        this.loading = true;
        this.displayGrid = false;
        this.legacyID = '';
        this.cols = [];
        this.formTitle = ScreenTitles;
        this.readOnlyUser = this.securityService.isReadOnlyUser();
        this.selectedFacility = ConstantValues.defaultDropDownOption;
        this.defaultDropDownOption = ConstantValues.defaultDropDownOption;
        this.selectedProductLifeCycleStatus = ConstantValues.statusActiveCode;
        this.selectedProductStatus = ConstantValues.productStatusActiveCode;
        this.returnMessage = new MessageModel();
        this.cols.push(FormLabelValues.productLegacyID,
            FormLabelValues.productDescription,
            FormLabelValues.productCode,
            FormLabelValues.facility,
            FormLabelValues.productCharacteristic,
            FormLabelValues.productComments,
            FormLabelValues.vcptProductStatus,
            FormLabelValues.productBusinessLifecycleStatus,
            FormLabelValues.sapRelevancyStatus);
        this.recordsPerPage = APP_CONSTANTS.recordsPerPageConstant;
        this.firstRecordIndexofGrid = 1;
        this.viewProductMaster = [];
        Observable.forkJoin(this.ViewProductMasterService.getFacilities(),
            this.ViewProductMasterService.getStatus(),
            this.ViewProductMasterService.getProductStatus())
            .subscribe((results: any) => {
                this.facility = results[0];
                this.prodBusLifeCycleStatus = results[1];
                this.selectedProductLifeCycleStatus = ConstantValues.statusActiveCode;
                this.prodStatus = results[2];
                this.selectedProductStatus = ConstantValues.productStatusActiveCode;
                // this.getProductDetails();
            }, (error: Error) => { this._router.navigate([Url.error]); }, () => this.loading = false);
        this.enableDisableButtons();
    }
    showResults(): void {
        this.selectedRow = null;
        if (this.legacyID !== '' || (this.selectedFacility !== '' && this.selectedFacility !== ConstantValues.defaultDropDownOption)) {
            this.getProductDetails();
            this.enableDisableButtons();
        } else {
            this.messageHeader = MessageItems.erroHeader;
            this.returnMessage.message = MessageItems.productSearchMessage;
            this.messageIconType = APP_CONSTANTS.ErrorIcon;
            this.displayMessage = true;
            this.enableDisableButtons();
            return;
        }
    }
    getProductDetails() {
        this.loading = true;
        this.viewProductMaster = [];
        this.productDetails = [];
        const jsonParam = this.getSearchCriteria();
        this.ViewProductMasterService.getProdDetails(jsonParam).
            subscribe((ViewProductMaster: ViewProductMaster[]) => {
                this.viewProductMaster = ViewProductMaster;
                if (this.viewProductMaster.length !== 0) {
                    this.displayGrid = true;
                } else {
                    this.displayGrid = false;
                }
            }, (err: any) => {
                this.err = err;
                if (err !== undefined) {
                    this._router.navigate([Url.error]);
                }
            }, () => {
                this.enableDisableButtons();
                this.loading = false;
            });
    }
    btnClick() {
        if (this.selectedRow !== undefined) {
            this._router.navigateByUrl(RouteURLs.MaintainProductPath + ';legacyId=' + this.selectedRow.productLegacyID);
        }
    }
    s2ab(s) {
        const buf = new ArrayBuffer(s.length);
        const view = new Uint8Array(buf);
        for (let i = 0; i !== s.length; ++i) {
            view[i] = s.charCodeAt(i) & 0xFF;
        }
        return buf;
    }

    exportExcel() {
        let timestamp = '';
        timestamp = CommonUtilitiesComponent.getCurrentDateTimeStamp();
        const sheetName = 'View Product List' + '_' + timestamp + '.xlsx';
        this.loading = true;
        const ws_name = 'Product_Details';
        const wb: WorkBook = { SheetNames: [], Sheets: {} };
        this.productDetails = [];
        this.viewProductMaster.forEach(element => {
            this.facilitiesStacked = '';
            this.facilitiesVal = [];
            if (element.facilityCollection !== null) {
                this.facilitiesVal = element.facilityCollection.split(',');
            }
            this.facilitiesVal.forEach(e => {
                this.productDetails.push({
                    'Product Legacy ID': element.productLegacyID,
                    'Product Description': element.productDescription,
                    'Product Code': element.productCode,
                    'Facility': e.replace(e.split('-')[0].toString(), '').substring(1, e.length - 1),
                    'Product Characteristic(s)': element.characteristicsCollection,
                    'Product Comments': element.prodComments,
                    'VCPT Product Status': element.productStatus,
                    'Product Business Lifecycle Status': element.productBusinessLifeCycleStatus,
                    'SAP Relevancy Status': element.sapRelevancyStatus
                });
            });
        },
            (err) => {
                if (err !== undefined) {
                    // this.messageHeader = MessageItems.erroHeader;
                    // this.returnMessage.message = MessageItems.errorMessgae;
                    // this.messageIconType = APP_CONSTANTS.ErrorIcon;
                    // this.displayMessage = true;
                    this._router.navigate([Url.error]);
                    return;
                }
            });

        const ws: any = utils.json_to_sheet(this.productDetails);
        wb.SheetNames.push(ws_name);
        wb.Sheets[ws_name] = ws;
        const wbout = write(wb, { bookType: 'xlsx', bookSST: true, type: 'binary' });
        this.loading = false;
        saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), sheetName);
    }
    getSearchCriteria(): any {
        const searchSet = new ProductSearchModel();
        if (this.selectedFacility.trim() === ConstantValues.defaultDropDownOption) {
            searchSet.facilityCode = '';
        } else {
            searchSet.facilityCode = this.selectedFacility;
        }
        searchSet.vcptProductStatus = this.selectedProductStatus;
        if (this.selectedProductStatus === ConstantValues.defaultDropDownOption) {
            searchSet.vcptProductStatus = 0;
        }
        if (this.selectedProductLifeCycleStatus.trim() === ConstantValues.defaultDropDownOption) {
            searchSet.productBusinessLifeCycleStatus = '';

        } else {
            searchSet.productBusinessLifeCycleStatus = this.selectedProductLifeCycleStatus;
        }
        if (this.legacyID === undefined || this.legacyID === '') {
            searchSet.productLegacyId = '';

        } else {
            searchSet.productLegacyId = this.legacyID;

        }
        if (this.productDescription === undefined || this.productDescription === '') {
            searchSet.productDescription = '';

        } else {
            searchSet.productDescription = this.productDescription;

        }
        if (this.productCode === undefined || this.productCode === '') {
            searchSet.productCode = '';
        } else {
            searchSet.productCode = this.productCode;
        }
        const jsonParam: any = {
            'productLegacyId': searchSet.productLegacyId,
            'facilityCode': searchSet.facilityCode,
            'productStatus': searchSet.vcptProductStatus,
            'productBusinessLifeCycleStatus': searchSet.productBusinessLifeCycleStatus,
            'productDescription': searchSet.productDescription,
            'productCode': searchSet.productCode
        };

        return jsonParam;
    }
    onGridPageChange(event: any) {
        this.firstRecordIndexofGrid = event.first === 1 ? event.first : event.first + 1;
        this.recordsPerPage = event.first !== 1 ? event.rows + event.first : event.rows;
    }
    enableDisableButtons() {
        const rowSelected = (typeof this.selectedRow !== 'undefined' && this.selectedRow !== null);
        if (this.readOnlyUser) {
            this.disableMaintainProductButton = true;
            this.disabled = true;
        } else {
            this.disableMaintainProductButton = true && !rowSelected;
            this.disabled = false;
        }
    }
    gridRowSelect(event: any) {
        this.enableDisableButtons();
    }

}

