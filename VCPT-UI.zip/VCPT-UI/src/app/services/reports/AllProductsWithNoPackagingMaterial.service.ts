import { Report } from './../../models/Report.model';
import { Url } from './../../shared/constants/app.constants';
import { HttpService } from './../base/http.service';
import { Observable } from 'rxjs/Observable';
import {  Http, Response, RequestOptions, Headers  } from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';


@Injectable()
export class AllProductsWithNoPackagingMaterialService {
    constructor(private httpService: HttpService) { }
getProductDetailsByLegacyID(facilities: string) {
    let jsonParam: any;
    jsonParam = {
      'facilityId': facilities
    };
    return this.httpService.get(Url.ProductWithNoPackagingMaterialUrl, jsonParam);
  }
  getProductDetailsExcelByLegacyID(facilities: string) {
    let jsonParam: any;
    jsonParam = {
      'facilityId': facilities,
      'isExport': true
    };
    return this.httpService.get(Url.ProductWithNoPackagingMaterialUrl, jsonParam);
  }
}
