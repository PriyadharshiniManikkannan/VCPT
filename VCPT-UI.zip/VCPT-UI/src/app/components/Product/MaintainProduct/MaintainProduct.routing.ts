import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MaintainProductComponent } from './MaintainProduct.component';
export const maintainProductRoutes: Routes = [
    {
        path: '',
        component: MaintainProductComponent
    },
    {
        path: ':id',
        component: MaintainProductComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(maintainProductRoutes)],
    exports: [RouterModule]
})
export class MaintainProductRoutingModule {
}
