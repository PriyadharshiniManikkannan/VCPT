import { TestBed, inject } from '@angular/core/testing';
import { HttpModule } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Rx';

import { ViewAllPackagingMaterialsComponent } from './ViewAllPackagingMaterials.component';
import { ViewAllPackagingMaterialsService } from './shared/ViewAllPackagingMaterials.service';
import { ViewAllPackagingMaterials } from './shared/ViewAllPackagingMaterials.model';

describe('a ViewAllPackagingMaterials component', () => {
	let component: ViewAllPackagingMaterialsComponent;

	// register all needed dependencies
	beforeEach(() => {
		TestBed.configureTestingModule({
			imports: [HttpModule],
			providers: [
				{ provide: ViewAllPackagingMaterialsService, useClass: MockViewAllPackagingMaterialsService },
				ViewAllPackagingMaterialsComponent
			]
		});
	});

	// instantiation through framework injection
	beforeEach(inject([ViewAllPackagingMaterialsComponent], (ViewAllPackagingMaterialsComponent) => {
		component = ViewAllPackagingMaterialsComponent;
	}));

	it('should have an instance', () => {
		expect(component).toBeDefined();
	});
});

// Mock of the original ViewAllPackagingMaterials service
class MockViewAllPackagingMaterialsService extends ViewAllPackagingMaterialsService {
	getList(): Observable<any> {
		return Observable.from([ { id: 1, name: 'One'}, { id: 2, name: 'Two'} ]);
	}
}
