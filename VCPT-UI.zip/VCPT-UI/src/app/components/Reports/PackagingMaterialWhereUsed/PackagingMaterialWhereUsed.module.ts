import { DialogDisplayModule } from './../../../shared/components/dialog-display/dialog-display.module';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PackagingMaterialWhereUsedComponent } from './PackagingMaterialWhereUsed.component';
import { PackagingMaterialWhereUsedRouting } from './PackagingMaterialWhereUsed.routing';
import { APP_CONSTANTS } from './../../../shared/constants/app.constants';
import { CommonModule } from '@angular/common';
import { PackagingMaterialWhereUsedService } from './../../../services/reports/PackagingMaterialWhereUsed.service';

import {
    DialogModule, InputMaskModule, ButtonModule,
} from 'primeng/primeng';
@NgModule({
    imports: [
        PackagingMaterialWhereUsedRouting,
        FormsModule, CommonModule,
        DialogModule, InputMaskModule, ButtonModule, ReactiveFormsModule,
        DialogDisplayModule,
        LoadingModule.forRoot(APP_CONSTANTS.loaderConfig)
    ],
    declarations: [PackagingMaterialWhereUsedComponent],
    providers: [PackagingMaterialWhereUsedService]
})
export class PackagingMaterialWhereUsedModule {

}
