import { OnlyNumberModule } from './../../../shared/Directives/OnlyNumber.module';
import { DialogDisplayModule } from './../../../shared/components/dialog-display/dialog-display.module';
import {
    PackagingMaterialForProductConfigurationService
} from './../../../services/packaging/PackagingMaterialsForProductConfiguration.service';
import { APP_CONSTANTS } from './../../../shared/constants/app.constants';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import {
    MaintainPackagingMaterialsForConfigurationComponent
} from './MaintainPackagingMaterialsForConfiguration.component';

import {
    MaintainPackagingMaterialsForConfigurationRoutingModule
} from './MaintainPackagingMaterialsForConfiguration.routing';

import {
    ConfirmDialogModule, ConfirmationService,
    InputMaskModule,
    DataTableModule, SharedModule, DialogModule, AccordionModule
} from 'primeng/primeng';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';

@NgModule({
    imports: [
        MaintainPackagingMaterialsForConfigurationRoutingModule,
        ConfirmDialogModule,
        InputMaskModule,
        DialogModule,
        DataTableModule,
        AccordionModule,
        DialogDisplayModule,
        SharedModule,
        FormsModule,
        ReactiveFormsModule,
        LoadingModule.forRoot(APP_CONSTANTS.loaderConfig),
        CommonModule,
        OnlyNumberModule
    ],
    providers: [ConfirmationService, PackagingMaterialForProductConfigurationService],
    declarations: [MaintainPackagingMaterialsForConfigurationComponent]
})
export class MaintainPackagingMaterialsForConfigurationModule {

}
