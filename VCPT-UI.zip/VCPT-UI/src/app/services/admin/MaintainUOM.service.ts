
import { MaintainUOM } from './../../models/MaintainUOM.model';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import {Url } from '../../shared/constants/app.constants';
import { HttpService  } from '../../services/base/http.service';

@Injectable()
export class MaintainUOMService {
    constructor(private _http: Http, private _httpService: HttpService) { }
    getUOM() {
       return this._httpService.get( Url.UomDetailsUrl);
    }
    addUOM(MaintainUOM: MaintainUOM) {
      return  this._httpService.post( Url.UomDetailsUrl, MaintainUOM);
    }

   
}
