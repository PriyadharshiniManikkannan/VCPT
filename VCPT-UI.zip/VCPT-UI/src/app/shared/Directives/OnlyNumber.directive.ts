import { Directive, ElementRef, HostListener, Input } from '@angular/core';
import * as Inputmask from 'inputmask';


@Directive({
    selector: '[OnlyNumber]'
})
export class OnlyNumberDirective {

  // map of some of the regex strings I'm using (TODO: add your own)
  private regexMap = {
    integer: '^[0-9]*$',
    decimal: '^\\d{0,11}(\\.\\d{0,5})?$',
  };

  constructor(private el: ElementRef) {}

  @Input('OnlyNumber')
  public set defineInputType(type: string) {
    Inputmask({regex: this.regexMap[type], placeholder: ''})
      .mask(this.el.nativeElement);
  }

}
