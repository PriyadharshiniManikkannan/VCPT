import { Facility } from './../../../models/ViewProductMaster.model';
import { SecurityService } from './../../../services/Security.service';
import { saveAs } from 'file-saver';
import {
    PackagingMaterialForProductConfigurationService
} from './../../../services/packaging/PackagingMaterialsForProductConfiguration.service';
import { MaintainPackagingMaterialsForProductService } from './../../../services/packaging/MaintainPackagingMaterialsForProduct.service';
import { FormControl, FormBuilder, FormGroup } from '@angular/forms';
import { MessageModel } from './../../../models/MessageModel.model';
import { PackagingMaterialsForProductConfiguration } from './../../../models/PackagingMaterialForProductConfiguration.model';
import {
    APP_CONSTANTS, excludeColumns, RouteURLs, ConstantValues,
    MessageItems, containsSearchfilterColumns, Url
} from './../../../shared/constants/app.constants';
import { ScreenTitles, FormLabelValues } from './../../../shared/constants/form.constants';
import { MaintainProductConfigurations } from './../../../models/MaintainProductConfigurations.model';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

import { SelectItem, Message, ConfirmationService } from 'primeng/primeng';
import { DialogModule } from 'primeng/primeng';
import { utils, write, WorkBook } from 'xlsx';

@Component({
    templateUrl: 'ViewAllPackagingMaterialsforConfigurations.component.html',
    styleUrls: ['./ViewAllPackagingMaterialsforConfigurations.component.scss']
})

export class ViewAllPackagingMaterialsforConfigurationsComponent implements OnInit {
    facilityDropdownItems: string[];
    packagingConfiguration: any[];
    packagingSupplies: any[];
    associatedPackagingSupplies: any[];
    activeConfiguration: any[];
    displayConfigGrid: boolean;
    displayPackagingGrid: boolean;
    displayAssociateGrid: boolean;
    columnNamesForConfigurationGrid: any[];
    recordsPerPageforConfigurationGrid: number;
    firstRecordIndexofConfigurationGrid: number;
    vals: any[];
    legacyID: string;
    SAPRelevancy: string;
    ProductCode: string;
    ProductDesc: string;
    productConfigId: number;
    facilityId: string;
    Facility: string;
    msgs: Message[];
    facilities: any[];
    selectedFacilities: string[];
    ProductComments: string;
    disableFacilityDropdown: boolean;
    configurationComments: string;
    displayDialog: boolean;
    displayPrintDialog: boolean;
    PackagingMaterialLegacyId: any;
    PackagingMaterialDescription: any;
    SAPBasicDataText: any;
    Quantity: any;
    QuantityUOM: any;
    Scrap: any;
    popupTitle: string;
    formLabels: any = FormLabelValues;
    formTitle: any;
    messageHeader: string;
    displayMessage: boolean;
    returnMessage: MessageModel;
    searchFormGroup: FormGroup;
    commaSeperatedFacilities: string;
    commaSeperatedFacilityIds: string;
    readOnlyUser: boolean;
    public loading = false;
    showOkButton: boolean;
    productDetailSelected: boolean;
    packagingMaterialDetails: PackagingMaterialsForProductConfiguration;
    isDisable: boolean;
    disableMaintainPackagingMaterialsForProductConfiguration: boolean;
    selectedConfigurationRow: any;
    messageIconType: string;
    ConstantValues: any;
    constructor(private formBuilder: FormBuilder, private activatedRoute: ActivatedRoute,
        private confirmationService: ConfirmationService, private router: Router,
        private packagingMaterialForProductConfigurationService: PackagingMaterialForProductConfigurationService,
        private maintainPackagingMaterialsForProductService: MaintainPackagingMaterialsForProductService,
        private securityService: SecurityService) {

    }


    ngOnInit() {
        this.loading = true;
        this.ConstantValues = ConstantValues;
        this.buildForm();
        this.readOnlyUser = this.securityService.isReadOnlyUser();
        this.initializeform(true);
        this.activatedRoute.params.subscribe((params: any) => {
            if (params) {
                if (params['id'] && params['id'] !== '') {
                    this.searchFormGroup.get('productLegacyID').patchValue(params['id']);
                    this.loading = true;
                    this.showResults();
                }
            }
        },
            (err) => {
                if (err !== undefined) {
                    this.router.navigate([Url.error]);
                    return;
                }
            });

    }
    buildForm() {
        this.searchFormGroup = this.formBuilder.group({ productLegacyID: new FormControl('') });
    }
    showResults(): void {
        this.loading = true;
        this.packagingMaterialDetails.configurationDetails = [];
        this.packagingMaterialDetails.productPackagingMaterialsMapping = [];
        this.packagingMaterialDetails.packagingDetails = [];
        const jsonParam = { legacyID: this.searchFormGroup.get('productLegacyID').value };
        this.messageHeader = 'Get Details for Product';
        if (this.searchFormGroup.get('productLegacyID').value) {
            this.packagingMaterialForProductConfigurationService
                .getProductDetails(jsonParam)
                .subscribe((productDetails: any) => {
                    if (productDetails && productDetails.message) {
                        this.showMessage(productDetails, this.messageHeader);
                        this.initializeform(false);
                    } else if (productDetails.productId) {
                        this.packagingMaterialDetails.productDetails = productDetails;
                        this.packagingMaterialDetails.productDetails.applicableFacilities.sort(function (a, b) {
                            return a.facilityName.localeCompare(b.facilityName);
                        });
                        this.maintainPackagingMaterialsForProductService
                            .getPackagingDetailsByProductId(this.packagingMaterialDetails.productDetails.productId)
                            .subscribe((packagingMaterialsForProduct: any) => {
                                if (packagingMaterialsForProduct && packagingMaterialsForProduct.message) {
                                    this.showMessage(packagingMaterialsForProduct, this.messageHeader);
                                } else if (packagingMaterialsForProduct && packagingMaterialsForProduct.length > 0
                                    && packagingMaterialsForProduct[0].pkgConfigMapId) {
                                    this.packagingMaterialDetails.productPackagingMaterialsMapping = packagingMaterialsForProduct;

                                }
                            },
                            (err) => {
                                if (err !== undefined) {
                                    this.router.navigate([Url.error]);
                                    return;
                                }
                            });
                        this.disableFacilityDropdown = false;
                        this.productDetailSelected = true;
                    }

                }, (error: Error) => {
                    this.router.navigate([Url.error]);
                    this.loading = false;
                }, () => this.loading = false
                );
        } else {
            this.initializeform(false);
            const returnMessage = { message: '', messageType: '' };
            returnMessage.message = MessageItems.draftMessage;
            returnMessage.messageType = 'Error';
            this.showMessage(returnMessage, MessageItems.productHeader);
            this.loading = false;
            return;
        }
    }
    getColumnforConfigurationGrid(obj: any): void {
        if (obj && obj.length) {
            const keys = Object.keys(obj[0]);
            const cols = [];
            keys.filter(key => excludeColumns.columns.indexOf(key) < 0
                && excludeColumns.hiddenColumns.indexOf(key) < 0)
                .forEach(key => cols.push({
                    field: key, header: key,
                    filter: containsSearchfilterColumns.columns.indexOf(key) < 0 ?
                        ConstantValues.equalsFilter : ConstantValues.containsFilter,
                    hidden: excludeColumns.hiddenColumns.indexOf(key) < 0 ? false : true
                }));

            this.columnNamesForConfigurationGrid = cols;
        }
    }

    initializeform(initializeMessage: boolean) {
        this.loading = true;
        this.packagingMaterialDetails = new PackagingMaterialsForProductConfiguration();
        this.commaSeperatedFacilities = '';
        this.commaSeperatedFacilityIds = '';
        this.activeConfiguration = [];
        this.firstRecordIndexofConfigurationGrid = 1;
        this.recordsPerPageforConfigurationGrid = APP_CONSTANTS.recordsPerPageConstant;
        this.SAPRelevancy = '';
        this.ProductCode = '';
        this.ProductDesc = '';
        this.Facility = '';
        this.configurationComments = '';
        this.displayConfigGrid = false;
        this.displayPackagingGrid = false;
        this.displayAssociateGrid = false;
        this.productDetailSelected = false;
        this.columnNamesForConfigurationGrid = [];
        this.msgs = [];
        this.ProductComments = '';
        this.facilities = [];
        this.selectedFacilities = [];
        this.disableFacilityDropdown = true;
        this.displayDialog = false;
        this.packagingConfiguration = [];
        this.packagingSupplies = [];
        this.associatedPackagingSupplies = [];
        this.formTitle = ScreenTitles;
        this.loading = false;
        this.enableDisableButtons();
        if (initializeMessage) {
            this.initializeMessage();
        }
    }
    configurationGridRowSelect(event: any) {
        this.selectedConfigurationRow = event.data;
        this.packagingMaterialDetails.packagingDetails = [];
        this.configurationComments = event.data['Configuration Comments'] ? event.data['Configuration Comments'].toString() : '';
        const jsonParam: any = {};
        jsonParam.productConfigurationId = event.data['ProdConfigId'];
        jsonParam.facilityId = this.facilityId;
        this.productConfigId = event.data['ProdConfigId'];
        if (jsonParam.productConfigurationId) {
            this.isDisable = false;
            this.loading = true;
            this.packagingMaterialForProductConfigurationService
                .getPackagingMaterialsForProductConfigurationNoLock(jsonParam)
                .subscribe((packagingDetails: any) => {
                    if (packagingDetails && packagingDetails.message) {
                        this.returnMessage = packagingDetails;
                    } else if (packagingDetails && packagingDetails.length > 0) {
                        this.packagingMaterialDetails.packagingDetails = packagingDetails;
                    }
                }, (error: Error) => {
                    this.router.navigate([Url.error]);
                    this.loading = false;
                }
                );
        } else {
            this.isDisable = true;
        }
        this.enableDisableButtons();
        this.loading = false;
    }
    getCommaSeperatedFacilities(): string {
        this.commaSeperatedFacilities = '';
        if (this.packagingMaterialDetails.productDetails.applicableFacilities
            && this.packagingMaterialDetails.productDetails.applicableFacilities.length > 0) {
            for (let i = 0; i < this.packagingMaterialDetails.productDetails.applicableFacilities.length; i++) {
                if (i !== this.packagingMaterialDetails.productDetails.applicableFacilities.length - 1) {
                    this.commaSeperatedFacilities =
                        this.commaSeperatedFacilities
                        + this.packagingMaterialDetails.productDetails.applicableFacilities[i].facilityName + ', ';
                } else {
                    this.commaSeperatedFacilities = this.commaSeperatedFacilities
                        + this.packagingMaterialDetails.productDetails.applicableFacilities[i].facilityName;
                }
            }
        }
        return this.commaSeperatedFacilities;
    }
    getCommaSeperatedFacilityIds(): string {
        this.commaSeperatedFacilityIds = '';
        if (this.packagingMaterialDetails.productDetails.applicableFacilities
            && this.packagingMaterialDetails.productDetails.applicableFacilities.length > 0) {
            for (let i = 0; i < this.packagingMaterialDetails.productDetails.applicableFacilities.length; i++) {
                if (i !== this.packagingMaterialDetails.productDetails.applicableFacilities.length - 1) {
                    this.commaSeperatedFacilityIds =
                        this.commaSeperatedFacilities
                        + this.packagingMaterialDetails.productDetails.applicableFacilities[i].facilityID + ',';
                } else {
                    this.commaSeperatedFacilities = this.commaSeperatedFacilities
                        + this.packagingMaterialDetails.productDetails.applicableFacilities[i].facilityID;
                }
            }
        }
        return this.commaSeperatedFacilities;
    }
    getConfigurationsForFacility(event: any) {
        this.isDisable = true;
        this.packagingMaterialDetails.packagingDetails = [];
        this.packagingMaterialDetails.configurationDetails = [];
        this.configurationComments = '';
        if (event.target.value > 0) {
            this.loading = true;
            this.facilityId = event.target.value.toString();
            const productConfigurations = new MaintainProductConfigurations();
            productConfigurations.productId = this.packagingMaterialDetails.productDetails.productId.toString();
            productConfigurations.facilityCollection = event.target.value;
            productConfigurations.getOnlyActiveConfiguration = true;
            this.packagingMaterialForProductConfigurationService.getFacilityById(event.target.value).subscribe((facility: Facility) => {
                this.packagingMaterialDetails.facilityName = facility.facilityName;
            });
            if (this.packagingMaterialDetails.productDetails.productId > 0) {
                this.packagingMaterialForProductConfigurationService
                    .getProductConfigurationDetails(productConfigurations)
                    .subscribe((activeConfigurations: any) => {
                        if (activeConfigurations && activeConfigurations.message) {
                            this.returnMessage = activeConfigurations;
                        } else if (activeConfigurations && activeConfigurations.length && activeConfigurations.length > 0) {
                            this.packagingMaterialDetails.configurationDetails = [];
                            this.packagingMaterialDetails.configurationDetails = activeConfigurations;
                            this.getColumnforConfigurationGrid(this.packagingMaterialDetails.configurationDetails);
                        }
                        this.loading = false;
                    }, (error: Error) => {
                        this.enableDisableButtons();
                        this.router.navigate([Url.error]);
                        this.loading = false;
                    }
                    );
            }
        } else {
            this.packagingMaterialDetails.configurationDetails = [];
            this.columnNamesForConfigurationGrid = [];
        }
    }
    onConfigurationGridPageChange(event: any) {
        this.firstRecordIndexofConfigurationGrid = event.first === 1 ? event.first : event.first + 1;
        this.recordsPerPageforConfigurationGrid = event.first !== 1 ? event.rows + event.first : event.rows;
    }
    s2ab(s) {
        const buf = new ArrayBuffer(s.length);
        const view = new Uint8Array(buf);
        for (let i = 0; i !== s.length; ++i) {
            view[i] = s.charCodeAt(i) & 0xFF;
        }
        return buf;
    }
    exportToExcel() {
        this.loading = true;
        const workBook: WorkBook = { SheetNames: [], Sheets: {} };
        const workSheetName = 'PackagingMaterialsForConfig';
        const timestamp = new Date();
        const packagingMaterialForProductConfiguration: any = {};
        const excelName = 'PackagingMaterialsForProductConfigurations' + '_'
            + timestamp.getDate().toString()
            + '_'
            + timestamp.getTime().toString()
            + '.xlsx';
        packagingMaterialForProductConfiguration.productLegacyId = this.searchFormGroup.get('productLegacyID').value;
        packagingMaterialForProductConfiguration.productConfigurationID = this.productConfigId;
        packagingMaterialForProductConfiguration.facilityId = this.facilityId;
        this.packagingMaterialForProductConfigurationService
            .getPackagingMaterialsForProductConfigurationInExportFormat(packagingMaterialForProductConfiguration).
            subscribe((packagingConfigurationDetails: any) => {
                if (packagingConfigurationDetails && packagingConfigurationDetails.length > 0) {
                    const ws: any = utils.json_to_sheet(packagingConfigurationDetails);
                    workBook.SheetNames.push(workSheetName);
                    workBook.Sheets[workSheetName] = ws;
                    const wbout = write(workBook, { bookType: 'xlsx', bookSST: true, type: 'binary' });
                    saveAs(new Blob([this.s2ab(wbout)],
                        { type: 'application/octet-stream' }),
                        excelName
                    );
                } else {
                    this.returnMessage.messageHeader = MessageItems.erroHeader;
                    this.returnMessage.messageIconClass = APP_CONSTANTS.ErrorIcon;
                    this.returnMessage.message = MessageItems.noResultsMessage;
                    this.displayMessage
                        = true;
                }
            },
            (err) => {
                if (err !== undefined) {
                    this.router.navigate([Url.error]);
                    return;
                }
            });

        this.loading = false;
    }
    printPackagingMaterialsforConfiguration() {
        this.displayPrintDialog = true;
        // const popupWindow = window
        //     .open('', '_blank', 'height=auto,width=auto,menubar=no,toolbar=no,location=no,status=no,titlebar=no,scrollbars=1');
        // popupWindow.document.open();
        // popupWindow.document.write(document.getElementById('printTemplate').innerHTML);
        // popupWindow.document.close();
    }
    printDocument(event) {
        const printWindow =
            window.open('', '_blank',
                'scrollbars=no,menubar=no,toolbar=no,location=no,status=no,titlebar=no');
        printWindow.document.open();
        printWindow.document.write(document.getElementById('printTemplate').innerHTML);
        printWindow.document.close();
        printWindow.print();
        this.displayPrintDialog = false;
    }
    cancelDocumentPrint(event) {
        this.displayPrintDialog = false;
    }
    maintainPackagingConfiguration() {
        // tslint:disable-next-line:max-line-length
        if (this.searchFormGroup.get('productLegacyID').value !== '' && this.searchFormGroup.get('productLegacyID').value !== undefined && (this.searchFormGroup.get('productLegacyID').value).length === ConstantValues.productLegacyIDLength) {
            this.router.navigateByUrl(RouteURLs.MaintainPackagingMaterialsConfigurationPath + ';id=' + this.searchFormGroup.get('productLegacyID').value);
        }
    }
    showMessage(messageToShow: any, messageHeader: any) {
        this.initializeMessage();
        this.returnMessage.messageCode = messageToShow.messageCode;
        this.returnMessage.messageHeader = messageHeader;
        if (messageToShow.listofItemsforDisplay) {
            messageToShow.listofItemsforDisplay.forEach(message =>
                this.returnMessage.listofItemsforDisplay.push(message));
        }
        this.returnMessage.message = messageToShow.message;
        this.returnMessage.messageType = messageToShow.messageType;
        this.getIconforMessageDisplay();
        this.returnMessage.messageIconClass = this.messageIconType;
        this.displayMessage
            = this.returnMessage.message !== '' && this.returnMessage.message !== null ? true : false;
    }
    initializeMessage() {
        this.displayMessage = false;
        this.returnMessage = new MessageModel();
        this.messageHeader = '';
        this.messageIconType = 'Information';
    }
    getIconforMessageDisplay() {
        switch (this.returnMessage.messageType.trim().toUpperCase()) {
            case 'Error'.toUpperCase(): this.messageIconType = APP_CONSTANTS.ErrorIcon;
                break;
            case 'Information'.toUpperCase(): this.messageIconType = APP_CONSTANTS.InformationIcon;
                break;
            case 'Warning'.toUpperCase(): this.messageIconType = APP_CONSTANTS.WarningIcon; break;
            default: this.messageIconType = APP_CONSTANTS.InformationIcon; break;
        }
    }
    enableDisableButtons() {
        const configurationSelected =
            (typeof this.selectedConfigurationRow !== 'undefined'
                && this.selectedConfigurationRow !== null);

        this.isDisable = !configurationSelected;

        if (this.readOnlyUser) {
            this.disableMaintainPackagingMaterialsForProductConfiguration = true;
        } else {
            this.disableMaintainPackagingMaterialsForProductConfiguration = true && !configurationSelected;
        }
    }
}
