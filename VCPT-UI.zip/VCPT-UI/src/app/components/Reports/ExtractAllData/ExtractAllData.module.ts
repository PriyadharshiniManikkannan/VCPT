import { ExtractAllDataService } from './../../../services/reports/ExtractAllData.service';
import { NgModule } from '@angular/core';
import { DialogDisplayModule } from './../../../shared/components/dialog-display/dialog-display.module';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ExtractAllDataComponent } from './ExtractAllData.component';
import { ExtractAllDataRoutingModule } from './ExtractAllData.routing';
import { APP_CONSTANTS } from './../../../shared/constants/app.constants';
import { CommonModule } from '@angular/common';

import {
    DialogModule, InputMaskModule, ButtonModule, ListboxModule, AccordionModule
} from 'primeng/primeng';
@NgModule({
    imports: [
        FormsModule, CommonModule,
        DialogModule, InputMaskModule, ButtonModule, ListboxModule,
        ReactiveFormsModule,
        AccordionModule,
        DialogDisplayModule,
        LoadingModule.forRoot(APP_CONSTANTS.loaderConfig)
    ],
    declarations: [ExtractAllDataComponent],
    providers: [ExtractAllDataService]
})
export class ExtractAllDataModule {

}
