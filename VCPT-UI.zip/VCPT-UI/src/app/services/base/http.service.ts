import { SessionConstants, Url } from './../../shared/constants/app.constants';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptionsArgs, Response } from '@angular/http';
import { environment } from '../../../environments/environment';
import { Router } from '@angular/router';

@Injectable()
export class HttpService {

  private headers = new Headers({ 'Content-Type': 'application/json' });

  constructor(private http: Http) {
  }

  private extractData<T>(res: Response): T {
    let body;

    // check if empty, before call json
    if (res.text()) {
      body = res.json();
    }

    return body || {};
  }

  private handleError<T>(error: any): Observable<T> {

    // let errorJson;
    // let errMsg;

    // if (error) {
    //   try {
    //     errorJson = error.json();
    //     errMsg = errorJson.message;
    //     this.router.navigate([Url.error]);

    //   } catch (e) {
    //     this.router.navigate([Url.error]);
    //   }
    // } else {
    //   this.router.navigate([Url.error]);
    // }

    // if (error && error.status && error.status === 401 || error.status === 403 || error.status === 500) {
    //   this.router.navigate([Url.error]);
    // }
    // this.router.navigate([Url.error]);
    return Observable.throw(error);
  }

  private isJson(str) {
    try {
      JSON.parse(str);
    } catch (e) {
      return false;
    }
    return true;
  }

  private queryString(jsonArray) {
    if (!jsonArray || jsonArray.length === 0) {
      return '';
    }
    const str = [];
    for (const p in jsonArray) {
      if (jsonArray.hasOwnProperty(p)) {
        str.push(encodeURIComponent(p) + '=' + encodeURIComponent(jsonArray[p]));
      }
    }
    if (str.length > 0) {
      return '?' + str.join('&');
    }
    return '';
  }

  get(url, params?: any, options?: any) {
    return this.http.get(environment.baseURL + url + this.queryString(params), this.appendAuthHeader(options))
      .map(this.extractData)
      .catch(this.handleError);
  }

  post(url, params?: any, options?: any) {
    return this.http.post(environment.baseURL + url, JSON.stringify(params), this.appendAuthHeader(options))
      .map(this.extractData)
      .catch(this.handleError);
  }

  put(url, params?: any, options?: any) {
    return this.http.put(environment.baseURL + url, JSON.stringify(params), this.appendAuthHeader(options))
      .map(this.extractData)
      .catch(this.handleError);
  }

  delete(url, params?: any, options?: any) {
    return this.http.delete(environment.baseURL + url + this.queryString(params), this.appendAuthHeader(options))
      .map(this.extractData)
      .catch(this.handleError);
  }

  /**
   * Method: appendAuthHeader
   *
   * Usage: To append headers to send.
   *
   * @param options - The custom header options to send.
   */
  private appendAuthHeader(options?: RequestOptionsArgs): RequestOptionsArgs {
    let mergedOptions: RequestOptionsArgs;
    if (!options) {
      mergedOptions = { headers: this.headers };
    } else {
      mergedOptions = options;
    }
    mergedOptions.withCredentials = true;
    if (environment.production === false && mergedOptions.headers.get('USERNAME') === null) {
      mergedOptions.headers.append('USERNAME', 'VCPT');
    }
    return mergedOptions;
  }

  /**
   * Method Name: synchronousPost
   *
   * Usage: Used to send synchronous http Post requests
   *
   * Parameters:
   *
   * 1. url: The API route URL that needs to be added with the base URL.
   * 2. params: The parameter that needs to be added to the body of the Post request.
   *
   * Note: The parameters added to the body will be converted to JSON object.
   *
   * @param url - The API Url.
   * @param params - Parameter for the API Url.
   */
  synchronousPost(url, params?: any) {
    const xhrRequest = new XMLHttpRequest();
    xhrRequest.open('POST', environment.baseURL + url, false);
    xhrRequest.setRequestHeader('Content-Type', 'application/json');
    xhrRequest.withCredentials = true;
    if (environment.production === false) {
      xhrRequest.setRequestHeader('USERNAME', 'VCPT');
    }
    xhrRequest.send(JSON.stringify(params));
  }

}
