import {NgModule} from '@angular/core';

import {HomeComponent} from './Home.component';
import {HomeRoutingModule} from './Home.routing';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

@NgModule({
  imports: [
    HomeRoutingModule,
    BrowserAnimationsModule,
  ],
  declarations: [HomeComponent],
  providers: [
  ]
})
export class HomeModule {
}
