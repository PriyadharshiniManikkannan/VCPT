import { Component, OnInit, HostListener } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { MaintainProductConfigurationsService } from './../../../services/product/MaintainProductConfigurations.service';
import { MaintainProductConfigurations, UOM } from './../../../models/MaintainProductConfigurations.model';
import { ViewProductMaster } from './../../../models/ViewProductMaster.model';
import { utils, write, WorkBook } from 'xlsx';
import { saveAs } from 'file-saver';
import { element } from 'protractor';
import {
    APP_CONSTANTS, ConstantValues, excludeColumns, containsSearchfilterColumns,
    RouteURLs, MessageItems, StatusCode, Url
} from '../../../shared/constants/app.constants';
import { Observable } from 'rxjs/Observable';
import { MessageModel } from './../../../models/MessageModel.model';
import { Observer } from 'rxjs/Observer';
import { FormLabelValues, ScreenTitles } from './../../../shared/constants/form.constants';
import { SelectItem, Message } from 'primeng/primeng';
import { ConfirmationService, DialogModule } from 'primeng/primeng';
@Component({
    templateUrl: './MaintainProductConfigurations.component.html',
    styleUrls: ['./MaintainProductConfigurations.component.scss']
})

export class MaintainProductConfigurationsComponent implements OnInit {
    facilityDropdownItems: SelectItem[];
    activeConfiguration: any[];
    displayConfigGrid: boolean;
    colsGrid: any[] = [];
    legacyID: string;
    productID: any;
    SAPRelevancy: string;
    ProductCode: string;
    ProductDesc: string;
    displayDialog: boolean;
    Facility: string;
    productStatusCode: string;
    selectedFacilityValues: string;
    data: any;
    err: any;
    message: boolean;
    productDetailSelected: boolean;
    editAccess: boolean;
    adminAccess: boolean;
    viewProductDetails: MaintainProductConfigurations[];
    disabled: boolean;
    addDisabled: boolean;
    facilityCollection: any[];
    popupTitle: string;
    selectedFacilities: string[];
    configComment: string;
    dynamicConfig: any[];
    formcontrolsCheck: any[];
    isActive: boolean;
    isDraft: boolean;
    productConfigId: number;
    facilitiesbyConfigId: any[];
    Submit: boolean;
    dirty: number;
    statusCode: string;
    isValidate: boolean;
    isValidateValue: boolean;
    displayMessage: boolean;
    returnMessage: MessageModel;
    productComments: string;
    productBusinessLifeCycleStatus: string;
    isFacilitiesDeslected: boolean;
    recordsPerPage: number;
    firstRecordIndexofGrid: number;
    messageHeader: string;
    messageIconType: string;
    formLabels: any;
    formTitle: any;
    duplicateConfigFacility: string[];
    ConstantValues: any;
    valuesMessage: string;
    messageItems: any;
    // Loading variable for ngx-loading component
    public loading = false;
    constructor(
        private MaintainProductConfigurationService: MaintainProductConfigurationsService, private _router: Router,
        private activatedRoute: ActivatedRoute,
        private router: Router,
        private confirmationService: ConfirmationService,

    ) { }
    ngOnInit() {
        this.formLabels = FormLabelValues;
        this.ConstantValues = ConstantValues;
        this.loading = true;
        this.dirty = 0;
        this.SAPRelevancy = '';
        this.ProductCode = '';
        this.ProductDesc = '';
        this.Facility = '';
        this.displayConfigGrid = false;
        this.facilityDropdownItems = [];
        this.configComment = '';
        this.returnMessage = new MessageModel();
        this.editAccess = true;
        this.addDisabled = true;
        this.productBusinessLifeCycleStatus = '';
        this.formTitle = ScreenTitles;
        this.productDetailSelected = false;
        this.Submit = false;
        this.isValidateValue = false;
        this.messageItems = MessageItems;
        this.recordsPerPage = APP_CONSTANTS.recordsPerPageConstant;
        this.activeConfiguration = [];
        this.firstRecordIndexofGrid = 1;
        if (this.editAccess || this.adminAccess) {
            this.disabled = false;
        } else {
            this.disabled = true;
        }

        this.activatedRoute.params.subscribe((params: Params) => {
            this.legacyID = params['id'];
        }, (error: Error) => {
            this.router.navigate([Url.error]);
            this.loading = false;
        }
        );
        if (this.legacyID !== undefined && this.legacyID !== '' && this.legacyID.length === ConstantValues.productLegacyIDLength) {
            const prod = new ViewProductMaster();
            prod.productLegacyID = this.legacyID;
            prod.facilityCode = '';
            prod.productStatus.statusCode = 0;
            prod.productBusinessLifeCycleStatus.statusCode = '';
            prod.productDescription = '';
            prod.productCode = '';
            this.getProductDetails(prod);
        } else {
            this.loading = false;
        }
    }
    showResults(): void {
        this.loading = true;
        if (this.legacyID !== undefined && this.legacyID !== '' && this.legacyID.length === ConstantValues.productLegacyIDLength) {
            const prod = new ViewProductMaster();
            prod.productLegacyID = this.legacyID;
            prod.facilityCode = '';
            prod.productStatus.statusCode = 0;
            prod.productBusinessLifeCycleStatus.statusCode = '';
            prod.productDescription = '';
            prod.productCode = '';
            this.selectedFacilityValues = '';
            this.getProductDetails(prod);
            this.loading = false;
        } else {
            this.returnMessage.messageHeader = MessageItems.productHeader;
            this.returnMessage.message = MessageItems.draftMessage;
            this.returnMessage.messageIconClass = APP_CONSTANTS.ErrorIcon;
            this.displayMessage = true;
            this.loading = false;
            return;
        }
    }
    getColumnforGrid(obj: any): void {
        if (obj && obj.length) {
            const keys = Object.keys(obj[0]);
            const cols = [];
            let j = 0;
            keys.forEach(function (k: any) {
                for (let i = 0; i <= excludeColumns.columns.length - 1; i++) {
                    if (k === excludeColumns.columns[i]) {
                        j = 1;
                    }
                }
                let filter = ConstantValues.equalsFilter;
                for (let i = 0; i <= containsSearchfilterColumns.columns.length - 1; i++) {
                    if (k.toString().toLowerCase() === containsSearchfilterColumns.columns[i].toString().toLowerCase()) {

                        filter = ConstantValues.containsFilter;
                    }
                }
                if (j === 0) {
                    cols.push({ field: k, header: k, filter: filter });
                }
                j = 0;
            });

            this.colsGrid = cols;
        }
    }
    getProductDetails(prod) {
        this.loading = true;
        this.displayConfigGrid = false;
        this.selectedFacilityValues = '';
        this.productBusinessLifeCycleStatus = '';
        this.MaintainProductConfigurationService.getProductDetailsByLegacyID(prod).
            subscribe((ViewProductDetails: MaintainProductConfigurations[]) => {
                this.viewProductDetails = ViewProductDetails;
                if (this.viewProductDetails !== undefined) {
                    if (this.viewProductDetails.length !== 0) {
                        this.addDisabled = false;
                        this.productDetailSelected = true;
                        this.viewProductDetails.forEach(element => {
                            this.productStatusCode = element.productStatus;
                            this.productBusinessLifeCycleStatus = element.productBusinessLifeCycleStatus;
                            const facilityArray = [];
                            if (this.productStatusCode.toString().toLowerCase()
                                === ConstantValues.statusActive.toLowerCase()
                                && this.productBusinessLifeCycleStatus.toString().toLowerCase()
                                !== ConstantValues.statusInActive.toLowerCase()
                                && this.productBusinessLifeCycleStatus.toString().toLowerCase()
                                !== ConstantValues.statusObsolete.toLowerCase()) {
                                this.SAPRelevancy = element.sapRelevancyStatus;
                                this.ProductCode = element.productCode;
                                this.ProductDesc = element.productDescription;
                                this.productID = element.productId;
                                this.productComments = element.productComments;
                                if (element.facilityCollection !== null) {
                                    this.facilityCollection = element.facilityCollection.split(',');
                                    this.facilityCollection.forEach(e => {
                                        this.selectedFacilityValues += e.split('-')[0].toString() + ',';
                                        e = e.replace(e.split('-')[0].toString(), '');
                                        facilityArray.push({ 'Facility': e.replace(e.substring(0, 10), '') });
                                    });
                                    facilityArray.sort(function (a, b) {
                                        return a.Facility.localeCompare(b.Facility);
                                    });
                                    this.Facility = '';
                                    facilityArray.forEach(e => {
                                        this.Facility += e.Facility + ', ';
                                    });
                                    if (this.Facility !== '') {
                                        this.Facility = this.Facility.substring(0, this.Facility.length - 2);
                                    }
                                    if (this.selectedFacilityValues !== '' && this.selectedFacilityValues !== undefined) {
                                        this.selectedFacilityValues =
                                            this.selectedFacilityValues.substring(0, this.selectedFacilityValues.length - 1);
                                        const viewProductConfig = new MaintainProductConfigurations();
                                        viewProductConfig.productId = this.productID;
                                        viewProductConfig.facilityCollection = this.selectedFacilityValues;
                                        this.MaintainProductConfigurationService.getProductConfigurationByFacility(viewProductConfig).
                                            subscribe((ViewProductconfiguartion: any) => {
                                                this.activeConfiguration = ViewProductconfiguartion;
                                                if (this.activeConfiguration.length > 0) {
                                                    this.getColumnforGrid(this.activeConfiguration);
                                                    this.displayConfigGrid = true;
                                                } else {
                                                    this.displayConfigGrid = false;
                                                }
                                            },
                                            (err) => {
                                                if (err !== undefined) {
                                                    this._router.navigate([Url.error]);
                                                    return;
                                                }
                                            });

                                    } else {
                                        this.displayConfigGrid = false;
                                    }
                                } else {
                                    this.SAPRelevancy = '';
                                    this.ProductCode = '';
                                    this.ProductDesc = '';
                                    this.Facility = '';
                                    this.addDisabled = true;
                                    this.productDetailSelected = false;
                                    this.productID = '';
                                    this.productComments = '';
                                    this.returnMessage.messageHeader = MessageItems.productHeader;
                                    this.returnMessage.message = MessageItems.draftMessage;
                                    this.returnMessage.messageIconClass = APP_CONSTANTS.ErrorIcon;
                                    this.displayMessage = true;
                                    this.loading = false;
                                    return;
                                }
                            } else if (this.productStatusCode.toLowerCase() === ConstantValues.productStatusDraft.toLowerCase()) {
                                this.SAPRelevancy = '';
                                this.ProductCode = '';
                                this.ProductDesc = '';
                                this.Facility = '';
                                this.productID = '';
                                this.productComments = '';
                                this.addDisabled = true;
                                this.productDetailSelected = false;
                                this.returnMessage.messageHeader = MessageItems.productHeader;
                                this.returnMessage.message = MessageItems.draftMessage;
                                this.returnMessage.messageIconClass = APP_CONSTANTS.ErrorIcon;
                                this.displayMessage = true;
                                this.loading = false;
                                this.activeConfiguration = [];
                                return;
                            } else if (this.productStatusCode.toLowerCase() === ConstantValues.productStatusInActive.toLowerCase()) {
                                this.SAPRelevancy = '';
                                this.ProductCode = '';
                                this.ProductDesc = '';
                                this.Facility = '';
                                this.productID = '';
                                this.productComments = '';
                                this.addDisabled = true;
                                this.productDetailSelected = false;
                                this.returnMessage.messageHeader = MessageItems.productHeader;
                                this.returnMessage.message = MessageItems.inactiveMessage;
                                this.returnMessage.messageIconClass = APP_CONSTANTS.ErrorIcon;
                                this.displayMessage = true;
                                this.loading = false;
                                this.activeConfiguration = [];
                                return;
                            } else {
                                this.SAPRelevancy = '';
                                this.ProductCode = '';
                                this.ProductDesc = '';
                                this.Facility = '';
                                this.productID = '';
                                this.productComments = '';
                                this.addDisabled = true;
                                this.productDetailSelected = false;
                                this.returnMessage.messageHeader = MessageItems.productHeader;
                                this.returnMessage.message = MessageItems.inactiveMessage;
                                this.returnMessage.messageIconClass = APP_CONSTANTS.ErrorIcon;
                                this.displayMessage = true;
                                this.loading = false;
                                this.activeConfiguration = [];
                                return;
                            }
                        });
                    } else {
                        this.SAPRelevancy = '';
                        this.ProductCode = '';
                        this.ProductDesc = '';
                        this.Facility = '';
                        this.addDisabled = true;
                        this.productDetailSelected = false;
                        this.productID = '';
                        this.productComments = '';
                        this.returnMessage.messageHeader = MessageItems.productHeader;
                        this.returnMessage.message = MessageItems.draftMessage;
                        this.returnMessage.messageIconClass = APP_CONSTANTS.ErrorIcon;
                        this.displayMessage = true;
                        this.loading = false;
                        this.displayConfigGrid = false;
                        return;
                    }
                } else {
                    this.SAPRelevancy = '';
                    this.ProductCode = '';
                    this.ProductDesc = '';
                    this.Facility = '';
                    this.productComments = '';
                    this.addDisabled = true;
                    this.productDetailSelected = false;
                    this.productID = '';
                    this.displayConfigGrid = false;
                }
            }, (error: Error) => {
                this.router.navigate([Url.error]);
                this.loading = false;
            }, () => this.loading = false
            );
    }
    EditConfiguration(config) {
        this.valuesMessage = '';
        this.isFacilitiesDeslected = true;
        this.data = '';
        this.selectedFacilities = [];
        this.productConfigId = config.ProdConfigId;
        this.returnMessage = new MessageModel();
        this.isValidate = false;
        this.dynamicConfig = [];
        this.isValidateValue = false;
        this.MaintainProductConfigurationService.getCharacteristicsByConfigID(this.productConfigId).
            subscribe((ViewProductconfiguartion: any) => {
                if (ViewProductconfiguartion && ViewProductconfiguartion.message) {
                    this.returnMessage.messageHeader = 'Configuration Detail';
                    this.returnMessage.message = '';
                    this.returnMessage.message = ViewProductconfiguartion.message;
                    this.returnMessage.messageType = ViewProductconfiguartion.messageType;
                    this.getIconforMessageDisplay();
                    this.displayMessage = true;
                } else {
                    this.popupTitle = 'Edit Configuration';
                    this.displayDialog = true;
                    this.dynamicConfig = ViewProductconfiguartion;
                    if (ViewProductconfiguartion !== undefined) {
                        this.dynamicConfig.forEach(e => {
                            this.configComment = e.configComments;
                        });
                    }
                }
            }
            , (err: any) => {
                this.err = err;
                if (err !== undefined) {
                    this.router.navigate([Url.error]);
                    this.loading = false;
                    return;
                }
            });

        this.MaintainProductConfigurationService.getCharacteristicsByConfigID(this.productConfigId).
            subscribe((maskProductconfiguartion: any) => {
                if (maskProductconfiguartion && maskProductconfiguartion.message) {
                    return;
                } else {
                    this.popupTitle = 'Edit Configuration';
                    this.displayDialog = true;
                    this.formcontrolsCheck = [];
                    this.formcontrolsCheck = maskProductconfiguartion;
                    if (maskProductconfiguartion !== undefined) {
                        this.formcontrolsCheck.forEach(e => {
                            this.configComment = e.configComments;
                        });
                    }
                }
            }
            , (err: any) => {
                this.err = err;
                if (err !== undefined) {
                    this.router.navigate([Url.error]);
                    this.loading = false;
                    return;
                }
            });
        this.MaintainProductConfigurationService.getFacilityByProducID(config.ProductId).
            subscribe((Facilities: any) => {
                this.facilityDropdownItems = [];
                Facilities.forEach(element => {
                    this.facilityDropdownItems.push({ label: element.facilityName, value: element.facilityCode });
                });
            }, (err: any) => {
                this.err = err;
                if (err !== undefined) {
                    this.router.navigate([Url.error]);
                    this.loading = false;
                    return;
                }
            });
        this.facilityDropdownItems.sort(function (a, b) {
            return a.label.localeCompare(b.label);
        });
        this.facilitiesbyConfigId = [];
        if (config.Facility !== null && config.Facility !== undefined) {
            const facilityArray = config.Facility.split(',');
            facilityArray.forEach(element => {
                this.selectedFacilities.push(element.substring(0, 8));
                this.facilitiesbyConfigId.push(element.substring(0, 8));
            });
        }
        if (this.duplicateConfigFacility !== undefined &&
            this.duplicateConfigFacility !== null &&
            this.duplicateConfigFacility.length !== 0) {
            this.duplicateConfigFacility.forEach(element => {
                if (!(this.selectedFacilities.indexOf(element.substring(0, 8)) > -1)) {
                    this.selectedFacilities.push(element.substring(0, 8));
                    this.facilitiesbyConfigId.push(element.substring(0, 8));
                }
            });
        }
        if (config.VCPTConfigurationStatus.toString().toLowerCase() === ConstantValues.productStatusActive.toLowerCase()) {
            this.isDraft = false;
            this.isActive = true;
        }
        if (config.VCPTConfigurationStatus.toString().toLowerCase() !== ConstantValues.productStatusActive.toLowerCase()) {
            this.isDraft = true;
            this.isActive = false;
        }
    }
    AddConfiguration() {
        this.displayDialog = false;
        this.valuesMessage = '';
        this.isFacilitiesDeslected = false;
        this.data = '';
        this.isValidate = false;
        this.isValidateValue = false;
        this.isDraft = true;
        this.isActive = false;
        this.selectedFacilities = [];
        this.formcontrolsCheck = [];
        this.facilitiesbyConfigId = [];
        this.dynamicConfig = [];
        this.productConfigId = 0;
        if (this.productID === undefined) {
            this.productID = 0;
        }
        this.MaintainProductConfigurationService.getFacilityByProducID(this.productID).
            subscribe((Facilities: any) => {
                this.facilityDropdownItems = [];
                Facilities.forEach(element => {
                    this.facilityDropdownItems.push({ label: element.facilityName, value: element.facilityCode });
                });
            }, (err: any) => {
                this.err = err;
                if (err !== undefined) {
                    this.router.navigate([Url.error]);
                    this.loading = false;
                    return;
                }
            });
        this.facilityDropdownItems.sort(function (a, b) {
            return a.label.localeCompare(b.label);
        });
        this.MaintainProductConfigurationService.getCharacteristicsByProductID(this.productID).
            subscribe((ViewProductconfiguartion: any) => {
                this.dynamicConfig = ViewProductconfiguartion;
                if (ViewProductconfiguartion !== undefined && ViewProductconfiguartion.length !== 0) {
                    this.dynamicConfig.forEach(e => {
                        this.configComment = e.configComments;
                    });
                    this.displayDialog = true;
                }
            }, (err: any) => {
                this.err = err;
                if (err !== undefined) {
                    this.router.navigate([Url.error]);
                    this.loading = false;
                    return;
                }
            });

        this.MaintainProductConfigurationService.getCharacteristicsByProductID(this.productID).
            subscribe((CopyProductconfiguartion: any) => {
                this.formcontrolsCheck = CopyProductconfiguartion;
                if (CopyProductconfiguartion !== undefined && CopyProductconfiguartion.length !== 0) {
                    this.formcontrolsCheck.forEach(e => {
                        this.configComment = e.configComments;
                    });
                }
            }, (err: any) => {
                this.err = err;
                if (err !== undefined) {
                    this.router.navigate([Url.error]);
                    this.loading = false;
                    return;
                }
            });
        this.popupTitle = 'Add Configuration';
    }

    btnClick() {
        if (this.legacyID && this.legacyID.length > 0) {
            this._router.navigateByUrl(RouteURLs.ViewProductConfigurationsPath + ';id=' + this.legacyID);
        } else {
            this.returnMessage = new MessageModel();
            this.returnMessage.message = MessageItems.emptyLegacyIdMessage;
            this.returnMessage.messageHeader = 'View Product Configuration';
            this.returnMessage.messageIconClass = APP_CONSTANTS.ErrorIcon;
            this.displayMessage = true;
        }
    }
    unlockProductConfiguration(synchronousCall = false) {
        this.sendUnlockRequest(synchronousCall);
    }
    cancel() {
        if (this.checkDirtyForm()) {
            this.confirmationService.confirm({
                message: APP_CONSTANTS.UnsavedChangesMessage,
                icon: APP_CONSTANTS.WarningIcon,
                header: 'Confirmation',
                accept: () => {
                    this.duplicateConfigFacility = [];
                    this.unlockProductConfiguration();
                    this.displayDialog = false;
                },
                reject: () => {
                    this.displayDialog = true; this.Submit = true;
                }
            });
        } else {
            this.displayDialog = false;
            this.duplicateConfigFacility = [];
            this.unlockProductConfiguration();
        }
        this.loading = false;
    }
    saveandActivate() {
        this.loading = true;
        this.data = '';
        this.Submit = false;
        const configDetails = new MaintainProductConfigurations();
        configDetails.productConfiguration = [];
        configDetails.configurationFacility = [];
        let iCount = 0;
        let minMaxCount = 0;
        let minMaxUomCount = 0;
        let valueUom = 0;
        let maxCount = 0;
        let minCount = 0;
        let minMaxequal = 0;
        let minZero = 0;
        let maxZero = 0;
        this.dynamicConfig.forEach(element => {
            configDetails.productId = this.productID;
            configDetails.productConfigurationStatus = ConstantValues.productStatusActiveCode;
            configDetails.configurationComments = this.configComment;
            configDetails.productConfiguration.push({
                'CharacteristicId': element.characteristicId, 'DataType': element.dataType,
                'UomId': element.selectedUOM, 'Range': element.configurationRange, 'Value': element.value,
                'MinValue': element.minValue, 'MaxValue': element.maxValue
            });
            if (element.minValue !== null && element.maxValue !== null && element.selectedUOM !== 0
                && element.maxValue !== '' && element.minValue !== '') {
                minMaxCount = 1;

            }
            if (parseFloat(element.minValue) === 0) {

                minZero = 1;
            }
            if (parseFloat(element.maxValue) === 0) {

                maxZero = 1;
            }
            if (element.minValue !== null && element.selectedUOM !== 0
                && element.minValue !== '' && element.configurationRange === false) {
                minMaxCount = 1;

            }
            if (element.minValue !== null && element.minValue !== null && element.selectedUOM === 0
                && element.maxValue !== '' && element.minValue !== '' && element.configurationRange === true) {
                minMaxUomCount = 1;
            }
            if (element.minValue !== null && element.minValue !== '' && element.selectedUOM === 0
                && element.configurationRange === false) {
                minMaxUomCount = 1;
            }
            if (element.minValue !== null && element.minValue !== '' && element.configurationRange === true) {
                if (element.maxValue === null || element.maxValue === '') {
                    maxCount = 1;
                }
            }
            if (element.maxValue !== null && element.maxValue !== '' && element.configurationRange === true) {
                if (element.minValue === null || element.minValue === '') {
                    minCount = 1;
                }
            }
            if (element.value !== null && element.selectedUOM !== 0 && element.value !== '') {
                iCount = 1;
            }
            if (element.value !== null && element.selectedUOM === 0 && element.value !== '') {
                valueUom = 1;
            }
            if (parseFloat(element.minValue) === parseFloat(element.maxValue) &&
                element.configurationRange === true && element.minValue !== null &&
                element.minValue !== undefined && element.minValue !== '' && element.maxValue !== null &&
                element.maxValue !== undefined && element.maxValue !== '' && parseFloat(element.minValue) !== 0
                && parseFloat(element.maxValue) !== 0) {
                minMaxequal = 1;
            }
        });

        if (this.facilitiesbyConfigId !== undefined && this.facilitiesbyConfigId !== undefined) {
            for (const i in this.facilitiesbyConfigId) {
                let facilityCode = this.facilitiesbyConfigId[i].element
                if (facilityCode === undefined) {
                    facilityCode = this.facilitiesbyConfigId[i]
                }
                configDetails.configurationFacility.push({
                    'FacilityCode': facilityCode,
                    'StatusCode': ConstantValues.productStatusActiveCode
                });
            }
        }
        if (iCount === 0 && minMaxCount === 0 && valueUom === 0 && minMaxUomCount === 0) {
            // tslint:disable-next-line:max-line-length
            this.data = MessageItems.characteristicMessage;
            this.isValidate = true;
            this.loading = false;
            return false;
        } else {
            this.isValidate = false;
        }
        if (minZero !== 0) {

            this.data = '';
            this.data = MessageItems.minValueZeroMessage;
            this.isValidate = true;
            this.loading = false;
            return false;
        }
        if (maxZero !== 0) {

            this.data = '';
            this.data = MessageItems.maxValueZeroMessage;
            this.isValidate = true;
            this.loading = false;
            return false;
        }
        if (valueUom !== 0 || minMaxUomCount !== 0) {
            // tslint:disable-next-line:max-line-length
            this.data = '';
            this.data = MessageItems.emptyUOMMessage;
            this.isValidate = true;
            this.loading = false;
            return false;
        } else {
            this.isValidate = false;
        }
        if (minMaxequal === 1) {
            this.isValidateValue = false;
            this.valuesMessage = '';
            this.data = '';
            this.data = MessageItems.equalsMessage;
            this.isValidate = true;
            this.loading = false;
            return false;
        }
        configDetails.productConfigId = this.productConfigId;
        if (this.isValidateValue) {
            this.loading = false;
            return false;
        }
        if (minCount !== 0) {
            this.valuesMessage = MessageItems.emptyMinValueMessage;
            this.isValidateValue = true;
            this.loading = false;
            return false;
        } else {
            this.isValidateValue = false;
        }
        if (maxCount !== 0) {
            this.valuesMessage = MessageItems.emptyMaxValueMessage;
            this.isValidateValue = true;
            this.loading = false;
            return false;
        } else {
            this.isValidateValue = false;
        }
        if (configDetails.configurationFacility.length === 0) {
            this.data = MessageItems.facilityMessage;
            this.isValidate = true;
            this.loading = false;
            return false;

        } else {
            this.isValidate = false;
        }
        this.MaintainProductConfigurationService.saveConfiguration(configDetails).subscribe((data: any) => {
            this.data = data;
            if (this.data.message === StatusCode.successCode) {
                this.displayDialog = false;
                this.returnMessage.messageHeader = MessageItems.saveandactivate;
                this.returnMessage.message = MessageItems.saveandActivateMessage;
                this.returnMessage.messageIconClass = APP_CONSTANTS.InformationIcon;
                this.displayMessage = true;
                this.loading = false;
                this.statusCode = StatusCode.successCode;
                this.Submit = true;
                this.getDetails();
                this.loading = false;
                return;

            } else if (this.data.message === StatusCode.duplicateCode) {
                this.duplicateCharacteristicsMappingforOtherFacilities(this.data.messageCode);
            } else if (this.data.message === StatusCode.mismatchCode) {
                this.returnMessage.messageHeader = MessageItems.erroHeader;
                this.returnMessage.message = MessageItems.characteristicMismatchMessage;
                this.returnMessage.messageIconClass = APP_CONSTANTS.ErrorIcon;
                this.displayMessage = true;
                this.displayDialog = false;
                this.getDetails();
                this.loading = false;
                return;
            }
        },
            (err) => {
                if (err !== undefined) {
                    this.router.navigate([Url.error]);
                    this.Submit = true;
                }
            }, () => this.loading = false
        );
        const prod = new ViewProductMaster();
        prod.productLegacyID = this.legacyID;
        prod.facilityCode = '';
        prod.productStatus.statusCode = 0;
        prod.productBusinessLifeCycleStatus.statusCode = '';
        prod.productDescription = '';
        prod.productCode = '';
        this.selectedFacilityValues = '';
        this.getProductDetails(prod);
        this.loading = false;
    }
    getDetails() {
        if (this.statusCode === StatusCode.successCode || this.data.message === StatusCode.mismatchCode) {
            this.message = false;
            const prod = new ViewProductMaster();
            prod.productLegacyID = this.legacyID;
            prod.facilityCode = '';
            prod.productStatus.statusCode = 0;
            prod.productBusinessLifeCycleStatus.statusCode = '';
            prod.productDescription = '';
            prod.productCode = '';
            this.selectedFacilityValues = '';
            this.getProductDetails(prod);
            this.loading = false;
        } else {
            this.message = false;
            this.loading = false;
        }
    }
    saveasDraft() {
        this.loading = true;
        this.data = '';
        this.Submit = false;
        const configDetails = new MaintainProductConfigurations();
        configDetails.productConfiguration = [];
        configDetails.configurationFacility = [];
        let iCount = 0;
        let minMaxCount = 0;
        let minMaxUomCount = 0;
        let valueUom = 0;
        let maxCount = 0;
        let minCount = 0;
        let minMaxequal = 0;
        let minZero = 0;
        let maxZero = 0;
        this.dynamicConfig.forEach(element => {
            configDetails.productId = this.productID;
            configDetails.productConfigurationStatus = ConstantValues.productStatusDraftCode;
            configDetails.configurationComments = this.configComment;
            configDetails.productConfiguration.push({
                'CharacteristicId': element.characteristicId, 'DataType': element.dataType,
                'UomId': element.selectedUOM, 'Range': element.configurationRange, 'Value': element.value,
                'MinValue': element.minValue, 'MaxValue': element.maxValue
            });
            if (element.minValue !== null && element.maxValue !== null && element.selectedUOM !== 0
                && element.maxValue !== '' && element.minValue !== '' && element.configurationRange === true) {
                minMaxCount = 1;

            }
            if (parseFloat(element.minValue) === 0) {

                minZero = 1;
            }
            if (parseFloat(element.maxValue) === 0) {

                maxZero = 1;
            }
            if (element.minValue !== null && element.selectedUOM !== 0
                && element.minValue !== '' && element.configurationRange === false) {
                minMaxCount = 1;

            }
            if (element.minValue !== null && element.maxValue !== null && element.selectedUOM === 0
                && element.maxValue !== '' && element.minValue !== '' && element.configurationRange === true) {
                minMaxUomCount = 1;
            }
            if (element.minValue !== null && element.minValue !== '' && element.selectedUOM === 0
                && element.configurationRange === false) {
                minMaxUomCount = 1;
            }
            if (element.minValue !== null && element.minValue !== '' && element.configurationRange === true) {
                if (element.maxValue === null || element.maxValue === '') {
                    maxCount = 1;
                }
            }
            if (element.maxValue !== null && element.maxValue !== '' && element.configurationRange === true) {
                if (element.minValue === null || element.minValue === '') {
                    minCount = 1;
                }
            }
            if (element.value !== null && element.selectedUOM !== 0 && element.value !== '') {
                iCount = 1;
            }
            if (element.value !== null && element.selectedUOM === 0 && element.value !== '') {
                valueUom = 1;
            }
            if (parseFloat(element.minValue) === parseFloat(element.maxValue) &&
                element.configurationRange === true && element.minValue !== null &&
                element.minValue !== undefined && element.minValue !== '' && element.maxValue !== null &&
                element.maxValue !== undefined && element.maxValue !== '' && parseFloat(element.minValue) !== 0
                && parseFloat(element.maxValue) !== 0) {
                minMaxequal = 1;
            }
        });
        if (this.facilitiesbyConfigId !== undefined && this.facilitiesbyConfigId !== undefined) {
            for (const i in this.facilitiesbyConfigId) {
                let facilityCode = this.facilitiesbyConfigId[i].element
                if (facilityCode === undefined) {
                    facilityCode = this.facilitiesbyConfigId[i]
                }
                configDetails.configurationFacility.push({
                    'FacilityCode': facilityCode,
                    'StatusCode': ConstantValues.productStatusActiveCode
                });
            }
        }

        if ((iCount === 0 && minMaxCount === 0) && (valueUom === 0 && minMaxUomCount === 0)) {
            // tslint:disable-next-line:max-line-length
            this.data = MessageItems.characteristicMessage;
            this.isValidate = true;
            this.loading = false;
            return false;
        } else {
            this.isValidate = false;
        }
        if (minZero !== 0) {

            this.data = '';
            this.data = MessageItems.minValueZeroMessage;
            this.isValidate = true;
            this.loading = false;
            return false;
        }
        if (maxZero !== 0) {

            this.data = '';
            this.data = MessageItems.maxValueZeroMessage;
            this.isValidate = true;
            this.loading = false;
            return false;
        }
        if (valueUom !== 0 || minMaxUomCount !== 0) {
            // tslint:disable-next-line:max-line-length
            this.data = '';
            this.data = MessageItems.emptyUOMMessage;
            this.isValidate = true;
            this.loading = false;
            return false;
        } else {
            this.isValidate = false;
        }
        if (minMaxequal === 1) {
            this.isValidateValue = false;
            this.valuesMessage = '';
            this.data = '';
            this.data = MessageItems.equalsMessage;
            this.isValidate = true;
            this.loading = false;
            return false;
        }
        if (configDetails.configurationFacility.length === 0) {
            this.data = MessageItems.facilityMessage;
            this.isValidate = true;
            this.loading = false;
            return false;

        } else {
            this.isValidate = false;
        }
        configDetails.productConfigId = this.productConfigId;
        if (this.isValidateValue) {
            this.loading = false;
            return false;
        }
        if (minCount !== 0) {
            this.valuesMessage = MessageItems.emptyMinValueMessage;
            this.isValidateValue = true;
            this.loading = false;
            return false;
        } else {
            this.isValidateValue = false;
        }
        if (maxCount !== 0) {
            this.valuesMessage = MessageItems.emptyMaxValueMessage;
            this.isValidateValue = true;
            this.loading = false;
            return false;
        } else {
            this.isValidateValue = false;
        }

        this.MaintainProductConfigurationService.saveConfiguration(configDetails).subscribe((data: any) => {
            this.data = data;
            if (this.
                data.message === StatusCode.successCode) {
                this.displayDialog = false;
                this.returnMessage.messageHeader = MessageItems.saveDraftHeader;
                this.returnMessage.message = MessageItems.saveMessage;
                this.returnMessage.messageIconClass = APP_CONSTANTS.InformationIcon;
                this.displayMessage = true;
                this.loading = false;
                this.statusCode = StatusCode.successCode;
                this.Submit = true;
                this.getDetails();
                this.loading = false;
                return;

            } else if (this.data.message === StatusCode.duplicateCode) {
                this.duplicateCharacteristicsMappingforOtherFacilities(this.data.messageCode);
            } else if (this.data.message === StatusCode.mismatchCode) {
                this.returnMessage.messageHeader = MessageItems.erroHeader;
                this.returnMessage.message = MessageItems.characteristicMismatchMessage;
                this.displayMessage = true;
                this.returnMessage.messageIconClass = APP_CONSTANTS.ErrorIcon;
                this.displayDialog = false;
                this.getDetails();
                this.loading = false;
                return;
            }
        },
            (err) => {
                if (err !== undefined) {
                    this.router.navigate([Url.error]);
                    return;
                }
            }, () => this.loading = false
        );
        this.loading = false;
    }
    duplicateCharacteristicsMappingforOtherFacilities(configId) {
        this.confirmationService.confirm({
            message: MessageItems.duplicateConfigurationMessage,
            icon: APP_CONSTANTS.WarningIcon,
            header: 'Confirmation',
            accept: () => {
                const config: any = {};
                config.ProdConfigId = configId;
                this.MaintainProductConfigurationService.DuplicateProdConfigDetail(config.ProdConfigId).
                    subscribe((details: any) => {
                        config.ProductId = details.productId;
                        config.VCPTConfigurationStatus = details.vcptProductConfigStatus.statusDesc;
                        config.Facility = '';
                        details.configurationFacility.forEach(element => {
                            config.Facility += element.facilityCode + ',';
                        });
                        config.Facility = config.Facility.substring(0, config.Facility.length - 1);
                        this.duplicateConfigFacility = [];
                        this.duplicateConfigFacility = this.selectedFacilities;
                        this.EditConfiguration(config);
                    });
            },
            reject: () => {
            }
        });
        return;
    }
    save() {
        this.loading = true;
        this.data = '';
        this.Submit = false;
        const configDetails = new MaintainProductConfigurations();
        configDetails.productConfiguration = [];
        configDetails.configurationFacility = [];
        let iCount = 0;
        let minMaxCount = 0;
        let minMaxUomCount = 0;
        let valueUom = 0;
        let maxCount = 0;
        let minCount = 0;
        let minMaxequal = 0;
        let minZero = 0;
        let maxZero = 0;
        this.dynamicConfig.forEach(element => {
            configDetails.productId = this.productID;
            configDetails.productConfigurationStatus = ConstantValues.productStatusActiveCode;
            configDetails.configurationComments = this.configComment;
            configDetails.productConfiguration.push({
                'CharacteristicId': element.characteristicId, 'DataType': element.dataType,
                'UomId': element.selectedUOM, 'Range': element.configurationRange, 'Value': element.value,
                'MinValue': element.minValue, 'MaxValue': element.maxValue
            });
            if (element.minValue !== null && element.maxValue !== null && element.selectedUOM !== 0
                && element.maxValue !== '' && element.minValue !== '') {
                minMaxCount = 1;

            }
            if (parseFloat(element.minValue) === 0) {

                minZero = 1;
            }
            if (parseFloat(element.maxValue) === 0) {

                maxZero = 1;
            }
            if (element.minValue !== null && element.selectedUOM !== 0
                && element.minValue !== '' && element.configurationRange === false) {
                minMaxCount = 1;

            }
            if (element.minValue !== null && element.maxValue !== null && element.selectedUOM === 0
                && element.maxValue !== '' && element.minValue !== '' && element.configurationRange === true) {
                minMaxUomCount = 1;
            }
            if (element.minValue !== null && element.minValue !== '' && element.selectedUOM === 0
                && element.configurationRange === false) {
                minMaxUomCount = 1;
            }
            if (element.minValue !== null && element.minValue !== '' && element.configurationRange === true) {
                if (element.maxValue === null || element.maxValue === '') {
                    maxCount = 1;
                }
            }
            if (element.maxValue !== null && element.maxValue !== '' && element.configurationRange === true) {
                if (element.minValue === null || element.minValue === '') {
                    minCount = 1;
                }
            }
            if (element.value !== null && element.selectedUOM !== 0 && element.value !== '') {
                iCount = 1;
            }
            if (element.value !== null && element.selectedUOM === 0 && element.value !== '') {
                valueUom = 1;
            }
            if (parseFloat(element.minValue) === parseFloat(element.maxValue) &&
                element.configurationRange === true && element.minValue !== null &&
                element.minValue !== undefined && element.minValue !== '' && element.maxValue !== null &&
                element.maxValue !== undefined && element.maxValue !== '' && parseFloat(element.minValue) !== 0
                && parseFloat(element.maxValue) !== 0) {
                minMaxequal = 1;
            }
        });
        if (this.facilitiesbyConfigId !== undefined && this.facilitiesbyConfigId !== undefined) {
            for (const i in this.facilitiesbyConfigId) {
                let facilityCode = this.facilitiesbyConfigId[i].element
                if (facilityCode === undefined) {
                    facilityCode = this.facilitiesbyConfigId[i]
                }
                configDetails.configurationFacility.push({
                    'FacilityCode': facilityCode,
                    'StatusCode': ConstantValues.productStatusActiveCode
                });
            }
        }
        if (iCount === 0 && minMaxCount === 0 && valueUom === 0 && minMaxUomCount === 0) {
            // tslint:disable-next-line:max-line-length
            this.data = MessageItems.characteristicMessage;
            this.isValidate = true;
            this.loading = false;
            return false;
        } else {
            this.isValidate = false;
        }
        if (valueUom !== 0 || minMaxUomCount !== 0) {
            // tslint:disable-next-line:max-line-length
            this.data = '';
            this.data = MessageItems.emptyUOMMessage;
            this.isValidate = true;
            this.loading = false;
            return false;
        } else {
            this.isValidate = false;
        }
        if (minZero !== 0) {

            this.data = '';
            this.data = MessageItems.minValueZeroMessage;
            this.isValidate = true;
            this.loading = false;
            return false;
        }
        if (maxZero !== 0) {

            this.data = '';
            this.data = MessageItems.maxValueZeroMessage;
            this.isValidate = true;
            this.loading = false;
            return false;
        }
        configDetails.productConfigId = this.productConfigId;
        if (this.isValidateValue) {
            return false;
        }
        if (minCount !== 0) {
            this.valuesMessage = MessageItems.emptyMinValueMessage;
            this.isValidateValue = true;
            this.loading = false;
            return false;
        } else {
            this.isValidateValue = false;
        }
        if (minMaxequal === 1) {
            this.isValidateValue = false;
            this.valuesMessage = '';
            this.data = '';
            this.data = MessageItems.equalsMessage;
            this.isValidate = true;
            this.loading = false;
            return false;
        }
        if (maxCount !== 0) {
            this.valuesMessage = MessageItems.emptyMaxValueMessage;
            this.isValidateValue = true;
            this.loading = false;
            return false;
        } else {
            this.isValidateValue = false;
        }
        if (configDetails.configurationFacility.length === 0) {
            this.loading = false;
            this.confirmationService.confirm({
                message: MessageItems.inactivateMessage,
                icon: APP_CONSTANTS.WarningIcon,
                header: 'Confirmation',
                accept: () => {
                    this.loading = true;
                    configDetails.productConfigurationStatus = ConstantValues.productStatusInActiveCode;
                    this.MaintainProductConfigurationService.saveConfiguration(configDetails).subscribe((data: any) => {
                        this.data = data;
                        if (this.data.message === StatusCode.successCode) {
                            this.displayDialog = false;
                            this.returnMessage.messageHeader = MessageItems.saveHeader;
                            this.returnMessage.message = MessageItems.saveMessage;
                            this.returnMessage.messageIconClass = APP_CONSTANTS.InformationIcon;
                            this.displayMessage = true;
                            this.loading = false;
                            this.statusCode = '200';
                            this.Submit = true;
                            if (this.checkCharacteristicChange()) {
                                this.returnMessage.message += '\n';
                                this.returnMessage.message += MessageItems.characteristicsChangeMessage;
                                this.isValidate = true;
                            }
                            this.getDetails();
                            this.loading = false;
                            return;

                        } else if (this.data.message === StatusCode.duplicateCode) {
                            this.duplicateCharacteristicsMappingforOtherFacilities(this.data.messageCode);
                        } else if (this.data.message === StatusCode.mismatchCode) {
                            this.returnMessage.messageHeader = MessageItems.erroHeader;
                            this.returnMessage.messageIconClass = APP_CONSTANTS.ErrorIcon;
                            this.returnMessage.message = MessageItems.characteristicMismatchMessage;
                            this.displayMessage = true;
                            this.displayDialog = false;
                            this.getDetails();
                            this.loading = false;
                            return;
                        }
                    },
                        (err) => {
                            if (err !== undefined) {
                                this.router.navigate([Url.error]);
                                this.loading = false;
                                return;
                            }
                        }, () => this.loading = false
                    );
                },
                reject: () => {
                    this.loading = false;
                }
            });
        } else {
            this.MaintainProductConfigurationService.saveConfiguration(configDetails).subscribe(data => {
                this.data = data;
                if (this.
                    data.message === StatusCode.successCode) {
                    this.displayDialog = false;
                    this.returnMessage.messageHeader = MessageItems.saveHeader;
                    this.returnMessage.message = MessageItems.saveMessage;
                    this.returnMessage.messageIconClass = APP_CONSTANTS.InformationIcon;
                    this.displayMessage = true;
                    this.loading = false;
                    this.statusCode = StatusCode.successCode;
                    this.Submit = true;
                    if (this.checkCharacteristicChange()) {
                        this.returnMessage.message += '\n';
                        this.returnMessage.message += MessageItems.characteristicsChangeMessage;
                        this.isValidate = true;
                    }
                    this.getDetails();
                    this.loading = false;
                    return;

                } else if (this.data.message === StatusCode.duplicateCode) {
                    this.duplicateCharacteristicsMappingforOtherFacilities(this.data.messageCode);
                } else if (this.data.message === StatusCode.mismatchCode) {
                    this.returnMessage.messageHeader = MessageItems.erroHeader;
                    this.returnMessage.messageIconClass = APP_CONSTANTS.ErrorIcon;
                    this.returnMessage.message = MessageItems.characteristicMismatchMessage;
                    this.displayMessage = true;
                    this.displayDialog = false;
                    this.getDetails();
                    this.loading = false;
                    return;
                }
            },
                (err) => {
                    if (err !== undefined) {
                        this.router.navigate([Url.error]);
                        this.loading = false;
                        return;
                    }
                }, () => this.loading = false
            );
        }
    }
    facilityCheckBoxClick(e) {
        this.facilitiesbyConfigId = [];

        e.value.forEach(element => {
            this.facilitiesbyConfigId.push({
                element
            });
        });
    }

    @HostListener('window:beforeunload', ['$event'])
    unloadNotification($event: any) {
        if (this.displayDialog && this.checkDirtyForm() && !this.Submit) {
            $event.returnValue = APP_CONSTANTS.UnsavedChangesMessage;
        }
        this.loading = false;
    }

    @HostListener('window:unload', ['$event'])
    unloadPage(event: any) {
        this.unlockProductConfiguration(true);
        this.displayDialog = false;
        this.SAPRelevancy = '';
        this.ProductCode = '';
        this.ProductDesc = '';
        this.Facility = '';
        this.legacyID = '';
    }

    checkDirtyForm(): boolean {
        if (this.selectedFacilities !== undefined && this.facilitiesbyConfigId !== undefined) {
            if (this.selectedFacilities.length !== this.facilitiesbyConfigId.length) {
                return true;
            }
        }
        if (this.isFacilitiesDeslected && this.selectedFacilities.length === 0) {
            return true;
        }
        for (let e in this.dynamicConfig) {

            for (let j in this.formcontrolsCheck) {

                if (e === j) {
                    if (this.dynamicConfig[e].value === this.formcontrolsCheck[j].value) {
                    }
                    else {
                        return true;
                    }
                    if (this.dynamicConfig[e].minValue === this.formcontrolsCheck[j].minValue) {
                    }
                    else {
                        return true;
                    }
                    if (this.dynamicConfig[e].maxValue === this.formcontrolsCheck[j].maxValue) {
                    }
                    else {
                        return true;
                    }
                    if (this.dynamicConfig[e].configurationRange === this.formcontrolsCheck[j].configurationRange) {
                    }
                    else {
                        return true;
                    }
                    if (this.dynamicConfig[e].configComments === this.configComment) {
                    }
                    else {
                        return true;
                    }
                    if (this.formcontrolsCheck[j].value !== undefined) {
                        if (this.dynamicConfig[e].selectedUOM === this.formcontrolsCheck[j].selectedUOM) {
                        }
                        else {
                            return true;
                        }
                    }
                }
            }
        }
        for (let f in this.selectedFacilities) {
            for (let j in this.facilitiesbyConfigId) {
                if (f === j) {
                    if (this.selectedFacilities[f] === this.facilitiesbyConfigId[j]) {
                    }
                    else {
                        return true;
                    }
                }
            }
        }
    }
    checkCharacteristicChange(): boolean {
        for (let e in this.dynamicConfig) {
            for (let j in this.formcontrolsCheck) {
                if (e === j) {
                    if (this.formcontrolsCheck[j].value !== undefined && this.formcontrolsCheck[j].value !== null) {
                        if (this.dynamicConfig[e].value === this.formcontrolsCheck[j].value) {
                        }
                        else {
                            return true;
                        }
                    }
                    if (this.formcontrolsCheck[j].value !== undefined && this.formcontrolsCheck[j].value !== null) {
                        if (this.dynamicConfig[e].selectedUOM === this.formcontrolsCheck[j].selectedUOM) {
                        }
                        else {
                            return true;
                        }
                    }
                    if (this.formcontrolsCheck[j].minValue !== undefined && this.formcontrolsCheck[j].minValue !== null) {
                        if (this.dynamicConfig[e].minValue === this.formcontrolsCheck[j].minValue) {
                        }
                        else {
                            return true;
                        }
                    }
                    if (this.formcontrolsCheck[j].maxValue !== undefined && this.formcontrolsCheck[j].maxValue !== null) {
                        if (this.dynamicConfig[e].maxValue === this.formcontrolsCheck[j].maxValue) {
                        }
                        else {
                            return true;
                        }
                    }
                    if (this.formcontrolsCheck[j].maxValue !== undefined && this.formcontrolsCheck[j].maxValue !== null && this.formcontrolsCheck[j].maxValue !== undefined && this.formcontrolsCheck[j].maxValue !== null) {
                        if (this.dynamicConfig[e].selectedUOM === this.formcontrolsCheck[j].selectedUOM) {
                        }
                        else {
                            return true;
                        }
                    }
                    if (this.formcontrolsCheck[j].maxValue !== undefined && this.formcontrolsCheck[j].maxValue !== null && this.formcontrolsCheck[j].maxValue !== undefined && this.formcontrolsCheck[j].maxValue !== null) {
                        if (this.dynamicConfig[e].configurationRange === this.formcontrolsCheck[j].configurationRange) {
                        }
                        else {
                            return true;
                        }
                    }
                }
            }
        }
    }
    onGridPageChange(event: any) {
        this.firstRecordIndexofGrid = event.first === 1 ? event.first : event.first + 1;
        this.recordsPerPage = event.first !== 1 ? event.rows + event.first : event.rows;
    }
    sendUnlockRequest(synchronousCall: boolean) {
        this.loading = true;
        if (!synchronousCall) {
            this.MaintainProductConfigurationService.unlockProductConfiguration(this.productConfigId).
                subscribe((data: any) => {
                }, (err: any) => {
                    this.err = err;
                    this.router.navigate([Url.error]);
                }, () => this.loading = false);
        } else {
            this.MaintainProductConfigurationService.unlockProductConfigurationSynchronous(this.productConfigId);
            this.loading = false;
        }
    }
    enableTextBox(event, i) {
        if (event.target.checked) {
            this.dynamicConfig[i].configurationRange = ConstantValues.isRangeTrue;
            this.dynamicConfig[i].range = ConstantValues.isRangeTrue;
        } else {
            this.dynamicConfig[i].configurationRange = ConstantValues.isRangeFalse;
            this.dynamicConfig[i].range = ConstantValues.isRangeTrue;
            this.dynamicConfig[i].maxValue = this.dynamicConfig[i].minValue;
            this.isValidateValue = false;
            this.valuesMessage = '';
        }
    }

    MaxValueChange(event, i) {

        if (this.dynamicConfig[i].range === true && this.dynamicConfig[i].configurationRange === true) {
            if (this.dynamicConfig[i].minValue !== null && parseFloat(this.dynamicConfig[i].minValue) !== 0) {
                if (parseFloat(this.dynamicConfig[i].maxValue) < parseFloat(this.dynamicConfig[i].minValue)) {
                    this.isValidateValue = true;
                    this.valuesMessage = MessageItems.maxMessage;
                } else if (parseFloat(this.dynamicConfig[i].maxValue) === parseFloat(this.dynamicConfig[i].minValue)
                    && parseFloat(this.dynamicConfig[i].maxValue) !== 0 && parseFloat(this.dynamicConfig[i].minValue) !== 0) {
                    this.isValidateValue = true;
                    this.valuesMessage = MessageItems.equalsMessage;
                } else {
                    this.isValidateValue = false;
                    this.valuesMessage = '';
                }
            }
        } else if (this.dynamicConfig[i].range === true && this.dynamicConfig[i].configurationRange === false) {
            this.dynamicConfig[i].maxValue = this.dynamicConfig[i].minValue;
        } else {
            this.isValidateValue = false;
            this.valuesMessage = '';
        }
    }
    MinValueChange(event, i) {
        if (this.dynamicConfig[i].range === true && this.dynamicConfig[i].configurationRange === true) {
            if (this.dynamicConfig[i].maxValue !== null && parseFloat(this.dynamicConfig[i].minValue) !== 0) {
                if (parseFloat(this.dynamicConfig[i].minValue) > parseFloat(this.dynamicConfig[i].maxValue)) {
                    this.isValidateValue = true;
                    this.valuesMessage = MessageItems.minMessage;
                } else if (parseFloat(this.dynamicConfig[i].minValue) === parseFloat(this.dynamicConfig[i].maxValue)
                    && parseFloat(this.dynamicConfig[i].maxValue) !== 0 && parseFloat(this.dynamicConfig[i].minValue) !== 0) {
                    this.isValidateValue = true;
                    this.valuesMessage = MessageItems.equalsMessage;
                } else {
                    this.isValidateValue = false;
                    this.valuesMessage = '';
                }
            }
        } else if (this.dynamicConfig[i].range === true && this.dynamicConfig[i].configurationRange === false) {
            this.dynamicConfig[i].maxValue = this.dynamicConfig[i].minValue;
        } else {
            this.isValidateValue = false;
            this.valuesMessage = '';
        }
    }
    getIconforMessageDisplay() {
        if (this.returnMessage.messageType) {
            switch (this.returnMessage.messageType.trim().toUpperCase()) {
                case 'Error'.toUpperCase(): this.returnMessage.messageIconClass = APP_CONSTANTS.ErrorIcon; break;
                case 'Information'.toUpperCase(): this.returnMessage.messageIconClass = APP_CONSTANTS.InformationIcon; break;
                case 'Warning'.toUpperCase(): this.returnMessage.messageIconClass = APP_CONSTANTS.WarningIcon; break;
                default: this.returnMessage.messageIconClass = APP_CONSTANTS.InformationIcon; break;
            }
        } else {
            this.returnMessage.messageIconClass = APP_CONSTANTS.InformationIcon;
        }
    }
}
