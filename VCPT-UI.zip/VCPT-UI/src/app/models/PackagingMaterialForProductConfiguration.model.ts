import { ProductConfigurationPackagingMaterialMapping } from './ProductConfigurationPackagingMaterialMapping.model';
import { PackagingMaterial } from './PackagingMaterial.model';
import { MaintainProductConfigurations } from './MaintainProductConfigurations.model';
import { ProductDetails } from './MaintainProduct.model';

export class PackagingMaterialsForProductConfiguration {
    productDetails: ProductDetails;
    configurationDetails: MaintainProductConfigurations[];
    productPackagingMaterialsMapping: any[];
    packagingDetails: PackagingMaterial[];
    facilityName: string;
    /**
     * Constructor for PackagingMaterialsForProductConfiguration
     */
    constructor() {
        this.productDetails = new ProductDetails();
        this.configurationDetails = [];
        this.productPackagingMaterialsMapping = [];
        this.packagingDetails = [];
        this.facilityName = '';
    }
}
