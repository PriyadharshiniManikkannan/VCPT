import { TestBed, inject } from '@angular/core/testing';
import { HttpModule } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Rx';

import { AddObsoletePackagingMaterialComponent } from './AddObsoletePackagingMaterial.component';
import { AddObsoletePackagingMaterialService } from './shared/AddObsoletePackagingMaterial.service';
import { AddObsoletePackagingMaterial } from './shared/AddObsoletePackagingMaterial.model';

describe('a AddObsoletePackagingMaterial component', () => {
	let component: AddObsoletePackagingMaterialComponent;

	// register all needed dependencies
	beforeEach(() => {
		TestBed.configureTestingModule({
			imports: [HttpModule],
			providers: [
				{ provide: AddObsoletePackagingMaterialService, useClass: MockAddObsoletePackagingMaterialService },
				AddObsoletePackagingMaterialComponent
			]
		});
	});

	// instantiation through framework injection
	beforeEach(inject([AddObsoletePackagingMaterialComponent], (AddObsoletePackagingMaterialComponent) => {
		component = AddObsoletePackagingMaterialComponent;
	}));

	it('should have an instance', () => {
		expect(component).toBeDefined();
	});
});

// Mock of the original AddObsoletePackagingMaterial service
class MockAddObsoletePackagingMaterialService extends AddObsoletePackagingMaterialService {
	getList(): Observable<any> {
		return Observable.from([ { id: 1, name: 'One'}, { id: 2, name: 'Two'} ]);
	}
}
