import {Facility} from './ViewProductMaster.model';
export class Report {
    packagingMaterialLegacyID: string;
    productLegacyId: string;
    Facilities: Facility[];
 public constructor() {
        this.packagingMaterialLegacyID = '';
        this.productLegacyId = '';
        this.Facilities = [] ;
    }
}
