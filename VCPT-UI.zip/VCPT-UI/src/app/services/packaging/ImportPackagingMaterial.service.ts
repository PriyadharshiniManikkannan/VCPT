import { PackagingMaterial } from './../../models/PackagingMaterial.model';
import { Url } from './../../shared/constants/app.constants';
import { HttpService } from './../base/http.service';
import { Observable } from 'rxjs/Observable';
import {  Http, Response, RequestOptions, Headers  } from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';


@Injectable()
export class ImportPackagingMaterialService {
    constructor(private _httpService: HttpService) { }
    getPackagingDetails(jsonParam: any) {
        return this._httpService.get(Url.PackagingMaterialDetailsUrl, jsonParam);
    }
     importPackagingDetails (packagingDetails: PackagingMaterial) {
        return this._httpService.post(Url.ImportPackagingMaterialUrl, packagingDetails);
    }
}
