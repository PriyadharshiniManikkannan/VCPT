import { Report } from './../../models/Report.model';
import { Url } from './../../shared/constants/app.constants';
import { HttpService } from './../base/http.service';
import { Observable } from 'rxjs/Observable';
import {  Http, Response, RequestOptions, Headers  } from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';


@Injectable()
export class PackagingMaterialWhereUsedService {
    constructor(private httpService: HttpService) { }
    getPackageDetailsByLegacyID(legacyId: string) {
    let jsonParam: any;
    jsonParam = {
      'packagingMaterialLegacyId': legacyId
    };
    return this.httpService.get(Url.ProductAndProductConfigCountForPackagingMaterialUrl , jsonParam);
  }
   getPackageDetailsForExportByLegacyID(legacyId: string) {
    let jsonParam: any;
    jsonParam = {
      'packagingMaterialLegacyId': legacyId
    };
    return this.httpService.get(Url.ActiveProductsAssociatedforPackagingMaterialUrl, jsonParam);
  }
  getPackageConfigDetailsForExportByLegacyID(legacyId: string) {
    let jsonParam: any;
    jsonParam = {
      'packagingMaterialLegacyId': legacyId
    };
    return this.httpService.get(Url.ActiveProductConfigurationforPackagingMaterialUrl, jsonParam);
  }
}
