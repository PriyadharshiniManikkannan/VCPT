import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MaintainPackagingMaterialsForConfigurationComponent } from './MaintainPackagingMaterialsForConfiguration.component';

const maintainPackagingMaterialsForConfigurationRoutes: Routes = [
    {
        path: '',
        component: MaintainPackagingMaterialsForConfigurationComponent
    },

    {
        path: ':id',
        component: MaintainPackagingMaterialsForConfigurationComponent
    }

];

@NgModule({
    imports: [RouterModule.forChild(maintainPackagingMaterialsForConfigurationRoutes)],
    exports: [RouterModule]
})
export class MaintainPackagingMaterialsForConfigurationRoutingModule {

}
