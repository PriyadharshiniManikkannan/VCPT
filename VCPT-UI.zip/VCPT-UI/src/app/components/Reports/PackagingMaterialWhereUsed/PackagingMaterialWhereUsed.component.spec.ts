import { TestBed, inject } from '@angular/core/testing';
import { HttpModule } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Rx';

import { PackagingItemWhereUsedComponent } from './PackagingMaterialWhereUsed.component';
import { PackagingItemWhereUsedService } from './shared/PackagingMaterialWhereUsed.service';
import { PackagingItemWhereUsed } from './shared/PackagingMaterialWhereUsed.model';

describe('a PackagingItemWhereUsed component', () => {
	let component: PackagingItemWhereUsedComponent;

	// register all needed dependencies
	beforeEach(() => {
		TestBed.configureTestingModule({
			imports: [HttpModule],
			providers: [
				{ provide: PackagingItemWhereUsedService, useClass: MockPackagingItemWhereUsedService },
				PackagingItemWhereUsedComponent
			]
		});
	});

	// instantiation through framework injection
	beforeEach(inject([PackagingItemWhereUsedComponent], (PackagingItemWhereUsedComponent) => {
		component = PackagingItemWhereUsedComponent;
	}));

	it('should have an instance', () => {
		expect(component).toBeDefined();
	});
});

// Mock of the original PackagingItemWhereUsed service
class MockPackagingItemWhereUsedService extends PackagingItemWhereUsedService {
	getList(): Observable<any> {
		return Observable.from([ { id: 1, name: 'One'}, { id: 2, name: 'Two'} ]);
	}
}
