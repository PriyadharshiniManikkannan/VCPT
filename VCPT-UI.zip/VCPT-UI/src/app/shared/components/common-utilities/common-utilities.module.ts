import { CommonUtilitiesComponent } from './common-utilities.component';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

@NgModule({
    imports: [
        CommonModule
    ],
    declarations: [CommonUtilitiesComponent]
})
export class CommonUtiltiesModule {

}
