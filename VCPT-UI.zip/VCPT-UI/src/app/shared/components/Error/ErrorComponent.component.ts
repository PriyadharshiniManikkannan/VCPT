import { Observer } from 'rxjs/Observer';
import { Observable } from 'rxjs/Observable';
import { Component } from '@angular/core';
import { ConfirmationService } from 'primeng/primeng';
import { APP_CONSTANTS } from './../../constants/app.constants';

@Component({
    templateUrl: './Error.component.html'
})
export class ErrorComponent {
    constructor() { }
}
