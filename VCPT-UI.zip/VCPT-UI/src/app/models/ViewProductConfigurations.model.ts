export class ViewProductConfigurations {
    productLegacyId: string;
    productDescription: string;
    sapRelevancyStatus: string;
    productCode: string;
    facilityCollection: string;
    productStatus: string;
    productComments: string;
    productId: string;
    characteristic: string;
    configurationComments: string;
    facility: string;
    productBusinessLifeCycleStatus: any;
}

