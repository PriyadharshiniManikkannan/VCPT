import { ProductSearchModel } from './../../models/SearchCriteria.model';
import { ViewProductMaster } from './../../models/ViewProductMaster.model';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { Url } from '../../shared/constants/app.constants';
import { HttpService } from '../../services/base/http.service';
@Injectable()
export class ViewProductMasterService {
    constructor(private _http: Http, private _httpService: HttpService) { }
    getFacilities() {
        return this._httpService.get(Url.FacilitiesUrl);
    }

    getStatus() {
        return this._httpService.get(Url.GGSMStatusesUrl);
    }
    getProductStatus() {
        return this._httpService.get(Url.VCPTStatusesUrl);
    }
    getProdDetails(jsonParam: any) {
        return this._httpService.get(Url.ProductSearchUrl, jsonParam);
    }
}
