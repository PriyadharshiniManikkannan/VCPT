import { HomeService } from './../services/Home.service';
import { OnlyNumberModule } from './../shared/Directives/OnlyNumber.module';
import { CommonUtiltiesModule } from './../shared/components/common-utilities/common-utilities.module';
import { SecurityService } from './../services/Security.service';
import { DialogDisplayModule } from './../shared/components/dialog-display/dialog-display.module';
import { UnsavedChangesModule } from './../shared/components/UnsavedChanges/UnsavedChanges.module';
import { NotAuthorizedModule } from './../shared/components/notAuthorized/NotAuthorized.module';
import { ErrorModule } from './../shared/components/Error/Error.module';
import { CanDeactivateGuard } from './../services/guards/CanComponentDeactivate.guard.service';
import { LoginService } from './../services/Login.service';
import { CookieService, CookieModule } from 'ngx-cookie';
import { AuthGuardService } from './../services/guards/AuthGuardService.service';
import { HttpService } from './../services/base/http.service';
import { NgModule } from '@angular/core';
import { APP_BASE_HREF, CommonModule } from '@angular/common';
import { LayoutComponent } from './layout.component';
import { HeaderComponent } from './header/header.component';
import { LayoutRoutingModule } from './layout.routing';
import { HomeModule } from '../components/Home/Home.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaintainProductModule } from './../components/Product/MaintainProduct/MaintainProduct.module';
import { MaintainUOMModule } from './../components/Admin/MaintainUOM/MaintainUOM.module';
import { MaintainCharacteristicsModule } from './../components/Admin/MaintainProductCharacteristics/MaintainProductCharacteristics.module';
import {
    MaintainProductConfigurationModule
} from './../components/Product/MaintainProductConfigurations/MaintainProductConfigurations.module';
import { ViewProductMasterModule } from './../components/Product/ViewProductMaster/ViewProductMaster.module';
import { ViewProductConfigurationsModule } from './../components/Product/ViewProductConfigurations/ViewProductConfigurations.module';
import { PackagingMaterialWhereUsedModule } from './../components/Reports/PackagingMaterialWhereUsed/PackagingMaterialWhereUsed.module';
import {
    AllProductsWithNoPackagingMaterialModule
} from './../components/Reports/AllProductsWithNoPackagingMaterial/AllProductsWithNoPackagingMaterial.module';
import { ExtractAllDataModule } from './../components/Reports/ExtractAllData/ExtractAllData.module';
import {
    MaintainPackagingMaterialsForConfigurationModule
} from './../components/Packaging/MaintainPackagingMaterialsForConfiguration/MaintainPackagingMaterialsForConfiguration.module';
import { ImportPackagingMaterialModule } from './../components/Packaging/ImportPackagingMaterial/ImportPackagingMaterial.module';
import {
    AddObsoletePackagingMaterialModule
} from './../components/Packaging/AddObsoletePackagingMaterial/AddObsoletePackagingMaterial.module';

import {
    ViewAllPackagingMaterialsforProductModule
} from './../components/Packaging/ViewAllPackagingMaterialsforProduct/ViewAllPackagingMaterialsforProduct.module';
import { ViewAllPackagingMaterialsModule } from './../components/Packaging/ViewAllPackagingMaterials/ViewAllPackagingMaterials.module';
import {
    ViewAllPackagingMaterialsforConfigurationsModule
} from './../components/Packaging/ViewAllPackagingMaterialsforConfigurations/ViewAllPackagingMaterialsforConfigurations.module';
import {
    MaintainPackagingMaterialsForProductModule
} from './../components/Packaging/MaintainPackagingMaterialsForProduct/MaintainPackagingMaterialsForProduct.module';

@NgModule({
    imports: [
        FormsModule,
        ReactiveFormsModule,
        LayoutRoutingModule,
        CommonModule,
        HomeModule,
        MaintainProductModule,
        MaintainCharacteristicsModule,
        MaintainUOMModule,
        ViewProductConfigurationsModule,
        ViewProductMasterModule,
        MaintainProductConfigurationModule,
        PackagingMaterialWhereUsedModule,
        ExtractAllDataModule,
        AllProductsWithNoPackagingMaterialModule,
        AddObsoletePackagingMaterialModule,
        ImportPackagingMaterialModule,
        MaintainPackagingMaterialsForConfigurationModule,
        MaintainPackagingMaterialsForProductModule,
        ViewAllPackagingMaterialsforConfigurationsModule,
        ViewAllPackagingMaterialsModule,
        ViewAllPackagingMaterialsforProductModule,
        UnsavedChangesModule,
        DialogDisplayModule,
        NotAuthorizedModule,
        CommonUtiltiesModule,
        CookieModule.forRoot(),
        ErrorModule,
        OnlyNumberModule
    ],
    providers: [
        { provide: APP_BASE_HREF, useValue: '/' },
        HttpService,
        CanDeactivateGuard,
        HomeService,
        AuthGuardService,
        LoginService,
        CookieService,
        SecurityService
    ],
    declarations: [
        LayoutComponent,
        HeaderComponent
    ]

})
export class LayoutModule {
}
