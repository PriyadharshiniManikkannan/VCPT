import { ViewProductConfigurations } from './../../models/ViewProductConfigurations.model';
import { ViewProductMaster } from './../../models/ViewProductMaster.model';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { Url } from '../../shared/constants/app.constants';
import { HttpService } from '../../services/base/http.service';
@Injectable()
export class ViewProductConfigurationsService {
  constructor(private _http: Http, private _httpService: HttpService) { }
  getProductDetailsByLegacyID(prodDetails: ViewProductMaster) {
    let jsonParam: any;
    jsonParam = {
      'productLegacyId': prodDetails.productLegacyID,
      'facilityCode': prodDetails.facilityCode,
      'productStatus': prodDetails.productStatus.statusCode,
      'productBusinessLifeCycleStatus': prodDetails.productBusinessLifeCycleStatus.statusCode,
      'productDescription': prodDetails.productDescription,
      'productCode': prodDetails.productCode
    };
    return this._httpService.get(Url.ProductSearchUrl, jsonParam);
    // return this._httpService.post(Url.ProdDetailsUrl, prodDetails);
  }
  getProductConfigurationByFacility(viewProductConfig: ViewProductConfigurations) {
    let jsonParam: any;
    jsonParam = {
      'productId': viewProductConfig.productId,
      'facilityCollection': viewProductConfig.facilityCollection,
      'viewMode': true
    };
    return this._httpService.get(Url.ProductConfigurationsUrl, jsonParam);
  }
  getProductConfigurationByFacilityExcel(viewProductConfig: ViewProductConfigurations) {
    let jsonParam: any;
    jsonParam = {
      'productId': viewProductConfig.productId,
      'facilityCollection': viewProductConfig.facilityCollection,
      'IsExport' : true
    };
    return this._httpService.get(Url.ProductConfigurationsUrl, jsonParam);
  }
}
