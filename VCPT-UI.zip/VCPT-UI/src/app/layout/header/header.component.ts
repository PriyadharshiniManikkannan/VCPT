import { Url } from './../../shared/constants/app.constants';
import { Router } from '@angular/router';
import { HomeService } from './../../services/Home.service';
import { LoginService } from './../../services/Login.service';
import { SecurityService } from './../../services/Security.service';
import { UserDetails } from './../../models/UserDetails.model';
import { Component, OnInit } from '@angular/core';
import { AppMenus } from './../../shared/constants/menu.constants';

@Component({
	selector: 'app-header',
	templateUrl: 'header.component.html'
})
export class HeaderComponent implements OnInit {
	tabIndex: number;
	menuBarItems = AppMenus;
	fullName: any;
	logOutURL: string;
	constructor(
		private securityService: SecurityService,
		private homeService: HomeService,
		private router: Router
	) {

	}
	ngOnInit() {
		this.tabIndex = 0;
		this.enableDisableMenu();
		this.fullName = UserDetails.getInstance().FullName;
	}

	enableDisableMenu() {
		if (this.securityService.isAdminUser() && !this.securityService.isReadOnlyUser()) {
			const adminMenu = this.menuBarItems.menus.find(menu => menu.mainMenuName.trim().toUpperCase() === 'ADMIN');

			if (typeof adminMenu !== 'undefined'
				&& adminMenu !== null) {
				adminMenu.enabled = true;
			}
			this.menuBarItems.menus.forEach(menu => {
				menu.SubMenu.filter(submenu => submenu.editable === true)
					.forEach(submenu => {
						submenu.enabled = true;
					});
			});
		} else if (!this.securityService.isAdminUser() && !this.securityService.isReadOnlyUser()) {
			const adminMenu =
				this.menuBarItems
					.menus
					.find(menu => menu.mainMenuName.trim().toUpperCase() === 'ADMIN');

			if (typeof adminMenu !== 'undefined'
				&& adminMenu !== null) {
				adminMenu.enabled = false;
			}
			this.menuBarItems.menus.forEach(menu => {
				menu.SubMenu.filter(submenu => submenu.editable === true)
					.forEach(submenu => {
						submenu.enabled = true;
					});
			});
		} else {
			const adminMenu =
				this.menuBarItems
					.menus
					.find(menu => menu.mainMenuName.trim().toUpperCase() === 'ADMIN');

			if (typeof adminMenu !== 'undefined'
				&& adminMenu !== null) {
				adminMenu.enabled = false;
			}
			this.menuBarItems.menus.forEach(menu => {
				menu.SubMenu.filter(submenu => submenu.editable === true)
					.forEach(submenu => {
						submenu.enabled = false;
					});
			});
		}
	}
	logOut() {
		window.location.href = Url.LogoutUrl;
	}
	helpFileDownload() {
		this.homeService
			.getHelpFileURL()
			.subscribe((url: string) => {
				if (url && url.trim().length > 0) {
					window.open(url, '_blank');
				}
			}, (err: Error) => {
				this.router.navigate([Url.error]);
				return;
			});
	}
}
