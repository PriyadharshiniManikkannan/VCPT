import { APP_CONSTANTS } from './../../constants/app.constants';
import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';

@Component({
  templateUrl: './common-utilities.component.html',
  styleUrls: ['./common-utilities.component.scss']
})
export class CommonUtilitiesComponent implements OnInit {

  public static getCurrentDateTimeStamp(): string {
    const dateTime = new Date();
    const datePipe = new DatePipe(APP_CONSTANTS.defaultLocaleString);
    let formattedDate = datePipe.transform(dateTime.getDate(), 'MMddyyyy');
    formattedDate += '_' + Math.floor(dateTime.getTime() / 1000);
    return formattedDate;
  }

  constructor() { }

  ngOnInit() {
  }

}
