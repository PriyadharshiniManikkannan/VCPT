import { CommonUtilitiesComponent } from './../../../shared/components/common-utilities/common-utilities.component';
import { SecurityService } from './../../../services/Security.service';
import { Component, OnInit } from '@angular/core';
import { FormLabelValues, ScreenTitles } from './../../../shared/constants/form.constants';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { APP_CONSTANTS, ConstantValues, MessageItems, RouteURLs, Url } from './../../../shared/constants/app.constants';
import { MessageModel } from './../../../models/MessageModel.model';
import { ViewProductMasterService } from './../../../services/product/ViewProductMaster.service';
import { AllProductsWithNoPackagingMaterialService } from './../../../services/Reports/AllProductsWithNoPackagingMaterial.service';
import { utils, write, WorkBook } from 'xlsx';
import { saveAs } from 'file-saver';
import { Router, ActivatedRoute } from '@angular/router';

import { SelectItem } from 'primeng/primeng';

@Component(
    {
        templateUrl: './AllProductsWithNoPackagingMaterial.Component.html',
        styleUrls: ['./AllProductsWithNoPackagingMaterial.Component.scss']
    }
)

export  /**
 * AllProductsWithNoPackagingMaterialComponent
 */
    class AllProductsWithNoPackagingMaterialComponent implements OnInit {
    formLabels: any;
    formTitle: any;
    facilityDropdownItems: SelectItem[];
    selectedFacilities: string;
    NoPackagingForm: FormGroup;
    messageHeader: string;
    returnMessage: MessageModel;
    messageIconType: string;
    displayMessage: boolean;
    cols: any[];
    seletedFacilityValues: string;
    readOnlyUser: boolean;
    recordsPerPage: number;
    firstRecordIndexofGrid: number;
    productDetails: any[];
    isNoRecords: boolean;
    selectedRow: any;
    disableMaintainProductButton: boolean;
    legacyID: any;
    // Loading variable for ngx-loading component
    public loading = false;
    productExportDetails: any[];
    ConstantValues: any;
    constructor(
        private formBuilder: FormBuilder, private ViewProductMasterService: ViewProductMasterService
        , private allProductsWithNoPackagingMaterialService: AllProductsWithNoPackagingMaterialService,
        private _router: Router,
        private securityService: SecurityService) {
    }
    ngOnInit() {
        this.formLabels = FormLabelValues;
        this.ConstantValues = ConstantValues;
        this.formTitle = ScreenTitles;
        this.recordsPerPage = APP_CONSTANTS.recordsPerPageConstant;
        this.firstRecordIndexofGrid = 1;
        this.productDetails = [];
        this.readOnlyUser = this.securityService.isReadOnlyUser();
        this.selectedFacilities = '';
        this.returnMessage = new MessageModel();
        this.cols = [];
        this.isNoRecords = true;
        this.legacyID = '';
        this.cols.push(FormLabelValues.productLegacyID,
            FormLabelValues.productDescription,
            FormLabelValues.productCode,
            FormLabelValues.facilityPlural);
        this.buildForm();
        this.facilityDropdownItems = [];
        this.ViewProductMasterService.getFacilities().subscribe((data: any) => {
            data.forEach(element => {
                this.facilityDropdownItems.push({ label: element.facilityName, value: element.facilityID });
            },
                (err) => {
                    if (err !== undefined) {
                        this._router.navigate([Url.error]);
                        return;
                    }
                });
        });
        this.enableDisableButtons();
    }
    buildForm() {
        this.NoPackagingForm = this.formBuilder.group({ facilities: [''] });
    }
    s2ab(s) {
        const buf = new ArrayBuffer(s.length);
        const view = new Uint8Array(buf);
        for (let i = 0; i !== s.length; ++i) {
            view[i] = s.charCodeAt(i) & 0xFF;
        }
        return buf;
    }
    exportToExcel() {
        let timestamp = '';
        timestamp = CommonUtilitiesComponent.getCurrentDateTimeStamp();
        const sheetName = 'AllProductsWithNoPackagingMaterial' + '_' + timestamp + '.xlsx';
        this.seletedFacilityValues = '';
        this.productExportDetails = [];
        if (this.selectedFacilities !== '') {
            for (const facility of this.selectedFacilities) {
                this.seletedFacilityValues += facility.toString().trim() + ',';
            }
        } else {
            this.seletedFacilityValues = '';
        }
        if (this.seletedFacilityValues.length !== 0) {
            this.seletedFacilityValues = this.seletedFacilityValues.substring(0, this.seletedFacilityValues.length - 1);
        }
        const ws_product = 'Product';
        const wb: WorkBook = { SheetNames: [], Sheets: {} };
        this.allProductsWithNoPackagingMaterialService
            .getProductDetailsExcelByLegacyID(this.seletedFacilityValues).subscribe((data: any) => {
                this.productExportDetails = [];
                this.productExportDetails = data;
                const ws: any = utils.json_to_sheet(this.productExportDetails);
                wb.SheetNames.push(ws_product);
                wb.Sheets[ws_product] = ws;
                const wbout = write(wb, { bookType: 'xlsx', bookSST: true, type: 'binary' });
                saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }),
                  sheetName );
            },
            (err) => {
                if (err !== undefined) {
                    this._router.navigate([Url.error]);
                    return;
                }
            });

    }
    ShowResults() {
        this.selectedRow = null;
        this.loading = true;
        this.seletedFacilityValues = '';
        this.productDetails = [];
        if (this.selectedFacilities !== '') {
            for (const facility of this.selectedFacilities) {
                this.seletedFacilityValues += facility.toString().trim() + ',';
            }
        } else {
            this.seletedFacilityValues = '';
        }
        if (this.seletedFacilityValues.length !== 0) {
            this.seletedFacilityValues = this.seletedFacilityValues.substring(0, this.seletedFacilityValues.length - 1);
        }
        this.allProductsWithNoPackagingMaterialService.getProductDetailsByLegacyID(this.seletedFacilityValues).subscribe((data: any) => {
            this.loading = false;
            if (data && data.length !== 0) {
                this.productDetails = data;
                this.isNoRecords = false;
            } else {
                this.isNoRecords = true;
            }
        },
            (err) => {
                if (err !== undefined) {
                    this._router.navigate([Url.error]);
                    return;
                }
            });
        this.enableDisableButtons();
    }

    onGridPageChange(event: any) {
        this.firstRecordIndexofGrid = event.first === 1 ? event.first : event.first + 1;
        this.recordsPerPage = event.first !== 1 ? event.rows + event.first : event.rows;
    }
    maintainPackagingMaterials() {
        if (this.legacyID !== '' && this.legacyID.length === ConstantValues.productLegacyIDLength) {
            this._router.navigateByUrl(RouteURLs.MaintainPackagingMaterialsPath + ';id=' + this.legacyID);
        }
    }
    enableDisableButtons() {
        const rowSelected = (typeof this.selectedRow !== 'undefined' && this.selectedRow !== null);
        if (this.readOnlyUser) {
            this.disableMaintainProductButton = true;
        } else {
            this.disableMaintainProductButton = true && !rowSelected;
        }
    }
    gridRowSelect(event: any) {
        this.legacyID = event.data.ProductLegacyID;
        this.enableDisableButtons();
    }
}
