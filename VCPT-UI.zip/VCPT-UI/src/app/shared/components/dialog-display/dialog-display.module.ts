import { DialogDisplayComponent } from './dialog-display.component';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ButtonModule,DialogModule } from 'primeng/primeng';

@NgModule({
    imports: [
        CommonModule,
        ButtonModule,
        DialogModule
    ],
    declarations: [DialogDisplayComponent],
    exports: [DialogDisplayComponent]
})
export class DialogDisplayModule {

}
