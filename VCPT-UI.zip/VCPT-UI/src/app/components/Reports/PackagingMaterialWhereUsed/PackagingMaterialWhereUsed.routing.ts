
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PackagingMaterialWhereUsedComponent } from './../PackagingMaterialWhereUsed/PackagingMaterialWhereUsed.component';
const packagingMaterialWhereUsedRoutes: Routes = [
    {
        path: '',
        component: PackagingMaterialWhereUsedComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(packagingMaterialWhereUsedRoutes)],
    exports: [RouterModule]
})
export class PackagingMaterialWhereUsedRouting {
}
