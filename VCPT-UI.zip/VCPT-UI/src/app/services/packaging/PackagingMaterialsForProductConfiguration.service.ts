import { MaintainProductConfigurations } from './../../models/MaintainProductConfigurations.model';
import { MaintainProductConfigurationsService } from './../product/MaintainProductConfigurations.service';
import { MaintainProductService } from './../product/MaintainProduct.service';
import { ProductConfigurationPackagingMaterialMapping } from './../../models/ProductConfigurationPackagingMaterialMapping.model';
import { ProductDetails, CharacteristicsListBoxModel } from './../../models/MaintainProduct.model';
import { Url } from './../../shared/constants/app.constants';
import { HttpService } from './../base/http.service';
import { Observable } from 'rxjs/Observable';
import { Http, Response } from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
@Injectable()
export class PackagingMaterialForProductConfigurationService {
    constructor(private _httpService: HttpService,
        private productService: MaintainProductService,
        private configurationDetailService: MaintainProductConfigurationsService) { }
    getProductDetails(jsonParam: any) {
        return this.productService.getActiveProduct(jsonParam);
    }
    getPackagingMaterialsForProductConfiguration(jsonParam: any) {
        return this._httpService.get(Url.PackagingMaterialforProductConfiguration, jsonParam);
    }
    getPackagingMaterialsForProductConfigurationNoLock(jsonParam: any) {
        return this._httpService.get(Url.PackagingMaterialForProductConfigurationNoLockUrl, jsonParam);
    }
    getProductConfigurationDetails(jsonParam: MaintainProductConfigurations) {
        return this.configurationDetailService.getProductConfigurationByFacility(jsonParam);
    }
    getPackagingMaterialsForProductConfigurationInExportFormat(packagingMaterialForProductConfiguration: any) {
        let jsonParam: any;
        jsonParam = {
            'facilityId': packagingMaterialForProductConfiguration.facilityId,
            'productLegacyId': packagingMaterialForProductConfiguration.productLegacyId,
            'productConfigurationID': packagingMaterialForProductConfiguration.productConfigurationID
        };
        return this._httpService.get(Url.ExtractAllDataUrl, jsonParam);
    }
    SavePackagingMaterialForProductConfiguration(packagingMaterial: ProductConfigurationPackagingMaterialMapping) {
        return this._httpService.post(Url.PackagingMaterialforProductConfiguration, packagingMaterial);
    }
    deletePackageAssociation(ProductConfigurationPackagingMaterialMappingId: number) {
        return this._httpService
            .post(Url.DisassociatePackagingMaterialforProductConfiguration, ProductConfigurationPackagingMaterialMappingId);
    }
    unlockProductConfigforEdit(packageDetails: ProductConfigurationPackagingMaterialMapping) {
        return this._httpService.post(Url.UnlockConfigFacilityUrl, packageDetails);
    }
    /**
     * Method: unlockProductConfigforEditSynchronous
     *
     * Usage: Used to send synchronous post request and unlock the product configuration.
     */
    unlockProductConfigforEditSynchronous(packageDetails: ProductConfigurationPackagingMaterialMapping) {
        return this._httpService.synchronousPost(Url.UnlockConfigFacilityUrl, packageDetails);
    }

    getFacilityById(facilityId) {
        let jsonParam: any;
        jsonParam = {
            'facilityId': facilityId
        };
        return this._httpService.get(Url.FacilitiesUrl, jsonParam);
    }
}
