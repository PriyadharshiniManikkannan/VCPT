import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import { ExtractAllDataComponent } from './ExtractAllData.component';
const extractAllDataRoutes: Routes = [
    {
        path: '',
        component: ExtractAllDataComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(extractAllDataRoutes)],
    exports: [RouterModule]
})
export class ExtractAllDataRoutingModule {
}
