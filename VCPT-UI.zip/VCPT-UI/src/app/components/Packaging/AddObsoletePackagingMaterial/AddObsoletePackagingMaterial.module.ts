import { DialogDisplayModule } from './../../../shared/components/dialog-display/dialog-display.module';
import { APP_CONSTANTS } from './../../../shared/constants/app.constants';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AddObsoletePackagingMaterialService } from './../../../services/packaging/AddObsoletePackagingMaterial.service';
import { AddObsoletePackagingMaterialRouting } from './AddObsoletePackagingMaterial.routing';
import { AddObsoletePackagingMaterialComponent } from './AddObsoletePackagingMaterial.component';

import {
    DialogModule, InputMaskModule, MessagesModule, ListboxModule,
     ButtonModule, ConfirmationService, ConfirmDialogModule
} from 'primeng/primeng';

@NgModule({
    imports: [
         CommonModule,
        AddObsoletePackagingMaterialRouting,
        DialogModule,
        InputMaskModule,
        ConfirmDialogModule,
        ListboxModule,
        ButtonModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        DialogDisplayModule,
        LoadingModule.forRoot(APP_CONSTANTS.loaderConfig)],

    declarations: [AddObsoletePackagingMaterialComponent],
     providers: [AddObsoletePackagingMaterialService, ConfirmationService],
    exports: [AddObsoletePackagingMaterialRouting]
})
export class AddObsoletePackagingMaterialModule {

}
