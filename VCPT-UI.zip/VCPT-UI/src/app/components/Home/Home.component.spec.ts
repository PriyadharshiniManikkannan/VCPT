import { TestBed, inject } from '@angular/core/testing';

import { HomeComponent } from './Home.component';

describe('a Home component', () => {
	let component: HomeComponent;

	// register all needed dependencies
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [
				HomeComponent
			]
		});
	});

	// instantiation through framework injection
	beforeEach(inject([HomeComponent], (HomeComponent) => {
		component = HomeComponent;
	}));

	it('should have an instance', () => {
		expect(component).toBeDefined();
	});
});