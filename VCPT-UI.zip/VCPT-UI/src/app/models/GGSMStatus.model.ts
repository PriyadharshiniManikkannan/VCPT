export class GGSMStatusModel {
    statusCode: string;
    statusDesc: string;
    constructor() {
        this.statusCode = '';
        this.statusDesc = '';
    }
}
