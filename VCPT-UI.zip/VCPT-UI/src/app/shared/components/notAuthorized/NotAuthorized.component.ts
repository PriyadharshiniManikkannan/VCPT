import { SecurityService } from './../../../services/Security.service';
import { Observer } from 'rxjs/Observer';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { ConfirmationService } from 'primeng/primeng';
import { APP_CONSTANTS,Url } from './../../constants/app.constants';

@Component({
    templateUrl: './NotAuthorized.component.html'
})
export class NotAuthorizedComponent implements OnInit {

    validUser: boolean;
    ngOnInit(): void {
        this.validUser = this.securityService.isValidUser();
    }
    constructor(private securityService: SecurityService) { }
    logOut() {
        window.location.href = Url.LogoutUrl;
    }
}
