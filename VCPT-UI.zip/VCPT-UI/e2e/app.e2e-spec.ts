import { VCPTPage } from './app.po';

describe('vcpt App', () => {
  let page: VCPTPage;

  beforeEach(() => {
    page = new VCPTPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
