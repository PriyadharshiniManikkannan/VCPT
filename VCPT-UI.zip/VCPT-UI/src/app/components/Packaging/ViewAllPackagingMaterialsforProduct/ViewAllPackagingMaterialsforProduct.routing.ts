import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ViewAllPackagingMaterialsforProductComponent } from './ViewAllPackagingMaterialsforProduct.component';

const viewAllPackagingMaterialsforProductsRoutes: Routes = [
    {
        path: '',
        component: ViewAllPackagingMaterialsforProductComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(viewAllPackagingMaterialsforProductsRoutes)],
    exports: [RouterModule]
})
export class ViewAllPackagingMaterialsforProductsRouteModule {

}
