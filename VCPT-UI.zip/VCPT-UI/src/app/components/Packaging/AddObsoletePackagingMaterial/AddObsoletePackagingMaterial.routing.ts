import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddObsoletePackagingMaterialComponent } from './AddObsoletePackagingMaterial.component';

const addObsoletePackagingMaterialsRoutes: Routes = [
    {
        path: '',
        component: AddObsoletePackagingMaterialComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(addObsoletePackagingMaterialsRoutes)],
    exports: [RouterModule]
})
export class AddObsoletePackagingMaterialRouting {

}
