import { MaintainProductConfigurationsService } from './../../../services/product/MaintainProductConfigurations.service';
import { PrintAllPackagingMaterialAssociationComponent } from './PrintAllPackagingMaterialAssociation.component';
import {
    PackagingMaterialForProductConfigurationService
} from './../../../services/packaging/PackagingMaterialsForProductConfiguration.service';
import { APP_CONSTANTS } from './../../../shared/constants/app.constants';
import { DialogDisplayModule } from './../../../shared/components/dialog-display/dialog-display.module';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { ViewAllPackagingMaterialsforConfigurationsRouteModule } from './ViewAllPackagingMaterialsforConfigurations.routing';
import { ViewAllPackagingMaterialsforConfigurationsComponent } from './ViewAllPackagingMaterialsforConfigurations.component';
import {
    MessagesModule, InputMaskModule, ListboxModule, AccordionModule,
    DataTableModule, SharedModule, ConfirmDialogModule, DialogModule, ConfirmationService
} from 'primeng/primeng';
import { LoadingModule } from 'ngx-loading';
@NgModule({
    imports: [
        ConfirmDialogModule,
        InputMaskModule,
        DialogModule,
        DataTableModule,
        AccordionModule,
        DialogDisplayModule,
        SharedModule,
        FormsModule,
        ReactiveFormsModule,
        LoadingModule.forRoot(APP_CONSTANTS.loaderConfig),
        CommonModule,
        ViewAllPackagingMaterialsforConfigurationsRouteModule],
    providers: [
        ConfirmationService,
        PackagingMaterialForProductConfigurationService,
        MaintainProductConfigurationsService
    ],
    declarations: [
        ViewAllPackagingMaterialsforConfigurationsComponent,
        PrintAllPackagingMaterialAssociationComponent
    ]
})
export class ViewAllPackagingMaterialsforConfigurationsModule {

}
