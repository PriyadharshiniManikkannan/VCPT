export class VCPTStatusModel {
    statusCode: number;
    statusDesc: string;
    constructor() {
        this.statusCode = 0;
        this.statusDesc = '';
    }
}
