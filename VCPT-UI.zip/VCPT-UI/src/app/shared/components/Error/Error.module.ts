import { ErrorComponent } from './ErrorComponent.component';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import {ErrorRoutingModule} from './Error.routing';

@NgModule({
      imports: [ErrorRoutingModule],
    declarations: [ErrorComponent],
})
export class ErrorModule {

}


