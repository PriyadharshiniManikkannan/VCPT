import { APP_CONSTANTS } from './../../constants/app.constants';
import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'dialog-display',
  templateUrl: './dialog-display.component.html',
  styleUrls: ['./dialog-display.component.scss']
})
export class DialogDisplayComponent implements OnInit {
  @Input() messageHeader: string;
  @Input() showMessage: boolean;
  @Input() messageToShow: string;
  @Input() listofItemsforDisplay: string[];
  @Input() iconToDisplay: string;
  @Output() showMessageChange: EventEmitter<boolean> = new EventEmitter<boolean>();
  appconstants: any;
  constructor() { }

  ngOnInit() {
    this.appconstants = APP_CONSTANTS;
  }
  changeValue() {
    this.showMessage = false;
    this.showMessageChange.emit(this.showMessage);
  }
}
