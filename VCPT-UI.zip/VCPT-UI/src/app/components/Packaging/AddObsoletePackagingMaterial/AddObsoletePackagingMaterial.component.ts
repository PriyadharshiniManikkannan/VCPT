import { GGSMStatusModel } from './../../../models/GGSMStatus.model';
import { Component, OnInit, HostListener } from '@angular/core';
import { PackagingMaterial } from './../../../models/PackagingMaterial.model';
import { AddObsoletePackagingMaterialService } from './../../../services/packaging/AddObsoletePackagingMaterial.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { UnsavedChangesComponent } from './../../../shared/components/UnsavedChanges/UnsavedChanges.component';
import { MessageModel } from './../../../models/MessageModel.model';
import { CanComponentDeactivate } from './../../../services/guards/CanComponentDeactivate.guard.service';
import { APP_CONSTANTS, ConstantValues, MessageItems, RouteURLs, Url } from './../../../shared/constants/app.constants';
import { FormLabelValues, ScreenTitles } from './../../../shared/constants/form.constants';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import { ConfirmationService, Message } from 'primeng/primeng';

@Component({
  templateUrl: 'AddObsoletePackagingMaterial.component.html',
  styleUrls: ['./AddObsoletePackagingMaterial.component.scss']
})


export class AddObsoletePackagingMaterialComponent implements OnInit {
  MaterialDesc: string;
  SAPText: string;
  QuantityUOM: string;
  MaterialLifeCycleStatus: string;
  legacyID: string;
  returnMessage: MessageModel;
  messageHeader: string;
  displayMessage = false;
  messageIconType: string;
  addObsoleteForm: FormGroup;
  unsavedChangesComponent: UnsavedChangesComponent;
  submit: boolean;
  formLabels: any;
  formTitle: any;
  constValues: any;
  // Loading variable for ngx-loading component
  public loading = false;

  constructor(
    private activatedRoute: ActivatedRoute,
    private addObsoletePackagingMaterialService: AddObsoletePackagingMaterialService,
    private confirmationService: ConfirmationService,
    private formBuilder: FormBuilder,
    private router: Router) {
  }
  ngOnInit() {
    this.loading = true;
    this.formLabels = FormLabelValues;
    this.constValues = ConstantValues;
    this.returnMessage = new MessageModel();
    this.initializeForm();
    this.initializeMessage();
    this.buildForm();
    this.loading = false;
  }
  initializeForm() {
    this.formTitle = ScreenTitles;
    this.MaterialDesc = '';
    this.SAPText = '';
    this.QuantityUOM = '';
    this.MaterialLifeCycleStatus = this.constValues.statusObsolete;
    this.legacyID = '';
    this.unsavedChangesComponent = new UnsavedChangesComponent(this.confirmationService);
  }
  initializeMessage() {
    this.returnMessage = new MessageModel();
    this.messageHeader = '';
    this.returnMessage.listofItemsforDisplay = [];
    this.returnMessage.message = '';
    this.returnMessage.messageCode = '';
  }
  Save() {
    if (this.legacyID !== '' && this.legacyID.length === ConstantValues.productLegacyIDLength && this.QuantityUOM !== ''
    ) {
      const packagingMaterial = new PackagingMaterial();
      packagingMaterial.packagingMaterialLegacyID = this.legacyID;
      packagingMaterial.packagingMaterialDescription = this.MaterialDesc;
      packagingMaterial.sapBasicDataText = this.SAPText;
      packagingMaterial.quantityUOM = this.QuantityUOM;
      packagingMaterial.materialBusinessLifeCycleStatus.statusDesc = this.MaterialLifeCycleStatus;
      packagingMaterial.materialBusinessLifeCycleStatus.statusCode = ConstantValues.statusObsoleteCode;
      this.addObsoletePackagingMaterialService.addObsoleteDetails(packagingMaterial).subscribe((returnMessage: MessageModel) => {
        this.initializeMessage();
        this.returnMessage.message = returnMessage.message;
        this.returnMessage.messageType = returnMessage.messageType;
        this.getIConforMessageDisplay();
        this.displayMessage = true;
        this.loading = false;
         if (returnMessage.messageType !== MessageItems.erroHeader) {
          this.legacyID = '';
         this.MaterialDesc = '';
          this.SAPText = '';
          this.QuantityUOM = '';
        }else {
          this.MaterialDesc = '';
          this.SAPText = '';
          this.QuantityUOM = '';

        }
      }, (err: Error) => {
        if (err !== undefined) {
           this.router.navigate([Url.error]);
          this.loading = false;
          this.addObsoleteForm.reset();
           this.initializeForm();
              this.buildForm();
        }
      });
    } else {

      if (this.legacyID === '' || this.legacyID.length !== ConstantValues.productLegacyIDLength) {
        this.initializeMessage();
        this.messageHeader = MessageItems.erroHeader;
        this.returnMessage.message += MessageItems.packagingIdSearchMessage;
        this.messageIconType = APP_CONSTANTS.ErrorIcon;
        this.displayMessage = true;
        this.loading = false;
        return;
      }
      if (this.QuantityUOM === '' && this.legacyID !== '' && this.legacyID.length === ConstantValues.productLegacyIDLength) {
        this.initializeMessage();
        this.messageHeader = MessageItems.erroHeader;
        this.returnMessage.message = MessageItems.packagingQuantityUOMEmptyMessage;
        this.messageIconType = APP_CONSTANTS.ErrorIcon;
        this.displayMessage = true;
        this.loading = false;
        return;
      }
    }

  }
  @HostListener('window:beforeunload', ['$event'])
  canNavigateAway(event: any) {
    if (this.checkDirtyForm()) {
      event.returnValue = APP_CONSTANTS.UnsavedChangesMessage;
    }
  }
  canDeactivate(): Observable<boolean> | boolean {
    if (this.checkDirtyForm()) {
      return this.getUserConfirmation().first();
    } else {
      return true;
    }
  }

  getUserConfirmation(): Observable<boolean> {
    return this.unsavedChangesComponent.getUnsavedChangesConfirmation();
  }
  checkDirtyForm(): boolean {
    return this.addObsoleteForm ? this.addObsoleteForm.dirty : false;
  }
  getIConforMessageDisplay() {
    switch (this.returnMessage.messageType.trim().toUpperCase()) {
      case 'Error'.toUpperCase(): this.messageIconType = APP_CONSTANTS.ErrorIcon;
        this.messageHeader = MessageItems.erroHeader; break;
      case 'Information'.toUpperCase(): this.messageIconType = APP_CONSTANTS.InformationIcon;
        this.messageHeader = MessageItems.saveHeader; break;
      case 'Warning'.toUpperCase(): this.messageIconType = APP_CONSTANTS.WarningIcon; break;
      default: this.messageIconType = APP_CONSTANTS.InformationIcon; break;
    }
  }
  buildForm() {
    this.addObsoleteForm
      = this.formBuilder.group({
        legacyID: new FormControl(),
        MaterialDesc: new FormControl(),
        SAPText: new FormControl(),
        QuantityUOM: new FormControl(),
        MaterialLifeCycleStatus: new FormControl({ value: ConstantValues.statusObsolete, disabled: 'true' }, []),
      });
  }
  viewPackaging() {
    if (this.legacyID !== '' && this.legacyID.length === ConstantValues.productLegacyIDLength) {
      this.router.navigateByUrl(RouteURLs.ViewPackagingMaterialsPath + ';id=' + this.legacyID);
    }else {
      this.messageHeader = MessageItems.erroHeader;
      this.returnMessage.message = MessageItems.packagingIdSearchMessage;
      this.messageIconType = APP_CONSTANTS.ErrorIcon;
      this.displayMessage = true;
      this.loading = false;
      return;
    }
  }
}
