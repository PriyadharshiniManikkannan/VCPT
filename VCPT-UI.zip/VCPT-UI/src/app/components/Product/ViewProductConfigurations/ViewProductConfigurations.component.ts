import { CommonUtilitiesComponent } from './../../../shared/components/common-utilities/common-utilities.component';
import { SecurityService } from './../../../services/Security.service';
import { APP_CONSTANTS, containsSearchfilterColumns, Url } from './../../../shared/constants/app.constants';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ViewProductConfigurationsService } from './../../../services/product/ViewProductConfiguration.service';
import { ViewProductConfigurations } from './../../../models/ViewProductConfigurations.model';
import { ViewProductMaster } from './../../../models/ViewProductMaster.model';
import { utils, write, WorkBook } from 'xlsx';
import { saveAs } from 'file-saver';
import { element } from 'protractor';
import { ConstantValues, excludeColumns, RouteURLs, MessageItems } from '../../../shared/constants/app.constants';
import { MessageModel } from './../../../models/MessageModel.model';
import { FormLabelValues, ScreenTitles } from './../../../shared/constants/form.constants';

import { SelectItem, Message } from 'primeng/primeng';
import { ConfirmationService, DialogModule } from 'primeng/primeng';
@Component({
    templateUrl: './ViewProductConfigurations.component.html',
    styleUrls: ['./ViewProductConfigurations.component.scss']
})

export class ViewProductConfigurationsComponent implements OnInit {
    facilityDropdownItems: SelectItem[];
    activeConfiguration: any[];
    displayConfigGrid: boolean;
    colsGrid: any[] = [];
    legacyID: string;
    productID: string;
    SAPRelevancy: string;
    ProductCode: string;
    ProductDesc: string;
    Facility: string;
    selectFacility: string[];
    showFacilities: boolean;
    productStatusCode: string;
    selectedFacilityValues: string;
    data: any;
    err: any;
    message: boolean;
    editAccess: boolean;
    adminAccess: boolean;
    productDetailSelected: boolean;
    viewProductDetails: ViewProductConfigurations[];
    disabled: boolean;
    disableMaintainConfigurationButton: boolean;
    facilityCollection: any[];
    configurationExcel: any[];
    displayButton: boolean;
    productComments: string;
    productBusinessLifeCycleStatus: any;
    recordsPerPage: number;
    firstRecordIndexofGrid: number;
    messageHeader: string;
    messageIconType: string;
    displayMessage: boolean;
    readOnlyUser: boolean;
    returnMessage: MessageModel;
    formLabels: any;
    formTitle: any;
    // Loading variable for ngx-loading component
    public loading = false;

    constructor(private ViewProductConfigurationService: ViewProductConfigurationsService,
        private _router: Router,
        private activatedRoute: ActivatedRoute,
        confirmationService: ConfirmationService,
        private securityService: SecurityService
    ) { }
    ngOnInit() {
        this.formLabels = FormLabelValues;
        this.loading = true;
        this.SAPRelevancy = '';
        this.ProductCode = '';
        this.ProductDesc = '';
        this.Facility = '';
        this.productComments = '';
        this.displayConfigGrid = false;
        this.facilityDropdownItems = [];
        this.editAccess = true;
        this.selectFacility = [];
        this.formTitle = ScreenTitles;
        this.displayConfigGrid = false;
        this.productDetailSelected = false;
        this.recordsPerPage = APP_CONSTANTS.recordsPerPageConstant;
        this.firstRecordIndexofGrid = 1;
        this.displayButton = false;
        this.readOnlyUser = this.securityService.isReadOnlyUser();
        this.returnMessage = new MessageModel();
        this.enableDisableButtons();
        this.activatedRoute.params.subscribe((params: Params) => {
            this.legacyID = params['id'];

            if (this.legacyID !== undefined && this.legacyID !== '' && this.legacyID.length === ConstantValues.productLegacyIDLength) {
                const prod = new ViewProductMaster();
                prod.productLegacyID = this.legacyID;
                prod.facilityCode = '';
                prod.productStatus.statusCode = 0;
                prod.productBusinessLifeCycleStatus.statusCode = '';
                prod.productDescription = '';
                prod.productCode = '';
                this.getProductDetails(prod);
                this.loading = false;
            }
        }, (error: Error) => {
            this._router.navigate([Url.error]);
        }, () => this.loading = false);

        this.loading = false;
    }
    showResults(): void {
        this.loading = true;
        this.selectFacility = [];
        this.displayConfigGrid = false;
        this.displayButton = false;
        if (this.legacyID !== undefined && this.legacyID !== '' && this.legacyID.length === ConstantValues.productLegacyIDLength) {
            const prod = new ViewProductMaster();
            prod.productLegacyID = this.legacyID;
            prod.facilityCode = '';
            prod.productStatus.statusCode = 0;
            prod.productBusinessLifeCycleStatus.statusCode = '';
            prod.productDescription = '';
            prod.productCode = '';
            this.getProductDetails(prod);
            this.loading = false;
        } else {
            this.loading = false;
            this.SAPRelevancy = '';
            this.ProductCode = '';
            this.ProductDesc = '';
            this.Facility = '';
            this.showFacilities = false;
            this.selectFacility = [];
            this.facilityDropdownItems = [];
            this.productComments = '';
            this.messageHeader = MessageItems.productHeader;
            this.returnMessage.message = MessageItems.draftMessage;
            this.messageIconType = APP_CONSTANTS.ErrorIcon;
            this.displayMessage = true;
            this.loading = false;
            return;
        }
    }
    btnViewClick() {
        this.loading = true;
        this.selectedFacilityValues = '';
        this.data = '';
        this.message = false;
        if (this.selectFacility.length !== 0) {
            for (const facility of this.selectFacility) {
                this.selectedFacilityValues += facility + ',';
            }
            if (this.selectedFacilityValues !== '' && this.selectedFacilityValues !== undefined) {
                this.selectedFacilityValues = this.selectedFacilityValues.substring(0, this.selectedFacilityValues.length - 1);
                const viewProductConfig = new ViewProductConfigurations();
                viewProductConfig.productId = this.productID;
                viewProductConfig.facilityCollection = this.selectedFacilityValues;
                this.ViewProductConfigurationService.getProductConfigurationByFacility(viewProductConfig).
                    subscribe((ViewProductDetails: any) => {
                        this.activeConfiguration = ViewProductDetails;
                        if (this.activeConfiguration.length > 0) {
                            this.displayButton = true;
                            this.displayConfigGrid = true;
                            this.getColumnforGrid(this.activeConfiguration);
                        } else {
                            this.displayButton = false;
                            this.displayConfigGrid = false;
                            this.displayButton = false;
                            this.messageHeader = MessageItems.erroHeader;
                            this.returnMessage.message = MessageItems.noResultsMessage;
                            this.messageIconType = APP_CONSTANTS.ErrorIcon;
                            this.displayMessage = true;
                        }
                    }, (error: Error) => {
                        this._router.navigate([Url.error]);
                    }, () => this.loading = false);
            }
        } else {
            this.loading = false;
            this.messageHeader = MessageItems.erroHeader;
            this.returnMessage.message = MessageItems.facilityMessage;
            this.messageIconType = APP_CONSTANTS.ErrorIcon;
            this.displayMessage = true;
            this.displayConfigGrid = false;
            this.displayButton = false;
            return;

        }
    }
    getColumnforGrid(obj: any): void {
        if (obj && obj.length) {
            const keys = Object.keys(obj[0]);
            const cols = [];
            let j = 0;
            keys.forEach(function (k: any) {
                for (let i = 0; i <= excludeColumns.columns.length - 1; i++) {
                    if (k === excludeColumns.columns[i]) {
                        j = 1;
                    }
                }
                let filter = ConstantValues.equalsFilter;
                for (let i = 0; i <= containsSearchfilterColumns.columns.length - 1; i++) {
                    if (k.toString().toLowerCase() === containsSearchfilterColumns.columns[i].toString().toLowerCase()) {

                        filter = ConstantValues.containsFilter;
                    }
                }
                if (j === 0) {
                    cols.push({ field: k, header: k, filter: filter });
                }
                j = 0;
            });

            this.colsGrid = cols;
        }
    }
    getProductDetails(prod) {
        this.loading = true;
        this.SAPRelevancy = '';
        this.ProductCode = '';
        this.ProductDesc = '';
        this.productID = '';
        this.Facility = '';
        this.data = '';
        this.productComments = '';
        this.productBusinessLifeCycleStatus = '';
        this.viewProductDetails = [];
        this.ViewProductConfigurationService.getProductDetailsByLegacyID(prod).
            subscribe((ViewProductDetails: ViewProductConfigurations[]) => {
                this.viewProductDetails = ViewProductDetails;
                if (this.viewProductDetails.length !== 0) {
                    this.productDetailSelected = true;
                    this.viewProductDetails.forEach(element => {
                        this.productStatusCode = element.productStatus;
                        this.productBusinessLifeCycleStatus = element.productBusinessLifeCycleStatus;
                        if (this.productStatusCode.toString().toLowerCase()
                            === ConstantValues.statusActive.toLowerCase()
                            && this.productBusinessLifeCycleStatus.toString().toLowerCase()
                            !== ConstantValues.statusInActive.toLowerCase()
                            && this.productBusinessLifeCycleStatus.toString().toLowerCase()
                            !== ConstantValues.statusObsolete.toLowerCase()) {
                            this.SAPRelevancy = element.sapRelevancyStatus;
                            this.ProductCode = element.productCode;
                            this.ProductDesc = element.productDescription;
                            this.productID = element.productId;
                            this.productComments = element.productComments;
                            if (element.facilityCollection !== null) {
                                this.facilityDropdownItems = [];
                                this.facilityCollection = element.facilityCollection.split(',');
                                this.facilityCollection.forEach(e => {
                                    const value = e.split('-')[0].toString();
                                    e = e.replace(e.split('-')[0].toString(), '').toString();
                                    e = e.replace(e.substring(0, 10), '');
                                    this.facilityDropdownItems.push({
                                        label: e,
                                        value: value
                                    });
                                });
                                this.facilityDropdownItems.sort(function (a, b) {
                                    return a.label.localeCompare(b.label);
                                });
                                this.Facility = '';
                                this.facilityDropdownItems.forEach(e => {
                                    this.Facility += e.label + ', ';
                                });
                                if (this.Facility !== '') {
                                    this.Facility = this.Facility.substring(0, this.Facility.length - 2);
                                }
                                this.showFacilities = true;
                            }
                        } else if (this.productStatusCode.toLowerCase() === ConstantValues.productStatusDraft.toLowerCase()) {
                            this.messageHeader = MessageItems.productHeader;
                            this.returnMessage.message = MessageItems.draftMessage;
                            this.messageIconType = APP_CONSTANTS.ErrorIcon;
                            this.displayMessage = true;
                            this.SAPRelevancy = '';
                            this.ProductCode = '';
                            this.ProductDesc = '';
                            this.Facility = '';
                            this.selectFacility = [];
                            this.showFacilities = false;
                            this.facilityDropdownItems = [];
                            this.productComments = '';
                            this.displayButton = false;
                            this.productDetailSelected = false;
                            this.displayConfigGrid = false;
                            this.productComments = '';
                        } else if (this.productStatusCode.toLowerCase() === ConstantValues.productStatusInActive.toLowerCase()) {
                            this.messageHeader = MessageItems.productHeader;
                            this.returnMessage.message = MessageItems.inactiveMessage;
                            this.messageIconType = APP_CONSTANTS.ErrorIcon;
                            this.displayMessage = true;
                            this.SAPRelevancy = '';
                            this.ProductCode = '';
                            this.ProductDesc = '';
                            this.Facility = '';
                            this.selectFacility = [];
                            this.showFacilities = false;
                            this.productDetailSelected = false;
                            this.facilityDropdownItems = [];
                            this.productComments = '';
                            this.displayButton = false;
                            this.displayConfigGrid = false;
                            this.productComments = '';
                        } else {
                            this.messageHeader = MessageItems.productHeader;
                            this.returnMessage.message = MessageItems.inactiveMessage;
                            this.messageIconType = APP_CONSTANTS.ErrorIcon;
                            this.displayMessage = true;
                            this.SAPRelevancy = '';
                            this.ProductCode = '';
                            this.ProductDesc = '';
                            this.Facility = '';
                            this.selectFacility = [];
                            this.showFacilities = false;
                            this.productDetailSelected = false;
                            this.facilityDropdownItems = [];
                            this.productComments = '';
                            this.displayButton = false;
                            this.displayConfigGrid = false;
                            this.productComments = '';
                        }
                    });
                } else {
                    this.SAPRelevancy = '';
                    this.ProductCode = '';
                    this.ProductDesc = '';
                    this.Facility = '';
                    this.showFacilities = false;
                    this.productDetailSelected = false;
                    this.selectFacility = [];
                    this.facilityDropdownItems = [];
                    this.displayButton = false;
                    this.displayConfigGrid = false;
                    this.productComments = '';
                    this.messageHeader = MessageItems.productHeader;
                    this.returnMessage.message = MessageItems.draftMessage;
                    this.messageIconType = APP_CONSTANTS.ErrorIcon;
                    this.displayMessage = true;
                }
            }, (error: Error) => {
                this._router.navigate([Url.error]);
            }, () => {
                this.enableDisableButtons();
                this.loading = false;
            });
    }

    btnClick() {
        this._router.navigateByUrl(RouteURLs.MaintainProductConfigurationsPath + ';id=' + this.legacyID);
    }
    s2ab(s) {
        const buf = new ArrayBuffer(s.length);
        const view = new Uint8Array(buf);
        for (let i = 0; i !== s.length; ++i) {
            view[i] = s.charCodeAt(i) & 0xFF;
        }
        return buf;
    }

    exportExcel() {
        let timestamp = '';
        timestamp = CommonUtilitiesComponent.getCurrentDateTimeStamp();
        const sheetName = 'ViewProductConfigurations' + '_' + timestamp + '.xlsx';
        this.configurationExcel = [];
        const ws_name = 'Product_Config_Details';
        const wb: WorkBook = { SheetNames: [], Sheets: {} };
        const viewProductConfig = new ViewProductConfigurations();
        viewProductConfig.productId = this.productID;
        viewProductConfig.facilityCollection = this.selectedFacilityValues;
        this.ViewProductConfigurationService.getProductConfigurationByFacilityExcel(viewProductConfig).
            subscribe((ViewProductDetails: any) => {
                this.configurationExcel = ViewProductDetails;
                const ws: any = utils.json_to_sheet(this.configurationExcel);
                wb.SheetNames.push(ws_name);
                wb.Sheets[ws_name] = ws;
                const wbout = write(wb, { bookType: 'xlsx', bookSST: true, type: 'binary' });
                saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), sheetName);
            },
            (err) => {
                if (err !== undefined) {
                    this._router.navigate([Url.error]);
                    return;
                }
            });
    }
    onGridPageChange(event: any) {
        this.firstRecordIndexofGrid = event.first === 1 ? event.first : event.first + 1;
        this.recordsPerPage = event.first !== 1 ? event.rows + event.first : event.rows;
    }
    enableDisableButtons() {
        if (this.viewProductDetails && this.viewProductDetails.length > 0 && !this.readOnlyUser) {
            this.disabled = false;
        } else {
            this.disabled = true;
        }
        if (this.readOnlyUser) {
            this.disableMaintainConfigurationButton = true;
        } else {
            this.disableMaintainConfigurationButton = false;
        }
    }
}
