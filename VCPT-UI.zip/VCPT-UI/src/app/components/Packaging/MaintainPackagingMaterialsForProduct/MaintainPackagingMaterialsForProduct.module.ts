import { OnlyNumberModule } from './../../../shared/Directives/OnlyNumber.module';
import { DialogDisplayModule } from './../../../shared/components/dialog-display/dialog-display.module';
import { APP_CONSTANTS } from './../../../shared/constants/app.constants';
import { LoadingModule } from 'ngx-loading';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import {
    InputMaskModule, DataTableModule, AccordionModule,
    SharedModule, ButtonModule, InputTextModule,
    ListboxModule, DialogModule, ConfirmationService, ConfirmDialogModule, PaginatorModule
} from 'primeng/primeng';

import { MaintainPackagingMaterialsForProductRouteModule } from './MaintainPackagingMaterialsForProduct.routing';
import { MaintainPackagingMaterialsForProductComponent } from './MaintainPackagingMaterialsForProduct.component';
import { MaintainPackagingMaterialsForProductService } from './../../../services/packaging/MaintainPackagingMaterialsForProduct.service';
import { PackagingMaterial } from './../../../models/PackagingMaterial.model';

@NgModule({
    imports: [
        InputTextModule,
        FormsModule,
        CommonModule,
        InputMaskModule,
        DataTableModule,
        SharedModule,
        ButtonModule,
        ListboxModule,
        DialogModule,
        ConfirmDialogModule,
        DialogDisplayModule,
        MaintainPackagingMaterialsForProductRouteModule,
        BrowserModule,
        ReactiveFormsModule,
        LoadingModule.forRoot(APP_CONSTANTS.loaderConfig),
        PaginatorModule,
        OnlyNumberModule,
        AccordionModule	
    ],
    providers: [MaintainPackagingMaterialsForProductService],
    declarations: [MaintainPackagingMaterialsForProductComponent]
})
export class MaintainPackagingMaterialsForProductModule {

}
