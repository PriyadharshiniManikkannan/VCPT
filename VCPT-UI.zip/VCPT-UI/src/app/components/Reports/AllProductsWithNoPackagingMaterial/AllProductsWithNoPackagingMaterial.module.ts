import { NgModule } from '@angular/core';
import { DialogDisplayModule } from './../../../shared/components/dialog-display/dialog-display.module';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AllProductsWithNoPackagingMaterialComponent } from './AllProductsWithNoPackagingMaterial.component';
import { AllProductsWithNoPackagingMaterialRoutingModule } from './AllProductsWithNoPackagingMaterial.routing';
import { APP_CONSTANTS } from './../../../shared/constants/app.constants';
import { CommonModule } from '@angular/common';
import { AllProductsWithNoPackagingMaterialService } from './../../../services/Reports/AllProductsWithNoPackagingMaterial.service';
import {RouterModule} from '@angular/router';
import {
    DialogModule, InputMaskModule, ButtonModule, ListboxModule, DataTableModule, AccordionModule
} from 'primeng/primeng';
@NgModule({
    imports: [
        FormsModule, CommonModule,
        DialogModule, InputMaskModule, ButtonModule, ListboxModule, DataTableModule, RouterModule,
        ReactiveFormsModule,
        AccordionModule,
        DialogDisplayModule,
        LoadingModule.forRoot(APP_CONSTANTS.loaderConfig)
    ],
    declarations: [AllProductsWithNoPackagingMaterialComponent],
    providers: [AllProductsWithNoPackagingMaterialService]
})
export class AllProductsWithNoPackagingMaterialModule {

}
